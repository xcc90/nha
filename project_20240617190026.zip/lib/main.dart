import 'package:flutter/material.dart';

import 'package:flutter_app/pages/desktop_2.dart';
import 'package:flutter_app/pages/desktop_3.dart';
import 'package:flutter_app/pages/equipamento_preenchido.dart';
import 'package:flutter_app/pages/equipamento_preenchido_1.dart';
import 'package:flutter_app/pages/equipamento_preenchido_expresso.dart';
import 'package:flutter_app/pages/equipamento_vazia_atendimento_expresso.dart';
import 'package:flutter_app/pages/equipamento_vazio.dart';
import 'package:flutter_app/pages/equipamento_vazio_preenchido.dart';
import 'package:flutter_app/pages/group_14.dart';
import 'package:flutter_app/pages/hamburger.dart';
import 'package:flutter_app/pages/login.dart';
import 'package:flutter_app/pages/relatorio.dart';
import 'package:flutter_app/pages/relatorio_1.dart';
import 'package:flutter_app/pages/reserva.dart';
import 'package:flutter_app/pages/reserva_preenchida.dart';
import 'package:flutter_app/pages/reserva_preenchida_datashow.dart';
import 'package:flutter_app/pages/reserva_preenchida_datashow_1.dart';
import 'package:flutter_app/pages/reserva_preenchida_datashow_2.dart';
import 'package:flutter_app/pages/reserva_preenchida_datashow_vazio.dart';
import 'package:flutter_app/pages/reserva_preenchida_expresso.dart';
import 'package:flutter_app/pages/reserva_vazia.dart';
import 'package:flutter_app/pages/reserva_vazia_atendimento_expresso.dart';
import 'package:flutter_app/pages/usuario_preenchido.dart';
import 'package:flutter_app/pages/usuario_preenchido_1.dart';
import 'package:flutter_app/pages/usuario_preenchido_2.dart';
import 'package:flutter_app/pages/usuario_preenchido_cadastro.dart';
import 'package:flutter_app/pages/usuario_preenchido_final.dart';
import 'package:flutter_app/pages/usuario_preenchido_final_1.dart';
import 'package:flutter_app/pages/usuario_vazio.dart';
import 'package:flutter_app/pages/usuario_vazio_cadastro.dart';


void main() => runApp(const MyApp());

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Flutter App',
      home: Scaffold(

        body: Desktop2(),
        // body: Desktop3(),
        // body: EquipamentoPreenchido(),
        // body: EquipamentoPreenchido1(),
        // body: EquipamentoPreenchidoExpresso(),
        // body: EquipamentoVaziaAtendimentoExpresso(),
        // body: EquipamentoVazio(),
        // body: EquipamentoVazioPreenchido(),
        // body: Group14(),
        // body: Hamburger(),
        // body: Login(),
        // body: Relatorio(),
        // body: Relatorio1(),
        // body: Reserva(),
        // body: ReservaPreenchida(),
        // body: ReservaPreenchidaDatashow(),
        // body: ReservaPreenchidaDatashow1(),
        // body: ReservaPreenchidaDatashow2(),
        // body: ReservaPreenchidaDatashowVazio(),
        // body: ReservaPreenchidaExpresso(),
        // body: ReservaVazia(),
        // body: ReservaVaziaAtendimentoExpresso(),
        // body: UsuarioPreenchido(),
        // body: UsuarioPreenchido1(),
        // body: UsuarioPreenchido2(),
        // body: UsuarioPreenchidoCadastro(),
        // body: UsuarioPreenchidoFinal(),
        // body: UsuarioPreenchidoFinal1(),
        // body: UsuarioVazio(),
        // body: UsuarioVazioCadastro(),

      ),
    );
  }
}
