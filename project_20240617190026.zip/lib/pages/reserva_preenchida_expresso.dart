import 'package:flutter/material.dart';
import 'dart:ui';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:flutter_app/utils.dart';
import 'package:google_fonts/google_fonts.dart';

class ReservaPreenchidaExpresso extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return 
    Container(
      decoration: BoxDecoration(
        color: Color(0xFFFFFFFF),
      ),
      child: SizedBox(
        width: 1440,
        child: Container(
          padding: EdgeInsets.fromLTRB(7, 34, 7, 0),
          child: Stack(
            clipBehavior: Clip.none,
            children: [
              Positioned(
                right: -7,
                bottom: 21,
                child: ImageFiltered(
                  imageFilter: ImageFilter.blur(
                    sigmaX: 2,
                    sigmaY: 2,
                  ),
                  child: SizedBox(
                    width: 1244,
                    height: 917,
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.start,
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: [
                        Container(
                          margin: EdgeInsets.fromLTRB(0, 0, 0, 26),
                          child: Container(
                            decoration: BoxDecoration(
                              color: Color(0xFFD9D9D9),
                            ),
                            child: Container(
                              width: 1244,
                              height: 36,
                            ),
                          ),
                        ),
                        Container(
                          margin: EdgeInsets.fromLTRB(16, 0, 31, 30),
                          decoration: BoxDecoration(
                            border: Border.all(color: Color(0xFFAA9D9D)),
                            color: Color(0xFFD9D9D9),
                          ),
                          child: Container(
                            width: 1197,
                            height: 162,
                          ),
                        ),
                        Container(
                          margin: EdgeInsets.fromLTRB(16, 0, 31, 0),
                          child: Container(
                            decoration: BoxDecoration(
                              color: Color(0xFFD9D9D9),
                            ),
                            child: Container(
                              width: 1197,
                              height: 663,
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ),
              Column(
                mainAxisAlignment: MainAxisAlignment.start,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Container(
                    margin: EdgeInsets.fromLTRB(0, 0, 0, 48),
                    child: Align(
                      alignment: Alignment.topRight,
                      child: Text(
                        'logado: Waltair',
                        style: GoogleFonts.getFont(
                          'Fira Sans Condensed',
                          fontWeight: FontWeight.w300,
                          fontSize: 16,
                          color: Color(0xFFFFFFFF),
                        ),
                      ),
                    ),
                  ),
                  Container(
                    margin: EdgeInsets.fromLTRB(1, 0, 1, 10),
                    child: Align(
                      alignment: Alignment.topLeft,
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.start,
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Container(
                            margin: EdgeInsets.fromLTRB(0, 0, 8, 5),
                            child: SizedBox(
                              width: 18,
                              height: 16,
                              child: SvgPicture.asset(
                                'assets/vectors/vector_274_x2.svg',
                              ),
                            ),
                          ),
                          Container(
                            margin: EdgeInsets.fromLTRB(0, 2, 0, 0),
                            child: Text(
                              'inicio
                          ',
                              style: GoogleFonts.getFont(
                                'Fira Sans Condensed',
                                fontWeight: FontWeight.w300,
                                fontSize: 16,
                                color: Color(0xFFFFFFFF),
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                  Container(
                    margin: EdgeInsets.fromLTRB(0, 0, 0, 13),
                    child: Align(
                      alignment: Alignment.topLeft,
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.start,
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Container(
                            margin: EdgeInsets.fromLTRB(0, 5, 8, 0),
                            child: SizedBox(
                              width: 18,
                              height: 16,
                              child: SvgPicture.asset(
                                'assets/vectors/vector_124_x2.svg',
                              ),
                            ),
                          ),
                          Container(
                            margin: EdgeInsets.fromLTRB(0, 0, 0, 2),
                            child: Text(
                              'consultar reservas',
                              style: GoogleFonts.getFont(
                                'Fira Sans Condensed',
                                fontWeight: FontWeight.w300,
                                fontSize: 16,
                                color: Color(0xFFFFFFFF),
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                  Container(
                    margin: EdgeInsets.fromLTRB(0.8, 0, 0.8, 15),
                    child: Align(
                      alignment: Alignment.topLeft,
                      child: SizedBox(
                        width: 412,
                        child: Stack(
                          children: [
                            SizedBox(
                              width: 412,
                              child: Row(
                                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Column(
                                    mainAxisAlignment: MainAxisAlignment.start,
                                    crossAxisAlignment: CrossAxisAlignment.center,
                                    children: [
                                      Container(
                                        margin: EdgeInsets.fromLTRB(0, 0, 0, 10),
                                        child: Row(
                                          mainAxisAlignment: MainAxisAlignment.start,
                                          crossAxisAlignment: CrossAxisAlignment.start,
                                          children: [
                                            Container(
                                              margin: EdgeInsets.fromLTRB(0, 2.5, 8.8, 1.5),
                                              child: SizedBox(
                                                width: 16.5,
                                                height: 15,
                                                child: SvgPicture.asset(
                                                  'assets/vectors/vector_88_x2.svg',
                                                ),
                                              ),
                                            ),
                                            Text(
                                              'adicionar material',
                                              style: GoogleFonts.getFont(
                                                'Fira Sans Condensed',
                                                fontWeight: FontWeight.w300,
                                                fontSize: 16,
                                                color: Color(0xFFFFFFFF),
                                              ),
                                            ),
                                          ],
                                        ),
                                      ),
                                      Container(
                                        margin: EdgeInsets.fromLTRB(0.3, 0, 6.6, 0),
                                        child: Row(
                                          mainAxisAlignment: MainAxisAlignment.start,
                                          crossAxisAlignment: CrossAxisAlignment.start,
                                          children: [
                                            Container(
                                              margin: EdgeInsets.fromLTRB(0, 3, 8, 0),
                                              child: SizedBox(
                                                width: 17,
                                                height: 16,
                                                child: SvgPicture.asset(
                                                  'assets/vectors/vector_176_x2.svg',
                                                ),
                                              ),
                                            ),
                                            Text(
                                              'adicionar reserva',
                                              style: GoogleFonts.getFont(
                                                'Fira Sans Condensed',
                                                fontWeight: FontWeight.w300,
                                                fontSize: 16,
                                                color: Color(0xFFFFFFFF),
                                              ),
                                            ),
                                          ],
                                        ),
                                      ),
                                    ],
                                  ),
                                  Container(
                                    margin: EdgeInsets.fromLTRB(0, 3, 0, 4),
                                    child: ImageFiltered(
                                      imageFilter: ImageFilter.blur(
                                        sigmaX: 2,
                                        sigmaY: 2,
                                      ),
                                      child: Column(
                                        mainAxisAlignment: MainAxisAlignment.start,
                                        crossAxisAlignment: CrossAxisAlignment.start,
                                        children: [
                                          Align(
                                            alignment: Alignment.topLeft,
                                            child: Text(
                                              'Data Inicial',
                                              style: GoogleFonts.getFont(
                                                'Fira Sans Condensed',
                                                fontWeight: FontWeight.w600,
                                                fontSize: 10,
                                                color: Color(0xFF000000),
                                              ),
                                            ),
                                          ),
                                          Container(
                                            decoration: BoxDecoration(
                                              border: Border.all(color: Color(0xFFAAA1A1)),
                                              color: Color(0xFFFFFFFF),
                                            ),
                                            child: SizedBox(
                                              width: 187.8,
                                              child: Container(
                                                padding: EdgeInsets.fromLTRB(4.8, 2.3, 0, 3.5),
                                                child: Row(
                                                  mainAxisAlignment: MainAxisAlignment.start,
                                                  crossAxisAlignment: CrossAxisAlignment.start,
                                                  children: [
                                                    Container(
                                                      margin: EdgeInsets.fromLTRB(0, 0, 4.8, 0),
                                                      child: SizedBox(
                                                        width: 30.2,
                                                        height: 23.4,
                                                        child: SvgPicture.asset(
                                                          'assets/vectors/vector_186_x2.svg',
                                                        ),
                                                      ),
                                                    ),
                                                    Container(
                                                      margin: EdgeInsets.fromLTRB(0, 1.2, 0, 0),
                                                      child: Container(
                                                        decoration: BoxDecoration(
                                                          color: Color(0xFFAA9D9D),
                                                        ),
                                                        child: Container(
                                                          width: 1,
                                                          height: 22.3,
                                                        ),
                                                      ),
                                                    ),
                                                  ],
                                                ),
                                              ),
                                            ),
                                          ),
                                        ],
                                      ),
                                    ),
                                  ),
                                ],
                              ),
                            ),
                            Positioned(
                              right: 57.8,
                              bottom: 13,
                              child: ImageFiltered(
                                imageFilter: ImageFilter.blur(
                                  sigmaX: 2,
                                  sigmaY: 2,
                                ),
                                child: SizedBox(
                                  height: 15,
                                  child: Text(
                                    '09/11/2022',
                                    style: GoogleFonts.getFont(
                                      'Inter',
                                      fontWeight: FontWeight.w400,
                                      fontSize: 12,
                                      color: Color(0xFF000000),
                                    ),
                                  ),
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ),
                  Container(
                    margin: EdgeInsets.fromLTRB(1, 0, 1, 0),
                    child: Align(
                      alignment: Alignment.topLeft,
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.start,
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Container(
                            margin: EdgeInsets.fromLTRB(0, 1, 10, 2),
                            child: SizedBox(
                              width: 15,
                              height: 16,
                              child: SvgPicture.asset(
                                'assets/vectors/container_34_x2.svg',
                              ),
                            ),
                          ),
                          Text(
                            'relatorios
                          ',
                            style: GoogleFonts.getFont(
                              'Fira Sans Condensed',
                              fontWeight: FontWeight.w300,
                              fontSize: 16,
                              color: Color(0xFFFFFFFF),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ],
              ),
              Positioned(
                left: -89,
                bottom: 0,
                child: Container(
                  decoration: BoxDecoration(
                    color: Color(0xFF212176),
                    borderRadius: BorderRadius.only(
                      bottomRight: Radius.circular(100),
                    ),
                  ),
                  child: SizedBox(
                    width: 278,
                    height: 959,
                    child: Container(
                      padding: EdgeInsets.fromLTRB(9.2, 15.8, 9.2, 0),
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.start,
                        crossAxisAlignment: CrossAxisAlignment.center,
                        children: [
                          Container(
                            margin: EdgeInsets.fromLTRB(0, 0, 0, 16.9),
                            child: Align(
                              alignment: Alignment.topLeft,
                              child: Row(
                                mainAxisAlignment: MainAxisAlignment.start,
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Container(
                                    margin: EdgeInsets.fromLTRB(0, 0, 43.5, 0),
                                    child: SizedBox(
                                      width: 47.3,
                                      height: 65.3,
                                      child: SvgPicture.asset(
                                        'assets/vectors/hamburger_24_x2.svg',
                                      ),
                                    ),
                                  ),
                                  Container(
                                    margin: EdgeInsets.fromLTRB(0, 32.2, 0, 13.1),
                                    child: Row(
                                      mainAxisAlignment: MainAxisAlignment.start,
                                      crossAxisAlignment: CrossAxisAlignment.start,
                                      children: [
                                        Container(
                                          margin: EdgeInsets.fromLTRB(0, 3, 8, 1),
                                          child: SizedBox(
                                            width: 17,
                                            height: 16,
                                            child: SvgPicture.asset(
                                              'assets/vectors/vector_378_x2.svg',
                                            ),
                                          ),
                                        ),
                                        Text(
                                          'Audio visual',
                                          style: GoogleFonts.getFont(
                                            'Fira Sans Condensed',
                                            fontWeight: FontWeight.w600,
                                            fontSize: 17,
                                            color: Color(0xFFFFFFFF),
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ),
                          Container(
                            margin: EdgeInsets.fromLTRB(35.8, 0, 0, 34),
                            child: Row(
                              mainAxisAlignment: MainAxisAlignment.start,
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Container(
                                  margin: EdgeInsets.fromLTRB(0, 2.5, 4.5, 2.5),
                                  child: SizedBox(
                                    width: 16.5,
                                    height: 15,
                                    child: SvgPicture.asset(
                                      'assets/vectors/vector_336_x2.svg',
                                    ),
                                  ),
                                ),
                                Text(
                                  'Equipamento',
                                  style: GoogleFonts.getFont(
                                    'Fira Sans Condensed',
                                    fontWeight: FontWeight.w600,
                                    fontSize: 17,
                                    color: Color(0xFFFFFFFF),
                                  ),
                                ),
                              ],
                            ),
                          ),
                          Container(
                            margin: EdgeInsets.fromLTRB(8.6, 0, 0, 31),
                            child: Row(
                              mainAxisAlignment: MainAxisAlignment.start,
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Container(
                                  margin: EdgeInsets.fromLTRB(0, 1, 10, 3),
                                  child: SizedBox(
                                    width: 15,
                                    height: 16,
                                    child: SvgPicture.asset(
                                      'assets/vectors/container_68_x2.svg',
                                    ),
                                  ),
                                ),
                                Text(
                                  'Usuários',
                                  style: GoogleFonts.getFont(
                                    'Fira Sans Condensed',
                                    fontWeight: FontWeight.w600,
                                    fontSize: 17,
                                    color: Color(0xFFFFFFFF),
                                  ),
                                ),
                              ],
                            ),
                          ),
                          Container(
                            margin: EdgeInsets.fromLTRB(27.6, 0, 0, 33),
                            child: Row(
                              mainAxisAlignment: MainAxisAlignment.start,
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Container(
                                  margin: EdgeInsets.fromLTRB(0, 1, 10, 3),
                                  child: SizedBox(
                                    width: 15,
                                    height: 16,
                                    child: SvgPicture.asset(
                                      'assets/vectors/container_48_x2.svg',
                                    ),
                                  ),
                                ),
                                Text(
                                  'Relatorios
                                ',
                                  style: GoogleFonts.getFont(
                                    'Fira Sans Condensed',
                                    fontWeight: FontWeight.w600,
                                    fontSize: 17,
                                    color: Color(0xFFFFFFFF),
                                  ),
                                ),
                              ],
                            ),
                          ),
                          Container(
                            margin: EdgeInsets.fromLTRB(7.2, 0, 0, 0),
                            child: Row(
                              mainAxisAlignment: MainAxisAlignment.start,
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Container(
                                  margin: EdgeInsets.fromLTRB(0, 5, 8, 0),
                                  child: SizedBox(
                                    width: 18,
                                    height: 16,
                                    child: SvgPicture.asset(
                                      'assets/vectors/vector_77_x2.svg',
                                    ),
                                  ),
                                ),
                                Container(
                                  margin: EdgeInsets.fromLTRB(0, 0, 0, 1),
                                  child: Text(
                                    'Reservas',
                                    style: GoogleFonts.getFont(
                                      'Fira Sans Condensed',
                                      fontWeight: FontWeight.w600,
                                      fontSize: 17,
                                      color: Color(0xFFFFFFFF),
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ),
              ),
              Positioned(
                right: -46,
                top: -34,
                child: Container(
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(5),
                    color: Color(0xFF000041),
                    boxShadow: [
                      BoxShadow(
                        color: Color(0x40000000),
                        offset: Offset(0, 4),
                        blurRadius: 2,
                      ),
                    ],
                  ),
                  child: SizedBox(
                    width: 1479,
                    height: 82,
                    child: Container(
                      padding: EdgeInsets.fromLTRB(0, 4, 74, 6),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Container(
                            decoration: BoxDecoration(
                              image: DecorationImage(
                                fit: BoxFit.cover,
                                image: AssetImage(
                                  'assets/images/image_2.png',
                                ),
                              ),
                            ),
                            child: Container(
                              width: 189,
                              height: 72,
                            ),
                          ),
                          Container(
                            margin: EdgeInsets.fromLTRB(0, 6, 0, 9),
                            child: Row(
                              mainAxisAlignment: MainAxisAlignment.start,
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Container(
                                  margin: EdgeInsets.fromLTRB(0, 0, 17, 0),
                                  child: SizedBox(
                                    width: 59,
                                    height: 57,
                                    child: SvgPicture.asset(
                                      'assets/vectors/group_1815_x2.svg',
                                    ),
                                  ),
                                ),
                                Container(
                                  margin: EdgeInsets.fromLTRB(0, 19, 0, 19),
                                  child: Text(
                                    'Logado: Waltair',
                                    style: GoogleFonts.getFont(
                                      'Fira Sans Condensed',
                                      fontWeight: FontWeight.w600,
                                      fontSize: 16,
                                      color: Color(0xFFFFFFFF),
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ),
                          Container(
                            margin: EdgeInsets.fromLTRB(0, 14, 0, 16),
                            child: Row(
                              mainAxisAlignment: MainAxisAlignment.start,
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Container(
                                  margin: EdgeInsets.fromLTRB(0, 0, 31, 0),
                                  child: Container(
                                    padding: EdgeInsets.fromLTRB(17, 11, 17, 12),
                                    child: Stack(
                                      clipBehavior: Clip.none,
                                      children: [
                                        Text(
                                          'Encerrar sessão',
                                          style: GoogleFonts.getFont(
                                            'Fira Sans Condensed',
                                            fontWeight: FontWeight.w600,
                                            fontSize: 16,
                                            color: Color(0xFFFFFFFF),
                                          ),
                                        ),
                                        Positioned(
                                          bottom: -12,
                                          child: Container(
                                            width: 138,
                                            height: 42,
                                            decoration: BoxDecoration(
                                              border: Border.all(color: Color(0xFFFFFFFF)),
                                              borderRadius: BorderRadius.circular(19),
                                            ),
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                ),
                                Container(
                                  decoration: BoxDecoration(
                                    color: Color(0xFF202075),
                                  ),
                                  child: SizedBox(
                                    width: 53,
                                    child: Container(
                                      padding: EdgeInsets.fromLTRB(2.7, 12.9, 7.7, 12.6),
                                      child: Stack(
                                        clipBehavior: Clip.none,
                                        children: [
                                          SizedBox(
                                            width: 42.6,
                                            child: Column(
                                              mainAxisAlignment: MainAxisAlignment.start,
                                              crossAxisAlignment: CrossAxisAlignment.center,
                                              children: [
                                                Container(
                                                  margin: EdgeInsets.fromLTRB(7.4, 0, 2.7, 4),
                                                  child: ClipRRect(
                                                    borderRadius: BorderRadius.circular(40),
                                                    child: SizedBox(
                                                      width: 32.5,
                                                      height: 2.8,
                                                      child: SvgPicture.asset(
                                                        'assets/vectors/rectangle_24_x2.svg',
                                                      ),
                                                    ),
                                                  ),
                                                ),
                                                Container(
                                                  margin: EdgeInsets.fromLTRB(7.4, 0, 2.7, 4),
                                                  child: ClipRRect(
                                                    borderRadius: BorderRadius.circular(40),
                                                    child: SizedBox(
                                                      width: 32.5,
                                                      height: 2.8,
                                                      child: SvgPicture.asset(
                                                        'assets/vectors/rectangle_38_x2.svg',
                                                      ),
                                                    ),
                                                  ),
                                                ),
                                                ClipRRect(
                                                  borderRadius: BorderRadius.circular(40),
                                                  child: SizedBox(
                                                    width: 42.6,
                                                    height: 2.8,
                                                    child: SvgPicture.asset(
                                                      'assets/vectors/rectangle_416_x2.svg',
                                                    ),
                                                  ),
                                                ),
                                              ],
                                            ),
                                          ),
                                          Positioned(
                                            left: -2.7,
                                            top: -11.9,
                                            child: Container(
                                              decoration: BoxDecoration(
                                                color: Color(0x03FFFFFF),
                                              ),
                                              child: Container(
                                                width: 48.7,
                                                height: 34.7,
                                              ),
                                            ),
                                          ),
                                        ],
                                      ),
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ),
              ),
              Positioned(
                right: 599.2,
                top: 135,
                child: ImageFiltered(
                  imageFilter: ImageFilter.blur(
                    sigmaX: 2,
                    sigmaY: 2,
                  ),
                  child: SizedBox(
                    width: 187.8,
                    height: 41,
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.start,
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Align(
                          alignment: Alignment.topLeft,
                          child: Text(
                            'Setor',
                            style: GoogleFonts.getFont(
                              'Fira Sans Condensed',
                              fontWeight: FontWeight.w600,
                              fontSize: 10,
                              color: Color(0xFF000000),
                            ),
                          ),
                        ),
                        Container(
                          decoration: BoxDecoration(
                            border: Border.all(color: Color(0xFFAAA1A1)),
                            color: Color(0xFFFFFFFF),
                          ),
                          child: Container(
                            width: 187.8,
                            height: 29.3,
                            padding: EdgeInsets.fromLTRB(9, 3.5, 9, 3.5),
                            child: SizedBox(
                              width: 31.8,
                              height: 22.3,
                              child: SvgPicture.asset(
                                'assets/vectors/container_73_x2.svg',
                              ),
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ),
              Positioned(
                left: 432,
                top: 135,
                child: ImageFiltered(
                  imageFilter: ImageFilter.blur(
                    sigmaX: 2,
                    sigmaY: 2,
                  ),
                  child: SizedBox(
                    width: 187.8,
                    height: 41,
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.start,
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Align(
                          alignment: Alignment.topLeft,
                          child: Text(
                            'Data Final',
                            style: GoogleFonts.getFont(
                              'Fira Sans Condensed',
                              fontWeight: FontWeight.w600,
                              fontSize: 10,
                              color: Color(0xFF000000),
                            ),
                          ),
                        ),
                        Container(
                          decoration: BoxDecoration(
                            border: Border.all(color: Color(0xFFAAA1A1)),
                            color: Color(0xFFFFFFFF),
                          ),
                          child: SizedBox(
                            width: 187.8,
                            child: Container(
                              padding: EdgeInsets.fromLTRB(4.8, 2.3, 0, 3.5),
                              child: Row(
                                mainAxisAlignment: MainAxisAlignment.start,
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Container(
                                    margin: EdgeInsets.fromLTRB(0, 0, 4.8, 0),
                                    child: SizedBox(
                                      width: 30.2,
                                      height: 23.4,
                                      child: SvgPicture.asset(
                                        'assets/vectors/vector_63_x2.svg',
                                      ),
                                    ),
                                  ),
                                  Container(
                                    margin: EdgeInsets.fromLTRB(0, 1.2, 0, 0),
                                    child: Container(
                                      decoration: BoxDecoration(
                                        color: Color(0xFFAA9D9D),
                                      ),
                                      child: Container(
                                        width: 1,
                                        height: 22.3,
                                      ),
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ),
              Positioned(
                right: 392.2,
                top: 135,
                child: ImageFiltered(
                  imageFilter: ImageFilter.blur(
                    sigmaX: 2,
                    sigmaY: 2,
                  ),
                  child: SizedBox(
                    width: 187.8,
                    height: 41,
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.start,
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Align(
                          alignment: Alignment.topLeft,
                          child: Text(
                            'Responsavel',
                            style: GoogleFonts.getFont(
                              'Fira Sans Condensed',
                              fontWeight: FontWeight.w600,
                              fontSize: 10,
                              color: Color(0xFF000000),
                            ),
                          ),
                        ),
                        Container(
                          decoration: BoxDecoration(
                            border: Border.all(color: Color(0xFFAAA1A1)),
                            color: Color(0xFFFFFFFF),
                          ),
                          child: Container(
                            width: 187.8,
                            height: 29.3,
                            padding: EdgeInsets.fromLTRB(10, 3.5, 10, 3.5),
                            child: SizedBox(
                              width: 30.8,
                              height: 22.3,
                              child: SvgPicture.asset(
                                'assets/vectors/container_20_x2.svg',
                              ),
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ),
              Positioned(
                right: 392.2,
                top: 135,
                child: ImageFiltered(
                  imageFilter: ImageFilter.blur(
                    sigmaX: 2,
                    sigmaY: 2,
                  ),
                  child: SizedBox(
                    width: 187.8,
                    height: 41,
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.start,
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Align(
                          alignment: Alignment.topLeft,
                          child: Text(
                            'Responsavel',
                            style: GoogleFonts.getFont(
                              'Fira Sans Condensed',
                              fontWeight: FontWeight.w600,
                              fontSize: 10,
                              color: Color(0xFF000000),
                            ),
                          ),
                        ),
                        Container(
                          decoration: BoxDecoration(
                            border: Border.all(color: Color(0xFFAAA1A1)),
                            color: Color(0xFFFFFFFF),
                          ),
                          child: Container(
                            width: 187.8,
                            height: 29.3,
                            padding: EdgeInsets.fromLTRB(10, 3.5, 10, 3.5),
                            child: SizedBox(
                              width: 30.8,
                              height: 22.3,
                              child: SvgPicture.asset(
                                'assets/vectors/container_2_x2.svg',
                              ),
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ),
              Positioned(
                right: 185.2,
                top: 135,
                child: ImageFiltered(
                  imageFilter: ImageFilter.blur(
                    sigmaX: 2,
                    sigmaY: 2,
                  ),
                  child: SizedBox(
                    width: 187.8,
                    height: 41,
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.start,
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Align(
                          alignment: Alignment.topLeft,
                          child: Text(
                            'Situação',
                            style: GoogleFonts.getFont(
                              'Fira Sans Condensed',
                              fontWeight: FontWeight.w600,
                              fontSize: 10,
                              color: Color(0xFF000000),
                            ),
                          ),
                        ),
                        Container(
                          decoration: BoxDecoration(
                            border: Border.all(color: Color(0xFFAAA1A1)),
                            color: Color(0xFFFFFFFF),
                          ),
                          child: Container(
                            width: 187.8,
                            height: 29.3,
                            padding: EdgeInsets.fromLTRB(9, 3.5, 9, 3.5),
                            child: SizedBox(
                              width: 31.8,
                              height: 22.3,
                              child: SvgPicture.asset(
                                'assets/vectors/container_74_x2.svg',
                              ),
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ),
              Positioned(
                right: -30.1,
                top: 148,
                child: ImageFiltered(
                  imageFilter: ImageFilter.blur(
                    sigmaX: 2,
                    sigmaY: 2,
                  ),
                  child: Stack(
                    children: [
                    Positioned(
                      left: -13.4,
                      top: -5.4,
                      child: Container(
                        decoration: BoxDecoration(
                          color: Color(0xFF000041),
                        ),
                        child: Container(
                          width: 98,
                          height: 28,
                        ),
                      ),
                    ),
              SizedBox(
                        width: 168.1,
                        height: 28,
                        child: Container(
                          padding: EdgeInsets.fromLTRB(13.4, 5.4, 0, 7.4),
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.start,
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Container(
                                margin: EdgeInsets.fromLTRB(0, 0, 7.4, 0),
                                child: SizedBox(
                                  width: 15.2,
                                  height: 15.2,
                                  child: SvgPicture.asset(
                                    'assets/vectors/vector_34_x2.svg',
                                  ),
                                ),
                              ),
                              Container(
                                margin: EdgeInsets.fromLTRB(0, 2.6, 0, 0.6),
                                child: Text(
                                  'Consultar',
                                  style: GoogleFonts.getFont(
                                    'Fira Sans Condensed',
                                    fontWeight: FontWeight.w600,
                                    fontSize: 10,
                                    color: Color(0xFFFFFFFF),
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
              Positioned(
                left: 225,
                top: 196,
                child: ImageFiltered(
                  imageFilter: ImageFilter.blur(
                    sigmaX: 2,
                    sigmaY: 2,
                  ),
                  child: Stack(
                    children: [
                    Positioned(
                      left: -6,
                      top: -7,
                      child: Container(
                        decoration: BoxDecoration(
                          color: Color(0xFF000041),
                        ),
                        child: Container(
                          width: 144,
                          height: 28,
                        ),
                      ),
                    ),
              SizedBox(
                        width: 162.1,
                        height: 28,
                        child: Container(
                          padding: EdgeInsets.fromLTRB(6, 7, 0, 7),
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.start,
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Container(
                                margin: EdgeInsets.fromLTRB(0, 0, 10, 0),
                                child: SizedBox(
                                  width: 14,
                                  height: 14,
                                  child: SvgPicture.asset(
                                    'assets/vectors/vector_117_x2.svg',
                                  ),
                                ),
                              ),
                              Container(
                                margin: EdgeInsets.fromLTRB(0, 1, 0, 1),
                                child: Text(
                                  'Atendimento Expresso',
                                  style: GoogleFonts.getFont(
                                    'Fira Sans Condensed',
                                    fontWeight: FontWeight.w600,
                                    fontSize: 10,
                                    color: Color(0xFFFFFFFF),
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
              Positioned(
                right: 24,
                top: 307,
                child: ImageFiltered(
                  imageFilter: ImageFilter.blur(
                    sigmaX: 2,
                    sigmaY: 2,
                  ),
                  child: Stack(
                    children: [
                    Positioned(
                      top: -7,
                      child: Container(
                        decoration: BoxDecoration(
                          color: Color(0xFF212176),
                        ),
                        child: Container(
                          width: 1197,
                          height: 31,
                        ),
                      ),
                    ),
              SizedBox(
                        width: 1197,
                        height: 43,
                        child: Container(
                          padding: EdgeInsets.fromLTRB(5, 7, 0, 16),
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.start,
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Container(
                                margin: EdgeInsets.fromLTRB(0, 0, 3, 0),
                                child: SizedBox(
                                  width: 20,
                                  height: 20,
                                  child: SvgPicture.asset(
                                    'assets/vectors/vector_135_x2.svg',
                                  ),
                                ),
                              ),
                              Container(
                                margin: EdgeInsets.fromLTRB(0, 5, 0, 3),
                                child: Text(
                                  'Atividades',
                                  style: GoogleFonts.getFont(
                                    'Fira Sans Condensed',
                                    fontWeight: FontWeight.w600,
                                    fontSize: 10,
                                    color: Color(0xFFFFFFFF),
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
              Positioned(
                left: 502,
                top: 152,
                child: ImageFiltered(
                  imageFilter: ImageFilter.blur(
                    sigmaX: 2,
                    sigmaY: 2,
                  ),
                  child: SizedBox(
                    height: 15,
                    child: Text(
                      '21/11/2022',
                      style: GoogleFonts.getFont(
                        'Inter',
                        fontWeight: FontWeight.w400,
                        fontSize: 12,
                        color: Color(0xFF000000),
                      ),
                    ),
                  ),
                ),
              ),
              Positioned(
                right: 677.2,
                top: 152,
                child: ImageFiltered(
                  imageFilter: ImageFilter.blur(
                    sigmaX: 2,
                    sigmaY: 2,
                  ),
                  child: SizedBox(
                    height: 15,
                    child: Text(
                      'Bloco C',
                      style: GoogleFonts.getFont(
                        'Inter',
                        fontWeight: FontWeight.w400,
                        fontSize: 12,
                        color: Color(0xFF000000),
                      ),
                    ),
                  ),
                ),
              ),
              Positioned(
                right: 449.3,
                top: 152,
                child: ImageFiltered(
                  imageFilter: ImageFilter.blur(
                    sigmaX: 2,
                    sigmaY: 2,
                  ),
                  child: SizedBox(
                    height: 15,
                    child: Text(
                      'Germano',
                      style: GoogleFonts.getFont(
                        'Inter',
                        fontWeight: FontWeight.w400,
                        fontSize: 12,
                        color: Color(0xFF000000),
                      ),
                    ),
                  ),
                ),
              ),
              Positioned(
                right: 239,
                top: 153,
                child: ImageFiltered(
                  imageFilter: ImageFilter.blur(
                    sigmaX: 2,
                    sigmaY: 2,
                  ),
                  child: SizedBox(
                    height: 15,
                    child: Text(
                      'Reservada',
                      style: GoogleFonts.getFont(
                        'Inter',
                        fontWeight: FontWeight.w400,
                        fontSize: 12,
                        color: Color(0xFF000000),
                      ),
                    ),
                  ),
                ),
              ),
              Positioned(
                left: 215,
                top: 353,
                child: ImageFiltered(
                  imageFilter: ImageFilter.blur(
                    sigmaX: 2,
                    sigmaY: 2,
                  ),
                  child: SizedBox(
                    width: 77.9,
                    height: 66,
                    child: Container(
                      padding: EdgeInsets.fromLTRB(0, 0, 4.7, 0),
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.start,
                        crossAxisAlignment: CrossAxisAlignment.center,
                        children: [
                          Container(
                            margin: EdgeInsets.fromLTRB(0, 0, 0, 6.7),
                            child: Container(
                              decoration: BoxDecoration(
                                color: Color(0xFF4228D7),
                              ),
                              child: Container(
                                padding: EdgeInsets.fromLTRB(12, 4, 16.3, 4.3),
                                child: Text(
                                  'nº Reserva',
                                  style: GoogleFonts.getFont(
                                    'Fira Sans Condensed',
                                    fontWeight: FontWeight.w600,
                                    fontSize: 10,
                                    color: Color(0xFFFFFFFF),
                                  ),
                                ),
                              ),
                            ),
                          ),
                          Container(
                            margin: EdgeInsets.fromLTRB(0, 0, 0, 7),
                            child: SizedBox(
                              width: 73.2,
                              child: Container(
                                padding: EdgeInsets.fromLTRB(0, 0, 0.9, 4),
                                child: Stack(
                                  clipBehavior: Clip.none,
                                  children: [
                                    Positioned(
                                      left: 0,
                                      right: 0,
                                      bottom: 0,
                                      child: Container(
                                        width: 73.2,
                                        height: 14.3,
                                        decoration: BoxDecoration(
                                          border: Border(
                                            bottom: BorderSize(
                                              color: Color(0xFFAA9D9D),
                                              width: 1,
                                            ),
                                          ),
                                        ),
                                      ),
                                    ),
                                    Text(
                                      '254',
                                      style: GoogleFonts.getFont(
                                        'Fira Sans Condensed',
                                        fontWeight: FontWeight.w500,
                                        fontSize: 10,
                                        color: Color(0xFF3E3636),
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                            ),
                          ),
                          SizedBox(
                            width: 73.2,
                            child: Container(
                              padding: EdgeInsets.fromLTRB(0, 0, 1.2, 4),
                              child: Stack(
                                clipBehavior: Clip.none,
                                children: [
                                  Positioned(
                                    left: 0,
                                    right: 0,
                                    bottom: 0,
                                    child: Container(
                                      width: 73.2,
                                      height: 14.3,
                                      decoration: BoxDecoration(
                                        border: Border(
                                          bottom: BorderSize(
                                            color: Color(0xFFAA9D9D),
                                            width: 1,
                                          ),
                                        ),
                                      ),
                                    ),
                                  ),
                                  Text(
                                    '255',
                                    style: GoogleFonts.getFont(
                                      'Fira Sans Condensed',
                                      fontWeight: FontWeight.w500,
                                      fontSize: 10,
                                      color: Color(0xFF3E3636),
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ),
              ),
              Positioned(
                left: 289.6,
                top: 353,
                child: ImageFiltered(
                  imageFilter: ImageFilter.blur(
                    sigmaX: 2,
                    sigmaY: 2,
                  ),
                  child: SizedBox(
                    width: 127.7,
                    height: 66,
                    child: Container(
                      padding: EdgeInsets.fromLTRB(0, 0, 0, 0),
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.start,
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Container(
                            margin: EdgeInsets.fromLTRB(0, 0, 0, 6.7),
                            child: Align(
                              alignment: Alignment.topLeft,
                              child: Container(
                                decoration: BoxDecoration(
                                  color: Color(0xFF4228D7),
                                ),
                                child: Container(
                                  padding: EdgeInsets.fromLTRB(19.4, 4, 19.4, 4.3),
                                  child: Text(
                                    'Data de retirada',
                                    style: GoogleFonts.getFont(
                                      'Fira Sans Condensed',
                                      fontWeight: FontWeight.w600,
                                      fontSize: 10,
                                      color: Color(0xFFFFFFFF),
                                    ),
                                  ),
                                ),
                              ),
                            ),
                          ),
                          Container(
                            margin: EdgeInsets.fromLTRB(0, 0, 0, 7),
                            child: Align(
                              alignment: Alignment.topLeft,
                              child: SizedBox(
                                width: 106.8,
                                child: Container(
                                  padding: EdgeInsets.fromLTRB(0, 0, 4.2, 4),
                                  child: Stack(
                                    clipBehavior: Clip.none,
                                    children: [
                                      Positioned(
                                        bottom: 0,
                                        child: Container(
                                          width: 106.8,
                                          height: 14.3,
                                          decoration: BoxDecoration(
                                            border: Border(
                                              bottom: BorderSize(
                                                color: Color(0xFFAA9D9D),
                                                width: 1,
                                              ),
                                            ),
                                          ),
                                        ),
                                      ),
                                      Text(
                                        '11/12/2022',
                                        style: GoogleFonts.getFont(
                                          'Fira Sans Condensed',
                                          fontWeight: FontWeight.w500,
                                          fontSize: 10,
                                          color: Color(0xFF3E3636),
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                              ),
                            ),
                          ),
                          Align(
                            alignment: Alignment.topLeft,
                            child: SizedBox(
                              width: 106.8,
                              child: Container(
                                padding: EdgeInsets.fromLTRB(0, 0, 4.2, 4),
                                child: Stack(
                                  clipBehavior: Clip.none,
                                  children: [
                                    Positioned(
                                      bottom: 0,
                                      child: Container(
                                        width: 106.8,
                                        height: 14.3,
                                        decoration: BoxDecoration(
                                          border: Border(
                                            bottom: BorderSize(
                                              color: Color(0xFFAA9D9D),
                                              width: 1,
                                            ),
                                          ),
                                        ),
                                      ),
                                    ),
                                    Text(
                                      '11/12/2022',
                                      style: GoogleFonts.getFont(
                                        'Fira Sans Condensed',
                                        fontWeight: FontWeight.w500,
                                        fontSize: 10,
                                        color: Color(0xFF3E3636),
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ),
              ),
              Positioned(
                left: 398,
                top: 353,
                child: ImageFiltered(
                  imageFilter: ImageFilter.blur(
                    sigmaX: 2,
                    sigmaY: 2,
                  ),
                  child: SizedBox(
                    width: 130.4,
                    height: 66,
                    child: Container(
                      padding: EdgeInsets.fromLTRB(0, 0, 0, 0),
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.start,
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Container(
                            margin: EdgeInsets.fromLTRB(0, 0, 0, 6.7),
                            child: Align(
                              alignment: Alignment.topLeft,
                              child: Container(
                                decoration: BoxDecoration(
                                  color: Color(0xFF4228D7),
                                ),
                                child: Container(
                                  padding: EdgeInsets.fromLTRB(2.9, 2.4, 2.9, 5.9),
                                  child: Stack(
                                    clipBehavior: Clip.none,
                                    children: [
                                      Text(
                                        'Data de entrega',
                                        style: GoogleFonts.getFont(
                                          'Fira Sans Condensed',
                                          fontWeight: FontWeight.w600,
                                          fontSize: 10,
                                          color: Color(0xFFFFFFFF),
                                        ),
                                      ),
                                      Positioned(
                                        bottom: -5.9,
                                        child: Container(
                                          decoration: BoxDecoration(
                                            color: Color(0xFF4228D7),
                                          ),
                                          child: Container(
                                            width: 106.8,
                                            height: 20.3,
                                            padding: EdgeInsets.fromLTRB(19.1, 4, 19.1, 4.3),
                                            child: Text(
                                              'Data de entrega',
                                              style: GoogleFonts.getFont(
                                                'Fira Sans Condensed',
                                                fontWeight: FontWeight.w600,
                                                fontSize: 10,
                                                color: Color(0xFFFFFFFF),
                                              ),
                                            ),
                                          ),
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                              ),
                            ),
                          ),
                          Container(
                            margin: EdgeInsets.fromLTRB(0, 0, 0, 7),
                            child: Align(
                              alignment: Alignment.topLeft,
                              child: SizedBox(
                                width: 106.8,
                                child: Container(
                                  padding: EdgeInsets.fromLTRB(6.9, 0, 0, 4),
                                  child: Stack(
                                    clipBehavior: Clip.none,
                                    children: [
                                      Positioned(
                                        bottom: -4,
                                        child: Container(
                                          width: 106.8,
                                          height: 14.3,
                                          decoration: BoxDecoration(
                                            border: Border(
                                              bottom: BorderSize(
                                                color: Color(0xFFAA9D9D),
                                                width: 1,
                                              ),
                                            ),
                                          ),
                                        ),
                                      ),
                                      Text(
                                        '17/12/2022',
                                        style: GoogleFonts.getFont(
                                          'Fira Sans Condensed',
                                          fontWeight: FontWeight.w500,
                                          fontSize: 10,
                                          color: Color(0xFF3E3636),
                                        ),
                                      ),
                                      Positioned(
                                        bottom: -4,
                                        child: Container(
                                          width: 106.8,
                                          height: 14.3,
                                          child: Container(
                                            width: 106.8,
                                            height: 14.3,
                                            decoration: BoxDecoration(
                                              border: Border(
                                                bottom: BorderSize(
                                                  color: Color(0xFFAA9D9D),
                                                  width: 1,
                                                ),
                                              ),
                                            ),
                                          ),
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                              ),
                            ),
                          ),
                          Align(
                            alignment: Alignment.topLeft,
                            child: SizedBox(
                              width: 106.8,
                              child: Container(
                                padding: EdgeInsets.fromLTRB(6.9, 0, 0, 4),
                                child: Stack(
                                  clipBehavior: Clip.none,
                                  children: [
                                    Positioned(
                                      bottom: -4,
                                      child: Container(
                                        width: 106.8,
                                        height: 14.3,
                                        decoration: BoxDecoration(
                                          border: Border(
                                            bottom: BorderSize(
                                              color: Color(0xFFAA9D9D),
                                              width: 1,
                                            ),
                                          ),
                                        ),
                                      ),
                                    ),
                                    Text(
                                      '17/12/2022',
                                      style: GoogleFonts.getFont(
                                        'Fira Sans Condensed',
                                        fontWeight: FontWeight.w500,
                                        fontSize: 10,
                                        color: Color(0xFF3E3636),
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ),
              ),
              Positioned(
                left: 506.3,
                top: 353,
                child: ImageFiltered(
                  imageFilter: ImageFilter.blur(
                    sigmaX: 2,
                    sigmaY: 2,
                  ),
                  child: SizedBox(
                    width: 182,
                    height: 66,
                    child: Container(
                      padding: EdgeInsets.fromLTRB(0, 0, 0, 0),
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.start,
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Container(
                            margin: EdgeInsets.fromLTRB(0, 0, 0, 7.7),
                            child: Align(
                              alignment: Alignment.topLeft,
                              child: Container(
                                decoration: BoxDecoration(
                                  color: Color(0xFF4228D7),
                                ),
                                child: Container(
                                  width: 126.5,
                                  padding: EdgeInsets.fromLTRB(3.3, 4, 0, 4.3),
                                  child: Text(
                                    'Setor',
                                    style: GoogleFonts.getFont(
                                      'Fira Sans Condensed',
                                      fontWeight: FontWeight.w600,
                                      fontSize: 10,
                                      color: Color(0xFFFFFFFF),
                                    ),
                                  ),
                                ),
                              ),
                            ),
                          ),
                          Container(
                            margin: EdgeInsets.fromLTRB(0, 0, 0, 8),
                            child: Align(
                              alignment: Alignment.topLeft,
                              child: SizedBox(
                                width: 126.5,
                                child: Container(
                                  padding: EdgeInsets.fromLTRB(5.3, 0, 0, 3),
                                  child: Stack(
                                    clipBehavior: Clip.none,
                                    children: [
                                      Positioned(
                                        bottom: -3,
                                        child: Container(
                                          width: 126.5,
                                          height: 14.3,
                                          decoration: BoxDecoration(
                                            border: Border(
                                              bottom: BorderSize(
                                                color: Color(0xFFAA9D9D),
                                                width: 1,
                                              ),
                                            ),
                                          ),
                                        ),
                                      ),
                                      Text(
                                        'Bloco C',
                                        style: GoogleFonts.getFont(
                                          'Fira Sans Condensed',
                                          fontWeight: FontWeight.w500,
                                          fontSize: 10,
                                          color: Color(0xFF3E3636),
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                              ),
                            ),
                          ),
                          Align(
                            alignment: Alignment.topLeft,
                            child: SizedBox(
                              width: 126.5,
                              child: Container(
                                padding: EdgeInsets.fromLTRB(5.3, 0, 0, 3),
                                child: Stack(
                                  clipBehavior: Clip.none,
                                  children: [
                                    Positioned(
                                      bottom: -3,
                                      child: Container(
                                        width: 126.5,
                                        height: 14.3,
                                        decoration: BoxDecoration(
                                          border: Border(
                                            bottom: BorderSize(
                                              color: Color(0xFFAA9D9D),
                                              width: 1,
                                            ),
                                          ),
                                        ),
                                      ),
                                    ),
                                    Text(
                                      'Bloco C',
                                      style: GoogleFonts.getFont(
                                        'Fira Sans Condensed',
                                        fontWeight: FontWeight.w500,
                                        fontSize: 10,
                                        color: Color(0xFF3E3636),
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ),
              ),
              Positioned(
                right: 596.4,
                top: 353,
                child: ImageFiltered(
                  imageFilter: ImageFilter.blur(
                    sigmaX: 2,
                    sigmaY: 2,
                  ),
                  child: SizedBox(
                    width: 196,
                    height: 66,
                    child: Container(
                      padding: EdgeInsets.fromLTRB(0, 0, 0, 0),
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.start,
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Container(
                            margin: EdgeInsets.fromLTRB(0, 0, 0, 7.7),
                            child: Align(
                              alignment: Alignment.topLeft,
                              child: Container(
                                decoration: BoxDecoration(
                                  color: Color(0xFF4228D7),
                                ),
                                child: Container(
                                  width: 144.6,
                                  padding: EdgeInsets.fromLTRB(2.3, 4, 0, 4.3),
                                  child: Text(
                                    'Requerente',
                                    style: GoogleFonts.getFont(
                                      'Fira Sans Condensed',
                                      fontWeight: FontWeight.w600,
                                      fontSize: 10,
                                      color: Color(0xFFFFFFFF),
                                    ),
                                  ),
                                ),
                              ),
                            ),
                          ),
                          Container(
                            margin: EdgeInsets.fromLTRB(0, 0, 0, 8),
                            child: Align(
                              alignment: Alignment.topLeft,
                              child: SizedBox(
                                width: 144.6,
                                child: Container(
                                  padding: EdgeInsets.fromLTRB(0, 0, 2.2, 3),
                                  child: Stack(
                                    clipBehavior: Clip.none,
                                    children: [
                                      Positioned(
                                        bottom: 0,
                                        child: Container(
                                          width: 144.6,
                                          height: 14.3,
                                          decoration: BoxDecoration(
                                            border: Border(
                                              bottom: BorderSize(
                                                color: Color(0xFFAA9D9D),
                                                width: 1,
                                              ),
                                            ),
                                          ),
                                        ),
                                      ),
                                      Text(
                                        'Germano',
                                        style: GoogleFonts.getFont(
                                          'Fira Sans Condensed',
                                          fontWeight: FontWeight.w500,
                                          fontSize: 10,
                                          color: Color(0xFF3E3636),
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                              ),
                            ),
                          ),
                          Container(
                            margin: EdgeInsets.fromLTRB(0, 0, 0, 0),
                            child: Align(
                              alignment: Alignment.topLeft,
                              child: SizedBox(
                                width: 144.6,
                                child: Container(
                                  padding: EdgeInsets.fromLTRB(0, 0, 2.2, 3),
                                  child: Stack(
                                    clipBehavior: Clip.none,
                                    children: [
                                      Positioned(
                                        bottom: 0,
                                        child: Container(
                                          width: 144.6,
                                          height: 14.3,
                                          decoration: BoxDecoration(
                                            border: Border(
                                              bottom: BorderSize(
                                                color: Color(0xFFAA9D9D),
                                                width: 1,
                                              ),
                                            ),
                                          ),
                                        ),
                                      ),
                                      Text(
                                        'Germano',
                                        style: GoogleFonts.getFont(
                                          'Fira Sans Condensed',
                                          fontWeight: FontWeight.w500,
                                          fontSize: 10,
                                          color: Color(0xFF3E3636),
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ),
              ),
              Positioned(
                right: 456.4,
                top: 353,
                child: ImageFiltered(
                  imageFilter: ImageFilter.blur(
                    sigmaX: 2,
                    sigmaY: 2,
                  ),
                  child: SizedBox(
                    width: 189.6,
                    height: 66,
                    child: Container(
                      padding: EdgeInsets.fromLTRB(0, 0, 0, 0),
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.start,
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Container(
                            margin: EdgeInsets.fromLTRB(0, 0, 0, 7.7),
                            child: Align(
                              alignment: Alignment.topLeft,
                              child: Container(
                                decoration: BoxDecoration(
                                  color: Color(0xFF4228D7),
                                ),
                                child: Container(
                                  width: 144.6,
                                  padding: EdgeInsets.fromLTRB(0, 4, 4, 4.3),
                                  child: Text(
                                    'Equipamento',
                                    style: GoogleFonts.getFont(
                                      'Fira Sans Condensed',
                                      fontWeight: FontWeight.w600,
                                      fontSize: 10,
                                      color: Color(0xFFFFFFFF),
                                    ),
                                  ),
                                ),
                              ),
                            ),
                          ),
                          Container(
                            margin: EdgeInsets.fromLTRB(0, 0, 0, 8),
                            child: Align(
                              alignment: Alignment.topLeft,
                              child: SizedBox(
                                width: 144.6,
                                child: Container(
                                  padding: EdgeInsets.fromLTRB(0, 0, 3.2, 3),
                                  child: Stack(
                                    clipBehavior: Clip.none,
                                    children: [
                                      Positioned(
                                        bottom: 0,
                                        child: Container(
                                          width: 144.6,
                                          height: 14.3,
                                          decoration: BoxDecoration(
                                            border: Border(
                                              bottom: BorderSize(
                                                color: Color(0xFFAA9D9D),
                                                width: 1,
                                              ),
                                            ),
                                          ),
                                        ),
                                      ),
                                      Text(
                                        'Microfone',
                                        style: GoogleFonts.getFont(
                                          'Fira Sans Condensed',
                                          fontWeight: FontWeight.w500,
                                          fontSize: 10,
                                          color: Color(0xFF3E3636),
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                              ),
                            ),
                          ),
                          Container(
                            margin: EdgeInsets.fromLTRB(0, 0, 0, 0),
                            child: Align(
                              alignment: Alignment.topLeft,
                              child: SizedBox(
                                width: 144.6,
                                child: Container(
                                  padding: EdgeInsets.fromLTRB(0, 0, 7, 3),
                                  child: Stack(
                                    clipBehavior: Clip.none,
                                    children: [
                                      Positioned(
                                        bottom: 0,
                                        child: Container(
                                          width: 144.6,
                                          height: 14.3,
                                          decoration: BoxDecoration(
                                            border: Border(
                                              bottom: BorderSize(
                                                color: Color(0xFFAA9D9D),
                                                width: 1,
                                              ),
                                            ),
                                          ),
                                        ),
                                      ),
                                      Text(
                                        'Cabo P10',
                                        style: GoogleFonts.getFont(
                                          'Fira Sans Condensed',
                                          fontWeight: FontWeight.w500,
                                          fontSize: 10,
                                          color: Color(0xFF3E3636),
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ),
              ),
              Positioned(
                right: 315.4,
                top: 353,
                child: ImageFiltered(
                  imageFilter: ImageFilter.blur(
                    sigmaX: 2,
                    sigmaY: 2,
                  ),
                  child: SizedBox(
                    width: 184.2,
                    height: 66.3,
                    child: Container(
                      padding: EdgeInsets.fromLTRB(0, 0, 0, 0.3),
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.start,
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Container(
                            margin: EdgeInsets.fromLTRB(0, 0, 0, 8.4),
                            child: Align(
                              alignment: Alignment.topLeft,
                              child: Container(
                                decoration: BoxDecoration(
                                  color: Color(0xFF4228D7),
                                ),
                                child: SizedBox(
                                  width: 144.6,
                                  child: Container(
                                    padding: EdgeInsets.fromLTRB(0, 3.6, 19.3, 4.7),
                                    child: Stack(
                                      clipBehavior: Clip.none,
                                      children: [
                                        Text(
                                          'Nº Patrimônio',
                                          style: GoogleFonts.getFont(
                                            'Fira Sans Condensed',
                                            fontWeight: FontWeight.w600,
                                            fontSize: 10,
                                            color: Color(0xFFFFFFFF),
                                          ),
                                        ),
                                        Positioned(
                                          bottom: 0,
                                          child: Container(
                                            decoration: BoxDecoration(
                                              color: Color(0xFF4228D7),
                                            ),
                                            child: Container(
                                              width: 144.6,
                                              height: 20.3,
                                              padding: EdgeInsets.fromLTRB(0, 4, 10.9, 4.3),
                                              child: Text(
                                                'Nº Patrimônio',
                                                style: GoogleFonts.getFont(
                                                  'Fira Sans Condensed',
                                                  fontWeight: FontWeight.w600,
                                                  fontSize: 10,
                                                  color: Color(0xFFFFFFFF),
                                                ),
                                              ),
                                            ),
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                ),
                              ),
                            ),
                          ),
                          Container(
                            margin: EdgeInsets.fromLTRB(0, 0, 0, 8.7),
                            child: Align(
                              alignment: Alignment.topLeft,
                              child: Container(
                                width: 144.6,
                                decoration: BoxDecoration(
                                  border: Border(
                                    bottom: BorderSize(
                                      color: Color(0xFFAA9D9D),
                                      width: 1,
                                    ),
                                  ),
                                ),
                                child: Container(
                                  padding: EdgeInsets.fromLTRB(0, 0.3, 9.5, 2),
                                  child: Stack(
                                    clipBehavior: Clip.none,
                                    children: [
                                      Text(
                                        'MIC409',
                                        style: GoogleFonts.getFont(
                                          'Fira Sans Condensed',
                                          fontWeight: FontWeight.w500,
                                          fontSize: 10,
                                          color: Color(0xFF3E3636),
                                        ),
                                      ),
                                      Positioned(
                                        bottom: 0,
                                        child: Container(
                                          width: 144.6,
                                          height: 14.3,
                                          child: Container(
                                            width: 144.6,
                                            height: 14.3,
                                            decoration: BoxDecoration(
                                              border: Border(
                                                bottom: BorderSize(
                                                  color: Color(0xFFAA9D9D),
                                                  width: 1,
                                                ),
                                              ),
                                            ),
                                          ),
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                              ),
                            ),
                          ),
                          Align(
                            alignment: Alignment.topLeft,
                            child: Container(
                              width: 144.6,
                              padding: EdgeInsets.fromLTRB(0, 0.3, 8.7, 2),
                              decoration: BoxDecoration(
                                border: Border(
                                  bottom: BorderSize(
                                    color: Color(0xFFAA9D9D),
                                    width: 1,
                                  ),
                                ),
                              ),
                              child: Text(
                                'CAB010',
                                style: GoogleFonts.getFont(
                                  'Fira Sans Condensed',
                                  fontWeight: FontWeight.w500,
                                  fontSize: 10,
                                  color: Color(0xFF3E3636),
                                ),
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ),
              ),
              Positioned(
                right: 154.4,
                top: 353,
                child: ImageFiltered(
                  imageFilter: ImageFilter.blur(
                    sigmaX: 2,
                    sigmaY: 2,
                  ),
                  child: SizedBox(
                    width: 198.9,
                    height: 66,
                    child: Container(
                      padding: EdgeInsets.fromLTRB(0, 0, 0, 0),
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.start,
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Container(
                            margin: EdgeInsets.fromLTRB(0, 0, 0, 6.7),
                            child: Align(
                              alignment: Alignment.topLeft,
                              child: Container(
                                decoration: BoxDecoration(
                                  color: Color(0xFF4228D7),
                                ),
                                child: SizedBox(
                                  width: 144.6,
                                  child: Container(
                                    padding: EdgeInsets.fromLTRB(0, 3.6, 19.3, 4.7),
                                    child: Stack(
                                      clipBehavior: Clip.none,
                                      children: [
                                        Text(
                                          'Nº Patrimônio',
                                          style: GoogleFonts.getFont(
                                            'Fira Sans Condensed',
                                            fontWeight: FontWeight.w600,
                                            fontSize: 10,
                                            color: Color(0xFFFFFFFF),
                                          ),
                                        ),
                                        Positioned(
                                          bottom: 0,
                                          child: Container(
                                            decoration: BoxDecoration(
                                              color: Color(0xFF4228D7),
                                            ),
                                            child: Container(
                                              width: 144.6,
                                              height: 20.3,
                                              padding: EdgeInsets.fromLTRB(12.2, 4, 0, 4.3),
                                              child: Text(
                                                'Responsavel',
                                                style: GoogleFonts.getFont(
                                                  'Fira Sans Condensed',
                                                  fontWeight: FontWeight.w600,
                                                  fontSize: 10,
                                                  color: Color(0xFFFFFFFF),
                                                ),
                                              ),
                                            ),
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                ),
                              ),
                            ),
                          ),
                          Container(
                            margin: EdgeInsets.fromLTRB(0, 0, 0, 7),
                            child: Align(
                              alignment: Alignment.topLeft,
                              child: SizedBox(
                                width: 144.6,
                                child: Container(
                                  padding: EdgeInsets.fromLTRB(17.3, 0, 0, 4),
                                  child: Stack(
                                    clipBehavior: Clip.none,
                                    children: [
                                      Positioned(
                                        bottom: -4,
                                        child: Container(
                                          width: 144.6,
                                          height: 14.3,
                                          decoration: BoxDecoration(
                                            border: Border(
                                              bottom: BorderSize(
                                                color: Color(0xFFAA9D9D),
                                                width: 1,
                                              ),
                                            ),
                                          ),
                                        ),
                                      ),
                                      Text(
                                        'Waltair',
                                        style: GoogleFonts.getFont(
                                          'Fira Sans Condensed',
                                          fontWeight: FontWeight.w500,
                                          fontSize: 10,
                                          color: Color(0xFF3E3636),
                                        ),
                                      ),
                                      Positioned(
                                        bottom: -4,
                                        child: Container(
                                          width: 144.6,
                                          height: 14.3,
                                          child: Container(
                                            width: 144.6,
                                            height: 14.3,
                                            decoration: BoxDecoration(
                                              border: Border(
                                                bottom: BorderSize(
                                                  color: Color(0xFFAA9D9D),
                                                  width: 1,
                                                ),
                                              ),
                                            ),
                                          ),
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                              ),
                            ),
                          ),
                          Align(
                            alignment: Alignment.topLeft,
                            child: SizedBox(
                              width: 144.6,
                              child: Container(
                                padding: EdgeInsets.fromLTRB(17.3, 0, 0, 4),
                                child: Stack(
                                  clipBehavior: Clip.none,
                                  children: [
                                    Positioned(
                                      bottom: -4,
                                      child: Container(
                                        width: 144.6,
                                        height: 14.3,
                                        decoration: BoxDecoration(
                                          border: Border(
                                            bottom: BorderSize(
                                              color: Color(0xFFAA9D9D),
                                              width: 1,
                                            ),
                                          ),
                                        ),
                                      ),
                                    ),
                                    Text(
                                      'Waltair',
                                      style: GoogleFonts.getFont(
                                        'Fira Sans Condensed',
                                        fontWeight: FontWeight.w500,
                                        fontSize: 10,
                                        color: Color(0xFF3E3636),
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ),
              ),
              Positioned(
                right: 48.8,
                top: 353,
                child: ImageFiltered(
                  imageFilter: ImageFilter.blur(
                    sigmaX: 2,
                    sigmaY: 2,
                  ),
                  child: SizedBox(
                    width: 158.2,
                    height: 66,
                    child: Container(
                      padding: EdgeInsets.fromLTRB(0, 0, 0, 0),
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.start,
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Container(
                            margin: EdgeInsets.fromLTRB(0.1, 0, 0.1, 6.7),
                            child: Align(
                              alignment: Alignment.topLeft,
                              child: Container(
                                decoration: BoxDecoration(
                                  color: Color(0xFF4228D7),
                                ),
                                child: Container(
                                  width: 114.6,
                                  padding: EdgeInsets.fromLTRB(5.1, 4, 0, 4.3),
                                  child: Text(
                                    'Situação',
                                    style: GoogleFonts.getFont(
                                      'Fira Sans Condensed',
                                      fontWeight: FontWeight.w600,
                                      fontSize: 10,
                                      color: Color(0xFFFFFFFF),
                                    ),
                                  ),
                                ),
                              ),
                            ),
                          ),
                          Container(
                            margin: EdgeInsets.fromLTRB(0.1, 0, 0.1, 7),
                            child: Align(
                              alignment: Alignment.topLeft,
                              child: SizedBox(
                                width: 114.6,
                                child: Container(
                                  padding: EdgeInsets.fromLTRB(8.7, 0, 0, 4),
                                  child: Stack(
                                    clipBehavior: Clip.none,
                                    children: [
                                      Positioned(
                                        bottom: -4,
                                        child: Container(
                                          width: 114.6,
                                          height: 14.3,
                                          decoration: BoxDecoration(
                                            border: Border(
                                              bottom: BorderSize(
                                                color: Color(0xFFAA9D9D),
                                                width: 1,
                                              ),
                                            ),
                                          ),
                                        ),
                                      ),
                                      Text(
                                        'Reservado',
                                        style: GoogleFonts.getFont(
                                          'Fira Sans Condensed',
                                          fontWeight: FontWeight.w500,
                                          fontSize: 10,
                                          color: Color(0xFF3E3636),
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                              ),
                            ),
                          ),
                          Align(
                            alignment: Alignment.topLeft,
                            child: SizedBox(
                              width: 114.6,
                              child: Container(
                                padding: EdgeInsets.fromLTRB(8.7, 0, 0, 4),
                                child: Stack(
                                  clipBehavior: Clip.none,
                                  children: [
                                    Positioned(
                                      bottom: -4,
                                      child: Container(
                                        width: 114.6,
                                        height: 14.3,
                                        decoration: BoxDecoration(
                                          border: Border(
                                            bottom: BorderSize(
                                              color: Color(0xFFAA9D9D),
                                              width: 1,
                                            ),
                                          ),
                                        ),
                                      ),
                                    ),
                                    Text(
                                      'Reservado',
                                      style: GoogleFonts.getFont(
                                        'Fira Sans Condensed',
                                        fontWeight: FontWeight.w500,
                                        fontSize: 10,
                                        color: Color(0xFF3E3636),
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ),
              ),
              Positioned(
                right: 167.3,
                top: 276,
                child: Container(
                  height: 286,
                  child: ClipRect(
                    child: BackdropFilter(
                      filter: ImageFilter.blur(
                        sigmaX: 2,
                        sigmaY: 2,
                      ),
                      child: Container(
                        decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(10),
                          boxShadow: [
                            BoxShadow(
                              color: Color(0x40000000),
                              offset: Offset(0, 4),
                              blurRadius: 2,
                            ),
                          ],
                        ),
                        child: Stack(
                          children: [
                        Positioned(
                          left: -16.5,
                          top: -1,
                          child: SizedBox(
                            width: 898.2,
                            height: 31,
                            child: SvgPicture.asset(
                              'assets/vectors/group_81_x2.svg',
                            ),
                          ),
                        ),
                  Container(
                              padding: EdgeInsets.fromLTRB(16.5, 1, 12.7, 121.3),
                              child: Column(
                                mainAxisAlignment: MainAxisAlignment.start,
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Container(
                                    margin: EdgeInsets.fromLTRB(0, 0, 0, 9.2),
                                    child: Align(
                                      alignment: Alignment.topRight,
                                      child: SizedBox(
                                        width: 522.6,
                                        child: Row(
                                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                          crossAxisAlignment: CrossAxisAlignment.start,
                                          children: [
                                            Container(
                                              margin: EdgeInsets.fromLTRB(0, 0, 12, 4),
                                              child: SizedBox(
                                                width: 477.6,
                                                child: Text(
                                                  'RESERVA RAPIDA',
                                                  style: GoogleFonts.getFont(
                                                    'Inter',
                                                    fontWeight: FontWeight.w600,
                                                    fontSize: 20,
                                                    color: Color(0xFFFFFFFF),
                                                  ),
                                                ),
                                              ),
                                            ),
                                            Container(
                                              decoration: BoxDecoration(
                                                color: Color(0xFF22127B),
                                              ),
                                              child: Container(
                                                padding: EdgeInsets.fromLTRB(8, 2, 12.2, 2),
                                                child: Text(
                                                  'X',
                                                  style: GoogleFonts.getFont(
                                                    'Inter',
                                                    fontWeight: FontWeight.w400,
                                                    fontSize: 20,
                                                    color: Color(0xFFFFFFFF),
                                                  ),
                                                ),
                                              ),
                                            ),
                                          ],
                                        ),
                                      ),
                                    ),
                                  ),
                                  Container(
                                    margin: EdgeInsets.fromLTRB(0, 0, 12.7, 23),
                                    child: Row(
                                      mainAxisAlignment: MainAxisAlignment.start,
                                      crossAxisAlignment: CrossAxisAlignment.start,
                                      children: [
                                        Container(
                                          margin: EdgeInsets.fromLTRB(0, 0, 27.6, 0.3),
                                          child: Column(
                                            mainAxisAlignment: MainAxisAlignment.start,
                                            crossAxisAlignment: CrossAxisAlignment.start,
                                            children: [
                                              Container(
                                                margin: EdgeInsets.fromLTRB(0, 0, 0, 2.7),
                                                child: Align(
                                                  alignment: Alignment.topLeft,
                                                  child: Text(
                                                    'Requerente',
                                                    style: GoogleFonts.getFont(
                                                      'Fira Sans Condensed',
                                                      fontWeight: FontWeight.w600,
                                                      fontSize: 10,
                                                      color: Color(0xFF000000),
                                                    ),
                                                  ),
                                                ),
                                              ),
                                              Container(
                                                decoration: BoxDecoration(
                                                  border: Border.all(color: Color(0xFFAAA1A1)),
                                                  color: Color(0xFFFFFFFF),
                                                ),
                                                child: SizedBox(
                                                  width: 193.4,
                                                  child: Container(
                                                    padding: EdgeInsets.fromLTRB(10.3, 4.4, 0, 4.4),
                                                    child: Row(
                                                      mainAxisAlignment: MainAxisAlignment.start,
                                                      crossAxisAlignment: CrossAxisAlignment.start,
                                                      children: [
                                                        Container(
                                                          margin: EdgeInsets.fromLTRB(0, 1, 10.1, 1.9),
                                                          child: SizedBox(
                                                            width: 20.6,
                                                            height: 25.2,
                                                            child: SvgPicture.asset(
                                                              'assets/vectors/vector_389_x2.svg',
                                                            ),
                                                          ),
                                                        ),
                                                        Container(
                                                          margin: EdgeInsets.fromLTRB(0, 0, 25.5, 0),
                                                          child: Container(
                                                            decoration: BoxDecoration(
                                                              color: Color(0xFFAA9D9D),
                                                            ),
                                                            child: Container(
                                                              width: 1,
                                                              height: 28,
                                                            ),
                                                          ),
                                                        ),
                                                        Container(
                                                          margin: EdgeInsets.fromLTRB(0, 5, 0, 8),
                                                          child: Text(
                                                            'Germano',
                                                            style: GoogleFonts.getFont(
                                                              'Inter',
                                                              fontWeight: FontWeight.w400,
                                                              fontSize: 12,
                                                              color: Color(0xFF000000),
                                                            ),
                                                          ),
                                                        ),
                                                      ],
                                                    ),
                                                  ),
                                                ),
                                              ),
                                            ],
                                          ),
                                        ),
                                        Container(
                                          margin: EdgeInsets.fromLTRB(0, 0, 27.6, 0.3),
                                          child: Column(
                                            mainAxisAlignment: MainAxisAlignment.start,
                                            crossAxisAlignment: CrossAxisAlignment.start,
                                            children: [
                                              Container(
                                                margin: EdgeInsets.fromLTRB(0, 0, 0, 2.7),
                                                child: Align(
                                                  alignment: Alignment.topLeft,
                                                  child: Text(
                                                    'Data de inicio',
                                                    style: GoogleFonts.getFont(
                                                      'Fira Sans Condensed',
                                                      fontWeight: FontWeight.w600,
                                                      fontSize: 10,
                                                      color: Color(0xFF000000),
                                                    ),
                                                  ),
                                                ),
                                              ),
                                              Container(
                                                decoration: BoxDecoration(
                                                  border: Border.all(color: Color(0xFFAAA1A1)),
                                                  color: Color(0xFFFFFFFF),
                                                ),
                                                child: SizedBox(
                                                  width: 193.4,
                                                  child: Container(
                                                    padding: EdgeInsets.fromLTRB(10.3, 4.4, 0, 4.4),
                                                    child: Row(
                                                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                                      crossAxisAlignment: CrossAxisAlignment.start,
                                                      children: [
                                                        SizedBox(
                                                          width: 31.7,
                                                          child: Row(
                                                            mainAxisAlignment: MainAxisAlignment.start,
                                                            crossAxisAlignment: CrossAxisAlignment.start,
                                                            children: [
                                                              Container(
                                                                margin: EdgeInsets.fromLTRB(0, 1, 10.1, 1.9),
                                                                child: SizedBox(
                                                                  width: 20.6,
                                                                  height: 25.2,
                                                                  child: SvgPicture.asset(
                                                                    'assets/vectors/vector_187_x2.svg',
                                                                  ),
                                                                ),
                                                              ),
                                                              Container(
                                                                decoration: BoxDecoration(
                                                                  color: Color(0xFFAA9D9D),
                                                                ),
                                                                child: Container(
                                                                  width: 1,
                                                                  height: 28,
                                                                ),
                                                              ),
                                                            ],
                                                          ),
                                                        ),
                                                        Container(
                                                          margin: EdgeInsets.fromLTRB(0, 5, 0, 8),
                                                          child: Text(
                                                            '25/11/2022',
                                                            style: GoogleFonts.getFont(
                                                              'Inter',
                                                              fontWeight: FontWeight.w400,
                                                              fontSize: 12,
                                                              color: Color(0xFF000000),
                                                            ),
                                                          ),
                                                        ),
                                                      ],
                                                    ),
                                                  ),
                                                ),
                                              ),
                                            ],
                                          ),
                                        ),
                                        Container(
                                          margin: EdgeInsets.fromLTRB(0, 0.3, 27.9, 0),
                                          child: Column(
                                            mainAxisAlignment: MainAxisAlignment.start,
                                            crossAxisAlignment: CrossAxisAlignment.start,
                                            children: [
                                              Container(
                                                margin: EdgeInsets.fromLTRB(0, 0, 0, 2.7),
                                                child: Align(
                                                  alignment: Alignment.topLeft,
                                                  child: Text(
                                                    'Data de entrega',
                                                    style: GoogleFonts.getFont(
                                                      'Fira Sans Condensed',
                                                      fontWeight: FontWeight.w600,
                                                      fontSize: 10,
                                                      color: Color(0xFF000000),
                                                    ),
                                                  ),
                                                ),
                                              ),
                                              Container(
                                                decoration: BoxDecoration(
                                                  border: Border.all(color: Color(0xFFAAA1A1)),
                                                  color: Color(0xFFFFFFFF),
                                                ),
                                                child: SizedBox(
                                                  width: 193.4,
                                                  child: Container(
                                                    padding: EdgeInsets.fromLTRB(10.3, 4.4, 0, 4.4),
                                                    child: Row(
                                                      mainAxisAlignment: MainAxisAlignment.start,
                                                      crossAxisAlignment: CrossAxisAlignment.start,
                                                      children: [
                                                        Container(
                                                          margin: EdgeInsets.fromLTRB(0, 1, 10.1, 1.9),
                                                          child: SizedBox(
                                                            width: 20.6,
                                                            height: 25.2,
                                                            child: SvgPicture.asset(
                                                              'assets/vectors/vector_394_x2.svg',
                                                            ),
                                                          ),
                                                        ),
                                                        Container(
                                                          margin: EdgeInsets.fromLTRB(0, 0, 26.1, 0),
                                                          child: Container(
                                                            decoration: BoxDecoration(
                                                              color: Color(0xFFAA9D9D),
                                                            ),
                                                            child: Container(
                                                              width: 1,
                                                              height: 28,
                                                            ),
                                                          ),
                                                        ),
                                                        Container(
                                                          margin: EdgeInsets.fromLTRB(0, 4.8, 0, 8.2),
                                                          child: Text(
                                                            '30/11/2022',
                                                            style: GoogleFonts.getFont(
                                                              'Inter',
                                                              fontWeight: FontWeight.w400,
                                                              fontSize: 12,
                                                              color: Color(0xFF000000),
                                                            ),
                                                          ),
                                                        ),
                                                      ],
                                                    ),
                                                  ),
                                                ),
                                              ),
                                            ],
                                          ),
                                        ),
                                        Container(
                                          margin: EdgeInsets.fromLTRB(0, 0, 0, 0.3),
                                          child: Column(
                                            mainAxisAlignment: MainAxisAlignment.start,
                                            crossAxisAlignment: CrossAxisAlignment.start,
                                            children: [
                                              Container(
                                                margin: EdgeInsets.fromLTRB(0, 0, 0, 2.7),
                                                child: Align(
                                                  alignment: Alignment.topLeft,
                                                  child: Text(
                                                    'Setor',
                                                    style: GoogleFonts.getFont(
                                                      'Fira Sans Condensed',
                                                      fontWeight: FontWeight.w600,
                                                      fontSize: 10,
                                                      color: Color(0xFF000000),
                                                    ),
                                                  ),
                                                ),
                                              ),
                                              Container(
                                                decoration: BoxDecoration(
                                                  border: Border.all(color: Color(0xFFAAA1A1)),
                                                  color: Color(0xFFFFFFFF),
                                                ),
                                                child: SizedBox(
                                                  width: 193.4,
                                                  child: Container(
                                                    padding: EdgeInsets.fromLTRB(10.3, 4.4, 0, 4.4),
                                                    child: Row(
                                                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                                      crossAxisAlignment: CrossAxisAlignment.start,
                                                      children: [
                                                        SizedBox(
                                                          width: 31.7,
                                                          child: Row(
                                                            mainAxisAlignment: MainAxisAlignment.start,
                                                            crossAxisAlignment: CrossAxisAlignment.start,
                                                            children: [
                                                              Container(
                                                                margin: EdgeInsets.fromLTRB(0, 1, 10.1, 1.9),
                                                                child: SizedBox(
                                                                  width: 20.6,
                                                                  height: 25.2,
                                                                  child: SvgPicture.asset(
                                                                    'assets/vectors/vector_219_x2.svg',
                                                                  ),
                                                                ),
                                                              ),
                                                              Container(
                                                                decoration: BoxDecoration(
                                                                  color: Color(0xFFAA9D9D),
                                                                ),
                                                                child: Container(
                                                                  width: 1,
                                                                  height: 28,
                                                                ),
                                                              ),
                                                            ],
                                                          ),
                                                        ),
                                                        Container(
                                                          margin: EdgeInsets.fromLTRB(0, 6.2, 0, 6.8),
                                                          child: Text(
                                                            'Bloco C',
                                                            style: GoogleFonts.getFont(
                                                              'Inter',
                                                              fontWeight: FontWeight.w400,
                                                              fontSize: 12,
                                                              color: Color(0xFF000000),
                                                            ),
                                                          ),
                                                        ),
                                                      ],
                                                    ),
                                                  ),
                                                ),
                                              ),
                                            ],
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                  Container(
                                    margin: EdgeInsets.fromLTRB(2.1, 0, 2.1, 0),
                                    child: Align(
                                      alignment: Alignment.topLeft,
                                      child: SizedBox(
                                        width: 372.8,
                                        child: Row(
                                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                          crossAxisAlignment: CrossAxisAlignment.start,
                                          children: [
                                            Column(
                                              mainAxisAlignment: MainAxisAlignment.start,
                                              crossAxisAlignment: CrossAxisAlignment.start,
                                              children: [
                                                Container(
                                                  margin: EdgeInsets.fromLTRB(0, 0, 0, 2.7),
                                                  child: Align(
                                                    alignment: Alignment.topLeft,
                                                    child: Text(
                                                      'Equimento',
                                                      style: GoogleFonts.getFont(
                                                        'Fira Sans Condensed',
                                                        fontWeight: FontWeight.w600,
                                                        fontSize: 10,
                                                        color: Color(0xFF000000),
                                                      ),
                                                    ),
                                                  ),
                                                ),
                                                Container(
                                                  decoration: BoxDecoration(
                                                    border: Border.all(color: Color(0xFFAAA1A1)),
                                                    color: Color(0xFFFFFFFF),
                                                  ),
                                                  child: SizedBox(
                                                    width: 193.4,
                                                    child: Container(
                                                      padding: EdgeInsets.fromLTRB(10.3, 4.4, 0, 4.4),
                                                      child: Row(
                                                        mainAxisAlignment: MainAxisAlignment.start,
                                                        crossAxisAlignment: CrossAxisAlignment.start,
                                                        children: [
                                                          Container(
                                                            margin: EdgeInsets.fromLTRB(0, 1, 10.1, 1.9),
                                                            child: SizedBox(
                                                              width: 20.6,
                                                              height: 25.2,
                                                              child: SvgPicture.asset(
                                                                'assets/vectors/vector_97_x2.svg',
                                                              ),
                                                            ),
                                                          ),
                                                          Container(
                                                            margin: EdgeInsets.fromLTRB(0, 0, 23.4, 0),
                                                            child: Container(
                                                              decoration: BoxDecoration(
                                                                color: Color(0xFFAA9D9D),
                                                              ),
                                                              child: Container(
                                                                width: 1,
                                                                height: 28,
                                                              ),
                                                            ),
                                                          ),
                                                          Container(
                                                            margin: EdgeInsets.fromLTRB(0, 5, 0, 8),
                                                            child: Text(
                                                              'DataShow',
                                                              style: GoogleFonts.getFont(
                                                                'Inter',
                                                                fontWeight: FontWeight.w400,
                                                                fontSize: 12,
                                                                color: Color(0xFF000000),
                                                              ),
                                                            ),
                                                          ),
                                                        ],
                                                      ),
                                                    ),
                                                  ),
                                                ),
                                              ],
                                            ),
                                            Container(
                                              margin: EdgeInsets.fromLTRB(0, 18.9, 0, 0.7),
                                              child: Container(
                                                decoration: BoxDecoration(
                                                  color: Color(0xFF000041),
                                                ),
                                                child: SizedBox(
                                                  width: 112.5,
                                                  child: Container(
                                                    padding: EdgeInsets.fromLTRB(10, 7, 0, 7.7),
                                                    child: Row(
                                                      mainAxisAlignment: MainAxisAlignment.start,
                                                      crossAxisAlignment: CrossAxisAlignment.start,
                                                      children: [
                                                        Container(
                                                          margin: EdgeInsets.fromLTRB(0, 0, 9.2, 0),
                                                          child: SizedBox(
                                                            width: 18.8,
                                                            height: 17.3,
                                                            child: SvgPicture.asset(
                                                              'assets/vectors/vector_66_x2.svg',
                                                            ),
                                                          ),
                                                        ),
                                                        Container(
                                                          margin: EdgeInsets.fromLTRB(0, 4, 0, 1.3),
                                                          child: Text(
                                                            'Registrar',
                                                            style: GoogleFonts.getFont(
                                                              'Fira Sans Condensed',
                                                              fontWeight: FontWeight.w600,
                                                              fontSize: 10,
                                                              color: Color(0xFFFFFFFF),
                                                            ),
                                                          ),
                                                        ),
                                                      ],
                                                    ),
                                                  ),
                                                ),
                                              ),
                                            ),
                                          ],
                                        ),
                                      ),
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}