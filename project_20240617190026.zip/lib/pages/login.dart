import 'package:flutter/material.dart';
import 'dart:ui';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:flutter_app/utils.dart';
import 'package:google_fonts/google_fonts.dart';

class Login extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return 
    Container(
      decoration: BoxDecoration(
        color: Color(0xFF22127B),
      ),
      child: Container(
        decoration: BoxDecoration(
          color: Color(0xFF22127B),
        ),
        child: Stack(
          children: [
          Positioned(
            left: 416,
            top: 71,
            child: ClipRect(
              child: BackdropFilter(
                filter: ImageFilter.blur(
                  sigmaX: 2,
                  sigmaY: 2,
                ),
                child: Container(
                  decoration: BoxDecoration(
                    color: Color(0xFFFFFFFF),
                    borderRadius: BorderRadius.circular(13),
                  ),
                  child: Container(
                    width: 581,
                    height: 882,
                  ),
                ),
              ),
            ),
          ),
    SizedBox(
              width: 1440,
              child: Container(
                padding: EdgeInsets.fromLTRB(0, 138, 0, 299),
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.start,
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    Container(
                      margin: EdgeInsets.fromLTRB(0, 0, 0, 70),
                      child: Container(
                        decoration: BoxDecoration(
                          image: DecorationImage(
                            fit: BoxFit.cover,
                            image: AssetImage(
                              'assets/images/image_1.png',
                            ),
                          ),
                        ),
                        child: Container(
                          width: 411,
                          height: 187,
                        ),
                      ),
                    ),
                    Container(
                      margin: EdgeInsets.fromLTRB(0, 0, 0, 37.3),
                      child: ClipRect(
                        child: BackdropFilter(
                          filter: ImageFilter.blur(
                            sigmaX: 2,
                            sigmaY: 2,
                          ),
                          child: Stack(
                            children: [
                          Positioned(
                            top: -19.5,
                            child: Container(
                              decoration: BoxDecoration(
                                border: Border.all(color: Color(0xFF0D024C)),
                                borderRadius: BorderRadius.circular(5),
                                color: Color(0xFFFFFFFF),
                              ),
                              child: Container(
                                width: 491,
                                height: 68.3,
                              ),
                            ),
                          ),
                    Container(
                                padding: EdgeInsets.fromLTRB(16.2, 19.5, 16.2, 28.2),
                                child: Text(
                                  'EMAIL ADRESS',
                                  style: GoogleFonts.getFont(
                                    'Fira Sans Condensed',
                                    fontWeight: FontWeight.w600,
                                    fontSize: 24,
                                    color: Color(0x7D000000),
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),
                    ),
                    Container(
                      margin: EdgeInsets.fromLTRB(0, 0, 0, 0.1),
                      child: ClipRect(
                        child: BackdropFilter(
                          filter: ImageFilter.blur(
                            sigmaX: 2,
                            sigmaY: 2,
                          ),
                          child: Stack(
                            children: [
                          Positioned(
                            top: -20.7,
                            child: Container(
                              decoration: BoxDecoration(
                                border: Border.all(color: Color(0xFF0D024C)),
                                borderRadius: BorderRadius.circular(5),
                                color: Color(0xFFFFFFFF),
                              ),
                              child: Container(
                                width: 491,
                                height: 69,
                              ),
                            ),
                          ),
                    Container(
                                padding: EdgeInsets.fromLTRB(16.2, 20.7, 16.2, 28.2),
                                child: Text(
                                  'SENHA',
                                  style: GoogleFonts.getFont(
                                    'Fira Sans Condensed',
                                    fontWeight: FontWeight.w600,
                                    fontSize: 24,
                                    color: Color(0x7D000000),
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),
                    ),
                    Container(
                      margin: EdgeInsets.fromLTRB(0, 0, 304.5, 55),
                      child: Text(
                        'Esqueceu a senha?',
                        style: GoogleFonts.getFont(
                          'Fira Sans Condensed',
                          fontWeight: FontWeight.w600,
                          fontSize: 20,
                          color: Color(0xFF000000),
                        ),
                      ),
                    ),
                    Container(
                      margin: EdgeInsets.fromLTRB(19, 0, 0, 0),
                      decoration: BoxDecoration(
                        border: Border.all(color: Color(0xFF0D024C)),
                        borderRadius: BorderRadius.circular(5),
                        color: Color(0xFF0D024C),
                      ),
                      child: Container(
                        width: 174,
                        padding: EdgeInsets.fromLTRB(0, 17, 5.7, 18),
                        child: Text(
                          'Entrar',
                          style: GoogleFonts.getFont(
                            'Fira Sans Condensed',
                            fontWeight: FontWeight.w700,
                            fontSize: 20,
                            color: Color(0xFFFFFFFF),
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}