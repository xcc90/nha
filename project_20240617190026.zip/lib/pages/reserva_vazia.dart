import 'package:flutter/material.dart';
import 'dart:ui';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:flutter_app/utils.dart';
import 'package:google_fonts/google_fonts.dart';

class ReservaVazia extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return 
    Container(
      decoration: BoxDecoration(
        color: Color(0xFFFFFFFF),
      ),
      child: SizedBox(
        width: 1440,
        child: Container(
          padding: EdgeInsets.fromLTRB(7, 34, 0, 21),
          child: Stack(
            clipBehavior: Clip.none,
            children: [
              Column(
                mainAxisAlignment: MainAxisAlignment.start,
                crossAxisAlignment: CrossAxisAlignment.end,
                children: [
                  Container(
                    margin: EdgeInsets.fromLTRB(868.7, 0, 0, 33),
                    child: Align(
                      alignment: Alignment.topCenter,
                      child: Text(
                        'logado: Waltair',
                        style: GoogleFonts.getFont(
                          'Fira Sans Condensed',
                          fontWeight: FontWeight.w300,
                          fontSize: 16,
                          color: Color(0xFFFFFFFF),
                        ),
                      ),
                    ),
                  ),
                  Container(
                    margin: EdgeInsets.fromLTRB(1, 0, 0, 10),
                    child: SizedBox(
                      width: 1432,
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Container(
                            margin: EdgeInsets.fromLTRB(0, 15, 0, 0),
                            child: Row(
                              mainAxisAlignment: MainAxisAlignment.start,
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Container(
                                  margin: EdgeInsets.fromLTRB(0, 0, 8, 5),
                                  child: SizedBox(
                                    width: 18,
                                    height: 16,
                                    child: SvgPicture.asset(
                                      'assets/vectors/vector_392_x2.svg',
                                    ),
                                  ),
                                ),
                                Container(
                                  margin: EdgeInsets.fromLTRB(0, 2, 0, 0),
                                  child: Text(
                                    'inicio
                                ',
                                    style: GoogleFonts.getFont(
                                      'Fira Sans Condensed',
                                      fontWeight: FontWeight.w300,
                                      fontSize: 16,
                                      color: Color(0xFFFFFFFF),
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ),
                          Container(
                            decoration: BoxDecoration(
                              color: Color(0xFFD9D9D9),
                            ),
                            child: Container(
                              width: 1244,
                              height: 36,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                  Container(
                    margin: EdgeInsets.fromLTRB(0, 0, 31, 30),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.start,
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Container(
                          margin: EdgeInsets.fromLTRB(0, 0, 61, 62),
                          child: Column(
                            mainAxisAlignment: MainAxisAlignment.start,
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Container(
                                margin: EdgeInsets.fromLTRB(0, 0, 0.2, 13),
                                child: Row(
                                  mainAxisAlignment: MainAxisAlignment.start,
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Container(
                                      margin: EdgeInsets.fromLTRB(0, 5, 8, 0),
                                      child: SizedBox(
                                        width: 18,
                                        height: 16,
                                        child: SvgPicture.asset(
                                          'assets/vectors/vector_90_x2.svg',
                                        ),
                                      ),
                                    ),
                                    Container(
                                      margin: EdgeInsets.fromLTRB(0, 0, 0, 2),
                                      child: Text(
                                        'consultar reservas',
                                        style: GoogleFonts.getFont(
                                          'Fira Sans Condensed',
                                          fontWeight: FontWeight.w300,
                                          fontSize: 16,
                                          color: Color(0xFFFFFFFF),
                                        ),
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                              Container(
                                margin: EdgeInsets.fromLTRB(0.8, 0, 0, 10),
                                child: Row(
                                  mainAxisAlignment: MainAxisAlignment.start,
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Container(
                                      margin: EdgeInsets.fromLTRB(0, 2.5, 8.8, 1.5),
                                      child: SizedBox(
                                        width: 16.5,
                                        height: 15,
                                        child: SvgPicture.asset(
                                          'assets/vectors/vector_308_x2.svg',
                                        ),
                                      ),
                                    ),
                                    Text(
                                      'adicionar material',
                                      style: GoogleFonts.getFont(
                                        'Fira Sans Condensed',
                                        fontWeight: FontWeight.w300,
                                        fontSize: 16,
                                        color: Color(0xFFFFFFFF),
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                              Container(
                                margin: EdgeInsets.fromLTRB(1, 0, 6.6, 15),
                                child: Row(
                                  mainAxisAlignment: MainAxisAlignment.start,
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Container(
                                      margin: EdgeInsets.fromLTRB(0, 3, 8, 0),
                                      child: SizedBox(
                                        width: 17,
                                        height: 16,
                                        child: SvgPicture.asset(
                                          'assets/vectors/vector_358_x2.svg',
                                        ),
                                      ),
                                    ),
                                    Text(
                                      'adicionar reserva',
                                      style: GoogleFonts.getFont(
                                        'Fira Sans Condensed',
                                        fontWeight: FontWeight.w300,
                                        fontSize: 16,
                                        color: Color(0xFFFFFFFF),
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                              Container(
                                margin: EdgeInsets.fromLTRB(1, 0, 1, 0),
                                child: Align(
                                  alignment: Alignment.topLeft,
                                  child: Row(
                                    mainAxisAlignment: MainAxisAlignment.start,
                                    crossAxisAlignment: CrossAxisAlignment.start,
                                    children: [
                                      Container(
                                        margin: EdgeInsets.fromLTRB(0, 1, 10, 2),
                                        child: SizedBox(
                                          width: 15,
                                          height: 16,
                                          child: SvgPicture.asset(
                                            'assets/vectors/container_27_x2.svg',
                                          ),
                                        ),
                                      ),
                                      Text(
                                        'relatorios
                                      ',
                                        style: GoogleFonts.getFont(
                                          'Fira Sans Condensed',
                                          fontWeight: FontWeight.w300,
                                          fontSize: 16,
                                          color: Color(0xFFFFFFFF),
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                        Container(
                          margin: EdgeInsets.fromLTRB(0, 16, 0, 0),
                          decoration: BoxDecoration(
                            border: Border.all(color: Color(0xFFAA9D9D)),
                            color: Color(0xFFD9D9D9),
                          ),
                          child: Container(
                            padding: EdgeInsets.fromLTRB(20, 21, 16, 52),
                            child: Column(
                              mainAxisAlignment: MainAxisAlignment.start,
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Container(
                                  margin: EdgeInsets.fromLTRB(0, 0, 0, 20),
                                  child: SizedBox(
                                    width: 1161,
                                    child: Row(
                                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                      crossAxisAlignment: CrossAxisAlignment.start,
                                      children: [
                                        Row(
                                          mainAxisAlignment: MainAxisAlignment.start,
                                          crossAxisAlignment: CrossAxisAlignment.start,
                                          children: [
                                            Column(
                                              mainAxisAlignment: MainAxisAlignment.start,
                                              crossAxisAlignment: CrossAxisAlignment.start,
                                              children: [
                                                Align(
                                                  alignment: Alignment.topLeft,
                                                  child: Text(
                                                    'Data Inicial',
                                                    style: GoogleFonts.getFont(
                                                      'Fira Sans Condensed',
                                                      fontWeight: FontWeight.w600,
                                                      fontSize: 10,
                                                      color: Color(0xFF000000),
                                                    ),
                                                  ),
                                                ),
                                                Container(
                                                  decoration: BoxDecoration(
                                                    border: Border.all(color: Color(0xFFAAA1A1)),
                                                    color: Color(0xFFFFFFFF),
                                                  ),
                                                  child: SizedBox(
                                                    width: 187.8,
                                                    child: Container(
                                                      padding: EdgeInsets.fromLTRB(4.8, 2.3, 0, 3.5),
                                                      child: Row(
                                                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                                        crossAxisAlignment: CrossAxisAlignment.start,
                                                        children: [
                                                          SizedBox(
                                                            width: 36,
                                                            child: Row(
                                                              mainAxisAlignment: MainAxisAlignment.start,
                                                              crossAxisAlignment: CrossAxisAlignment.start,
                                                              children: [
                                                                Container(
                                                                  margin: EdgeInsets.fromLTRB(0, 0, 4.8, 0),
                                                                  child: SizedBox(
                                                                    width: 30.2,
                                                                    height: 23.4,
                                                                    child: SvgPicture.asset(
                                                                      'assets/vectors/vector_167_x2.svg',
                                                                    ),
                                                                  ),
                                                                ),
                                                                Container(
                                                                  margin: EdgeInsets.fromLTRB(0, 1.2, 0, 0),
                                                                  child: Container(
                                                                    decoration: BoxDecoration(
                                                                      color: Color(0xFFAA9D9D),
                                                                    ),
                                                                    child: Container(
                                                                      width: 1,
                                                                      height: 22.3,
                                                                    ),
                                                                  ),
                                                                ),
                                                              ],
                                                            ),
                                                          ),
                                                          Container(
                                                            margin: EdgeInsets.fromLTRB(0, 2.9, 0, 5.5),
                                                            child: Text(
                                                              '18/11/2022',
                                                              style: GoogleFonts.getFont(
                                                                'Inter',
                                                                fontWeight: FontWeight.w400,
                                                                fontSize: 12,
                                                                color: Color(0xFF000000),
                                                              ),
                                                            ),
                                                          ),
                                                        ],
                                                      ),
                                                    ),
                                                  ),
                                                ),
                                              ],
                                            ),
                                            Column(
                                              mainAxisAlignment: MainAxisAlignment.start,
                                              crossAxisAlignment: CrossAxisAlignment.start,
                                              children: [
                                                Align(
                                                  alignment: Alignment.topLeft,
                                                  child: Text(
                                                    'Data Final',
                                                    style: GoogleFonts.getFont(
                                                      'Fira Sans Condensed',
                                                      fontWeight: FontWeight.w600,
                                                      fontSize: 10,
                                                      color: Color(0xFF000000),
                                                    ),
                                                  ),
                                                ),
                                                Container(
                                                  decoration: BoxDecoration(
                                                    border: Border.all(color: Color(0xFFAAA1A1)),
                                                    color: Color(0xFFFFFFFF),
                                                  ),
                                                  child: SizedBox(
                                                    width: 187.8,
                                                    child: Container(
                                                      padding: EdgeInsets.fromLTRB(4.8, 2.3, 0, 3.5),
                                                      child: Row(
                                                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                                        crossAxisAlignment: CrossAxisAlignment.start,
                                                        children: [
                                                          SizedBox(
                                                            width: 36,
                                                            child: Row(
                                                              mainAxisAlignment: MainAxisAlignment.start,
                                                              crossAxisAlignment: CrossAxisAlignment.start,
                                                              children: [
                                                                Container(
                                                                  margin: EdgeInsets.fromLTRB(0, 0, 4.8, 0),
                                                                  child: SizedBox(
                                                                    width: 30.2,
                                                                    height: 23.4,
                                                                    child: SvgPicture.asset(
                                                                      'assets/vectors/vector_347_x2.svg',
                                                                    ),
                                                                  ),
                                                                ),
                                                                Container(
                                                                  margin: EdgeInsets.fromLTRB(0, 1.2, 0, 0),
                                                                  child: Container(
                                                                    decoration: BoxDecoration(
                                                                      color: Color(0xFFAA9D9D),
                                                                    ),
                                                                    child: Container(
                                                                      width: 1,
                                                                      height: 22.3,
                                                                    ),
                                                                  ),
                                                                ),
                                                              ],
                                                            ),
                                                          ),
                                                          Container(
                                                            margin: EdgeInsets.fromLTRB(0, 2.9, 0, 5.5),
                                                            child: Text(
                                                              '18/11/2022',
                                                              style: GoogleFonts.getFont(
                                                                'Inter',
                                                                fontWeight: FontWeight.w400,
                                                                fontSize: 12,
                                                                color: Color(0xFF000000),
                                                              ),
                                                            ),
                                                          ),
                                                        ],
                                                      ),
                                                    ),
                                                  ),
                                                ),
                                              ],
                                            ),
                                            Column(
                                              mainAxisAlignment: MainAxisAlignment.start,
                                              crossAxisAlignment: CrossAxisAlignment.start,
                                              children: [
                                                Align(
                                                  alignment: Alignment.topLeft,
                                                  child: Text(
                                                    'Setor',
                                                    style: GoogleFonts.getFont(
                                                      'Fira Sans Condensed',
                                                      fontWeight: FontWeight.w600,
                                                      fontSize: 10,
                                                      color: Color(0xFF000000),
                                                    ),
                                                  ),
                                                ),
                                                Container(
                                                  decoration: BoxDecoration(
                                                    border: Border.all(color: Color(0xFFAAA1A1)),
                                                    color: Color(0xFFFFFFFF),
                                                  ),
                                                  child: SizedBox(
                                                    width: 187.8,
                                                    child: Container(
                                                      padding: EdgeInsets.fromLTRB(9, 3.5, 0, 3.5),
                                                      child: Row(
                                                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                                        crossAxisAlignment: CrossAxisAlignment.start,
                                                        children: [
                                                          SizedBox(
                                                            width: 31.8,
                                                            child: Row(
                                                              mainAxisAlignment: MainAxisAlignment.start,
                                                              crossAxisAlignment: CrossAxisAlignment.start,
                                                              children: [
                                                                Container(
                                                                  margin: EdgeInsets.fromLTRB(0, 1.8, 10.8, 0.5),
                                                                  child: SizedBox(
                                                                    width: 20,
                                                                    height: 20,
                                                                    child: SvgPicture.asset(
                                                                      'assets/vectors/vector_69_x2.svg',
                                                                    ),
                                                                  ),
                                                                ),
                                                                Container(
                                                                  decoration: BoxDecoration(
                                                                    color: Color(0xFFAA9D9D),
                                                                  ),
                                                                  child: Container(
                                                                    width: 1,
                                                                    height: 22.3,
                                                                  ),
                                                                ),
                                                              ],
                                                            ),
                                                          ),
                                                          Container(
                                                            margin: EdgeInsets.fromLTRB(0, 1.8, 0, 5.5),
                                                            child: Text(
                                                              'Bloco C',
                                                              style: GoogleFonts.getFont(
                                                                'Inter',
                                                                fontWeight: FontWeight.w400,
                                                                fontSize: 12,
                                                                color: Color(0xFF000000),
                                                              ),
                                                            ),
                                                          ),
                                                        ],
                                                      ),
                                                    ),
                                                  ),
                                                ),
                                              ],
                                            ),
                                            Column(
                                              mainAxisAlignment: MainAxisAlignment.start,
                                              crossAxisAlignment: CrossAxisAlignment.start,
                                              children: [
                                                Align(
                                                  alignment: Alignment.topLeft,
                                                  child: Text(
                                                    'Responsavel',
                                                    style: GoogleFonts.getFont(
                                                      'Fira Sans Condensed',
                                                      fontWeight: FontWeight.w600,
                                                      fontSize: 10,
                                                      color: Color(0xFF000000),
                                                    ),
                                                  ),
                                                ),
                                                Container(
                                                  decoration: BoxDecoration(
                                                    border: Border.all(color: Color(0xFFAAA1A1)),
                                                    color: Color(0xFFFFFFFF),
                                                  ),
                                                  child: SizedBox(
                                                    width: 187.8,
                                                    child: Container(
                                                      padding: EdgeInsets.fromLTRB(10, 3.5, 0, 3.5),
                                                      child: Row(
                                                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                                        crossAxisAlignment: CrossAxisAlignment.start,
                                                        children: [
                                                          SizedBox(
                                                            width: 30.8,
                                                            child: Row(
                                                              mainAxisAlignment: MainAxisAlignment.start,
                                                              crossAxisAlignment: CrossAxisAlignment.start,
                                                              children: [
                                                                Container(
                                                                  margin: EdgeInsets.fromLTRB(0, 0.8, 9.8, 1.5),
                                                                  child: SizedBox(
                                                                    width: 20,
                                                                    height: 20,
                                                                    child: SvgPicture.asset(
                                                                      'assets/vectors/vector_18_x2.svg',
                                                                    ),
                                                                  ),
                                                                ),
                                                                Container(
                                                                  decoration: BoxDecoration(
                                                                    color: Color(0xFFAA9D9D),
                                                                  ),
                                                                  child: Container(
                                                                    width: 1,
                                                                    height: 22.3,
                                                                  ),
                                                                ),
                                                              ],
                                                            ),
                                                          ),
                                                          Container(
                                                            margin: EdgeInsets.fromLTRB(0, 1.8, 0, 5.5),
                                                            child: Text(
                                                              'Germano',
                                                              style: GoogleFonts.getFont(
                                                                'Inter',
                                                                fontWeight: FontWeight.w400,
                                                                fontSize: 12,
                                                                color: Color(0xFF000000),
                                                              ),
                                                            ),
                                                          ),
                                                        ],
                                                      ),
                                                    ),
                                                  ),
                                                ),
                                              ],
                                            ),
                                            Column(
                                              mainAxisAlignment: MainAxisAlignment.start,
                                              crossAxisAlignment: CrossAxisAlignment.start,
                                              children: [
                                                Align(
                                                  alignment: Alignment.topLeft,
                                                  child: Text(
                                                    'Situação',
                                                    style: GoogleFonts.getFont(
                                                      'Fira Sans Condensed',
                                                      fontWeight: FontWeight.w600,
                                                      fontSize: 10,
                                                      color: Color(0xFF000000),
                                                    ),
                                                  ),
                                                ),
                                                Container(
                                                  decoration: BoxDecoration(
                                                    border: Border.all(color: Color(0xFFAAA1A1)),
                                                    color: Color(0xFFFFFFFF),
                                                  ),
                                                  child: SizedBox(
                                                    width: 187.8,
                                                    child: Container(
                                                      padding: EdgeInsets.fromLTRB(9, 3.5, 0, 3.5),
                                                      child: Row(
                                                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                                        crossAxisAlignment: CrossAxisAlignment.start,
                                                        children: [
                                                          SizedBox(
                                                            width: 31.8,
                                                            child: Row(
                                                              mainAxisAlignment: MainAxisAlignment.start,
                                                              crossAxisAlignment: CrossAxisAlignment.start,
                                                              children: [
                                                                Container(
                                                                  margin: EdgeInsets.fromLTRB(0, 0.8, 10.8, 1.5),
                                                                  child: SizedBox(
                                                                    width: 20,
                                                                    height: 20,
                                                                    child: SvgPicture.asset(
                                                                      'assets/vectors/vector_397_x2.svg',
                                                                    ),
                                                                  ),
                                                                ),
                                                                Container(
                                                                  decoration: BoxDecoration(
                                                                    color: Color(0xFFAA9D9D),
                                                                  ),
                                                                  child: Container(
                                                                    width: 1,
                                                                    height: 22.3,
                                                                  ),
                                                                ),
                                                              ],
                                                            ),
                                                          ),
                                                          Container(
                                                            margin: EdgeInsets.fromLTRB(0, 2.8, 0, 4.5),
                                                            child: Text(
                                                              'Reserva',
                                                              style: GoogleFonts.getFont(
                                                                'Inter',
                                                                fontWeight: FontWeight.w400,
                                                                fontSize: 12,
                                                                color: Color(0xFF000000),
                                                              ),
                                                            ),
                                                          ),
                                                        ],
                                                      ),
                                                    ),
                                                  ),
                                                ),
                                              ],
                                            ),
                                          ],
                                        ),
                                        Container(
                                          margin: EdgeInsets.fromLTRB(0, 13, 0, 0),
                                          child: Container(
                                            decoration: BoxDecoration(
                                              color: Color(0xFF000041),
                                            ),
                                            child: SizedBox(
                                              width: 98,
                                              child: Container(
                                                padding: EdgeInsets.fromLTRB(13.4, 5.4, 0, 7.4),
                                                child: Row(
                                                  mainAxisAlignment: MainAxisAlignment.start,
                                                  crossAxisAlignment: CrossAxisAlignment.start,
                                                  children: [
                                                    Container(
                                                      margin: EdgeInsets.fromLTRB(0, 0, 7.4, 0),
                                                      child: SizedBox(
                                                        width: 15.2,
                                                        height: 15.2,
                                                        child: SvgPicture.asset(
                                                          'assets/vectors/vector_86_x2.svg',
                                                        ),
                                                      ),
                                                    ),
                                                    Container(
                                                      margin: EdgeInsets.fromLTRB(0, 2.6, 0, 0.6),
                                                      child: Text(
                                                        'Consultar',
                                                        style: GoogleFonts.getFont(
                                                          'Fira Sans Condensed',
                                                          fontWeight: FontWeight.w600,
                                                          fontSize: 10,
                                                          color: Color(0xFFFFFFFF),
                                                        ),
                                                      ),
                                                    ),
                                                  ],
                                                ),
                                              ),
                                            ),
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                ),
                                Align(
                                  alignment: Alignment.topLeft,
                                  child: Container(
                                    decoration: BoxDecoration(
                                      color: Color(0xFF000041),
                                    ),
                                    child: SizedBox(
                                      width: 144,
                                      child: Container(
                                        padding: EdgeInsets.fromLTRB(6, 7, 0, 7),
                                        child: Row(
                                          mainAxisAlignment: MainAxisAlignment.start,
                                          crossAxisAlignment: CrossAxisAlignment.start,
                                          children: [
                                            Container(
                                              margin: EdgeInsets.fromLTRB(0, 0, 10, 0),
                                              child: SizedBox(
                                                width: 14,
                                                height: 14,
                                                child: SvgPicture.asset(
                                                  'assets/vectors/vector_194_x2.svg',
                                                ),
                                              ),
                                            ),
                                            Container(
                                              margin: EdgeInsets.fromLTRB(0, 1, 0, 1),
                                              child: Text(
                                                'Atendimento Expresso',
                                                style: GoogleFonts.getFont(
                                                  'Fira Sans Condensed',
                                                  fontWeight: FontWeight.w600,
                                                  fontSize: 10,
                                                  color: Color(0xFFFFFFFF),
                                                ),
                                              ),
                                            ),
                                          ],
                                        ),
                                      ),
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                  Container(
                    margin: EdgeInsets.fromLTRB(31, 0, 31, 0),
                    child: Container(
                      decoration: BoxDecoration(
                        color: Color(0xFFD9D9D9),
                      ),
                      child: Container(
                        padding: EdgeInsets.fromLTRB(0, 1, 0, 605),
                        child: Column(
                          mainAxisAlignment: MainAxisAlignment.start,
                          crossAxisAlignment: CrossAxisAlignment.center,
                          children: [
                            Container(
                              margin: EdgeInsets.fromLTRB(0, 0, 0, 6),
                              child: Container(
                                decoration: BoxDecoration(
                                  color: Color(0xFF212176),
                                ),
                                child: SizedBox(
                                  width: 1197,
                                  child: Container(
                                    padding: EdgeInsets.fromLTRB(5, 7, 0, 4),
                                    child: Row(
                                      mainAxisAlignment: MainAxisAlignment.start,
                                      crossAxisAlignment: CrossAxisAlignment.start,
                                      children: [
                                        Container(
                                          margin: EdgeInsets.fromLTRB(0, 0, 3, 0),
                                          child: SizedBox(
                                            width: 20,
                                            height: 20,
                                            child: SvgPicture.asset(
                                              'assets/vectors/vector_344_x2.svg',
                                            ),
                                          ),
                                        ),
                                        Container(
                                          margin: EdgeInsets.fromLTRB(0, 5, 0, 3),
                                          child: Text(
                                            'Atividades',
                                            style: GoogleFonts.getFont(
                                              'Fira Sans Condensed',
                                              fontWeight: FontWeight.w600,
                                              fontSize: 10,
                                              color: Color(0xFFFFFFFF),
                                            ),
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                ),
                              ),
                            ),
                            Container(
                              margin: EdgeInsets.fromLTRB(0, 0, 11.9, 0),
                              child: Row(
                                mainAxisAlignment: MainAxisAlignment.start,
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Container(
                                    margin: EdgeInsets.fromLTRB(0, 0, 6, 0),
                                    width: 20,
                                    height: 20,
                                    child: SizedBox(
                                      width: 20,
                                      height: 20,
                                      child: SvgPicture.asset(
                                        'assets/vectors/vector_311_x2.svg',
                                      ),
                                    ),
                                  ),
                                  Container(
                                    margin: EdgeInsets.fromLTRB(0, 3, 0, 2),
                                    child: Text(
                                      'Clique no botão consultar para filtrar os resultados',
                                      style: GoogleFonts.getFont(
                                        'Inter',
                                        fontWeight: FontWeight.w400,
                                        fontSize: 12,
                                        color: Color(0xFF000000),
                                      ),
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ),
                ],
              ),
              Positioned(
                left: -89,
                bottom: -21,
                child: Container(
                  decoration: BoxDecoration(
                    color: Color(0xFF212176),
                    borderRadius: BorderRadius.only(
                      bottomRight: Radius.circular(100),
                    ),
                  ),
                  child: SizedBox(
                    width: 278,
                    height: 959,
                    child: Container(
                      padding: EdgeInsets.fromLTRB(9.2, 15.8, 9.2, 0),
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.start,
                        crossAxisAlignment: CrossAxisAlignment.center,
                        children: [
                          Container(
                            margin: EdgeInsets.fromLTRB(0, 0, 0, 16.9),
                            child: Align(
                              alignment: Alignment.topLeft,
                              child: Row(
                                mainAxisAlignment: MainAxisAlignment.start,
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Container(
                                    margin: EdgeInsets.fromLTRB(0, 0, 43.5, 0),
                                    child: SizedBox(
                                      width: 47.3,
                                      height: 65.3,
                                      child: SvgPicture.asset(
                                        'assets/vectors/hamburger_18_x2.svg',
                                      ),
                                    ),
                                  ),
                                  Container(
                                    margin: EdgeInsets.fromLTRB(0, 32.2, 0, 13.1),
                                    child: Row(
                                      mainAxisAlignment: MainAxisAlignment.start,
                                      crossAxisAlignment: CrossAxisAlignment.start,
                                      children: [
                                        Container(
                                          margin: EdgeInsets.fromLTRB(0, 3, 8, 1),
                                          child: SizedBox(
                                            width: 17,
                                            height: 16,
                                            child: SvgPicture.asset(
                                              'assets/vectors/vector_210_x2.svg',
                                            ),
                                          ),
                                        ),
                                        Text(
                                          'Audio visual',
                                          style: GoogleFonts.getFont(
                                            'Fira Sans Condensed',
                                            fontWeight: FontWeight.w600,
                                            fontSize: 17,
                                            color: Color(0xFFFFFFFF),
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ),
                          Container(
                            margin: EdgeInsets.fromLTRB(35.8, 0, 0, 34),
                            child: Row(
                              mainAxisAlignment: MainAxisAlignment.start,
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Container(
                                  margin: EdgeInsets.fromLTRB(0, 2.5, 4.5, 2.5),
                                  child: SizedBox(
                                    width: 16.5,
                                    height: 15,
                                    child: SvgPicture.asset(
                                      'assets/vectors/vector_172_x2.svg',
                                    ),
                                  ),
                                ),
                                Text(
                                  'Equipamento',
                                  style: GoogleFonts.getFont(
                                    'Fira Sans Condensed',
                                    fontWeight: FontWeight.w600,
                                    fontSize: 17,
                                    color: Color(0xFFFFFFFF),
                                  ),
                                ),
                              ],
                            ),
                          ),
                          Container(
                            margin: EdgeInsets.fromLTRB(8.6, 0, 0, 31),
                            child: Row(
                              mainAxisAlignment: MainAxisAlignment.start,
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Container(
                                  margin: EdgeInsets.fromLTRB(0, 1, 10, 3),
                                  child: SizedBox(
                                    width: 15,
                                    height: 16,
                                    child: SvgPicture.asset(
                                      'assets/vectors/container_51_x2.svg',
                                    ),
                                  ),
                                ),
                                Text(
                                  'Usuários',
                                  style: GoogleFonts.getFont(
                                    'Fira Sans Condensed',
                                    fontWeight: FontWeight.w600,
                                    fontSize: 17,
                                    color: Color(0xFFFFFFFF),
                                  ),
                                ),
                              ],
                            ),
                          ),
                          Container(
                            margin: EdgeInsets.fromLTRB(27.6, 0, 0, 33),
                            child: Row(
                              mainAxisAlignment: MainAxisAlignment.start,
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Container(
                                  margin: EdgeInsets.fromLTRB(0, 1, 10, 3),
                                  child: SizedBox(
                                    width: 15,
                                    height: 16,
                                    child: SvgPicture.asset(
                                      'assets/vectors/container_16_x2.svg',
                                    ),
                                  ),
                                ),
                                Text(
                                  'Relatorios
                                ',
                                  style: GoogleFonts.getFont(
                                    'Fira Sans Condensed',
                                    fontWeight: FontWeight.w600,
                                    fontSize: 17,
                                    color: Color(0xFFFFFFFF),
                                  ),
                                ),
                              ],
                            ),
                          ),
                          Container(
                            margin: EdgeInsets.fromLTRB(7.2, 0, 0, 0),
                            child: Row(
                              mainAxisAlignment: MainAxisAlignment.start,
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Container(
                                  margin: EdgeInsets.fromLTRB(0, 5, 8, 0),
                                  child: SizedBox(
                                    width: 18,
                                    height: 16,
                                    child: SvgPicture.asset(
                                      'assets/vectors/vector_x2.svg',
                                    ),
                                  ),
                                ),
                                Container(
                                  margin: EdgeInsets.fromLTRB(0, 0, 0, 1),
                                  child: Text(
                                    'Reservas',
                                    style: GoogleFonts.getFont(
                                      'Fira Sans Condensed',
                                      fontWeight: FontWeight.w600,
                                      fontSize: 17,
                                      color: Color(0xFFFFFFFF),
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ),
              ),
              Positioned(
                right: -39,
                top: -34,
                child: Container(
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(5),
                    color: Color(0xFF000041),
                    boxShadow: [
                      BoxShadow(
                        color: Color(0x40000000),
                        offset: Offset(0, 4),
                        blurRadius: 2,
                      ),
                    ],
                  ),
                  child: SizedBox(
                    width: 1479,
                    height: 82,
                    child: Container(
                      padding: EdgeInsets.fromLTRB(0, 4, 74, 6),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Container(
                            decoration: BoxDecoration(
                              image: DecorationImage(
                                fit: BoxFit.cover,
                                image: AssetImage(
                                  'assets/images/image_2.png',
                                ),
                              ),
                            ),
                            child: Container(
                              width: 189,
                              height: 72,
                            ),
                          ),
                          Container(
                            margin: EdgeInsets.fromLTRB(0, 6, 0, 9),
                            child: Row(
                              mainAxisAlignment: MainAxisAlignment.start,
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Container(
                                  margin: EdgeInsets.fromLTRB(0, 0, 17, 0),
                                  child: SizedBox(
                                    width: 59,
                                    height: 57,
                                    child: SvgPicture.asset(
                                      'assets/vectors/group_18_x2.svg',
                                    ),
                                  ),
                                ),
                                Container(
                                  margin: EdgeInsets.fromLTRB(0, 19, 0, 19),
                                  child: Text(
                                    'Logado: Waltair',
                                    style: GoogleFonts.getFont(
                                      'Fira Sans Condensed',
                                      fontWeight: FontWeight.w600,
                                      fontSize: 16,
                                      color: Color(0xFFFFFFFF),
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ),
                          Container(
                            margin: EdgeInsets.fromLTRB(0, 14, 0, 16),
                            child: Row(
                              mainAxisAlignment: MainAxisAlignment.start,
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Container(
                                  margin: EdgeInsets.fromLTRB(0, 0, 31, 0),
                                  child: Container(
                                    padding: EdgeInsets.fromLTRB(17, 11, 17, 12),
                                    child: Stack(
                                      clipBehavior: Clip.none,
                                      children: [
                                        Text(
                                          'Encerrar sessão',
                                          style: GoogleFonts.getFont(
                                            'Fira Sans Condensed',
                                            fontWeight: FontWeight.w600,
                                            fontSize: 16,
                                            color: Color(0xFFFFFFFF),
                                          ),
                                        ),
                                        Positioned(
                                          bottom: -12,
                                          child: Container(
                                            width: 138,
                                            height: 42,
                                            decoration: BoxDecoration(
                                              border: Border.all(color: Color(0xFFFFFFFF)),
                                              borderRadius: BorderRadius.circular(19),
                                            ),
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                ),
                                Container(
                                  decoration: BoxDecoration(
                                    color: Color(0xFF202075),
                                  ),
                                  child: SizedBox(
                                    width: 53,
                                    child: Container(
                                      padding: EdgeInsets.fromLTRB(2.7, 12.9, 7.7, 12.6),
                                      child: Stack(
                                        clipBehavior: Clip.none,
                                        children: [
                                          SizedBox(
                                            width: 42.6,
                                            child: Column(
                                              mainAxisAlignment: MainAxisAlignment.start,
                                              crossAxisAlignment: CrossAxisAlignment.center,
                                              children: [
                                                Container(
                                                  margin: EdgeInsets.fromLTRB(7.4, 0, 2.7, 4),
                                                  child: ClipRRect(
                                                    borderRadius: BorderRadius.circular(40),
                                                    child: SizedBox(
                                                      width: 32.5,
                                                      height: 2.8,
                                                      child: SvgPicture.asset(
                                                        'assets/vectors/rectangle_218_x2.svg',
                                                      ),
                                                    ),
                                                  ),
                                                ),
                                                Container(
                                                  margin: EdgeInsets.fromLTRB(7.4, 0, 2.7, 4),
                                                  child: ClipRRect(
                                                    borderRadius: BorderRadius.circular(40),
                                                    child: SizedBox(
                                                      width: 32.5,
                                                      height: 2.8,
                                                      child: SvgPicture.asset(
                                                        'assets/vectors/rectangle_32_x2.svg',
                                                      ),
                                                    ),
                                                  ),
                                                ),
                                                ClipRRect(
                                                  borderRadius: BorderRadius.circular(40),
                                                  child: SizedBox(
                                                    width: 42.6,
                                                    height: 2.8,
                                                    child: SvgPicture.asset(
                                                      'assets/vectors/rectangle_417_x2.svg',
                                                    ),
                                                  ),
                                                ),
                                              ],
                                            ),
                                          ),
                                          Positioned(
                                            left: -2.7,
                                            top: -11.9,
                                            child: Container(
                                              decoration: BoxDecoration(
                                                color: Color(0x03FFFFFF),
                                              ),
                                              child: Container(
                                                width: 48.7,
                                                height: 34.7,
                                              ),
                                            ),
                                          ),
                                        ],
                                      ),
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}