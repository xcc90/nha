import 'package:flutter/material.dart';
import 'dart:ui';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:flutter_app/utils.dart';
import 'package:google_fonts/google_fonts.dart';

class ReservaPreenchidaDatashow2 extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return 
    Container(
      decoration: BoxDecoration(
        color: Color(0xFFFFFFFF),
      ),
      child: SizedBox(
        width: 1440,
        child: Container(
          padding: EdgeInsets.fromLTRB(7, 34, 0, 21),
          child: Stack(
            clipBehavior: Clip.none,
            children: [
              Column(
                mainAxisAlignment: MainAxisAlignment.start,
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  Container(
                    margin: EdgeInsets.fromLTRB(868.7, 0, 0, 33),
                    child: Text(
                      'logado: Waltair',
                      style: GoogleFonts.getFont(
                        'Fira Sans Condensed',
                        fontWeight: FontWeight.w300,
                        fontSize: 16,
                        color: Color(0xFFFFFFFF),
                      ),
                    ),
                  ),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.start,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Container(
                        margin: EdgeInsets.fromLTRB(0, 15, 45, 755),
                        child: Column(
                          mainAxisAlignment: MainAxisAlignment.start,
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Container(
                              margin: EdgeInsets.fromLTRB(1, 0, 1, 10),
                              child: Align(
                                alignment: Alignment.topLeft,
                                child: Row(
                                  mainAxisAlignment: MainAxisAlignment.start,
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Container(
                                      margin: EdgeInsets.fromLTRB(0, 0, 8, 5),
                                      child: SizedBox(
                                        width: 18,
                                        height: 16,
                                        child: SvgPicture.asset(
                                          'assets/vectors/vector_411_x2.svg',
                                        ),
                                      ),
                                    ),
                                    Container(
                                      margin: EdgeInsets.fromLTRB(0, 2, 0, 0),
                                      child: Text(
                                        'inicio
                                    ',
                                        style: GoogleFonts.getFont(
                                          'Fira Sans Condensed',
                                          fontWeight: FontWeight.w300,
                                          fontSize: 16,
                                          color: Color(0xFFFFFFFF),
                                        ),
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                            ),
                            Container(
                              margin: EdgeInsets.fromLTRB(0, 0, 0.2, 13),
                              child: Row(
                                mainAxisAlignment: MainAxisAlignment.start,
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Container(
                                    margin: EdgeInsets.fromLTRB(0, 5, 8, 0),
                                    child: SizedBox(
                                      width: 18,
                                      height: 16,
                                      child: SvgPicture.asset(
                                        'assets/vectors/vector_261_x2.svg',
                                      ),
                                    ),
                                  ),
                                  Container(
                                    margin: EdgeInsets.fromLTRB(0, 0, 0, 2),
                                    child: Text(
                                      'consultar reservas',
                                      style: GoogleFonts.getFont(
                                        'Fira Sans Condensed',
                                        fontWeight: FontWeight.w300,
                                        fontSize: 16,
                                        color: Color(0xFFFFFFFF),
                                      ),
                                    ),
                                  ),
                                ],
                              ),
                            ),
                            Container(
                              margin: EdgeInsets.fromLTRB(0.8, 0, 0, 10),
                              child: Row(
                                mainAxisAlignment: MainAxisAlignment.start,
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Container(
                                    margin: EdgeInsets.fromLTRB(0, 2.5, 8.8, 1.5),
                                    child: SizedBox(
                                      width: 16.5,
                                      height: 15,
                                      child: SvgPicture.asset(
                                        'assets/vectors/vector_357_x2.svg',
                                      ),
                                    ),
                                  ),
                                  Text(
                                    'adicionar material',
                                    style: GoogleFonts.getFont(
                                      'Fira Sans Condensed',
                                      fontWeight: FontWeight.w300,
                                      fontSize: 16,
                                      color: Color(0xFFFFFFFF),
                                    ),
                                  ),
                                ],
                              ),
                            ),
                            Container(
                              margin: EdgeInsets.fromLTRB(1, 0, 6.6, 15),
                              child: Row(
                                mainAxisAlignment: MainAxisAlignment.start,
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Container(
                                    margin: EdgeInsets.fromLTRB(0, 3, 8, 0),
                                    child: SizedBox(
                                      width: 17,
                                      height: 16,
                                      child: SvgPicture.asset(
                                        'assets/vectors/vector_281_x2.svg',
                                      ),
                                    ),
                                  ),
                                  Text(
                                    'adicionar reserva',
                                    style: GoogleFonts.getFont(
                                      'Fira Sans Condensed',
                                      fontWeight: FontWeight.w300,
                                      fontSize: 16,
                                      color: Color(0xFFFFFFFF),
                                    ),
                                  ),
                                ],
                              ),
                            ),
                            Container(
                              margin: EdgeInsets.fromLTRB(1, 0, 1, 0),
                              child: Align(
                                alignment: Alignment.topLeft,
                                child: Row(
                                  mainAxisAlignment: MainAxisAlignment.start,
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Container(
                                      margin: EdgeInsets.fromLTRB(0, 1, 10, 2),
                                      child: SizedBox(
                                        width: 15,
                                        height: 16,
                                        child: SvgPicture.asset(
                                          'assets/vectors/container_86_x2.svg',
                                        ),
                                      ),
                                    ),
                                    Text(
                                      'relatorios
                                    ',
                                      style: GoogleFonts.getFont(
                                        'Fira Sans Condensed',
                                        fontWeight: FontWeight.w300,
                                        fontSize: 16,
                                        color: Color(0xFFFFFFFF),
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                      Column(
                        mainAxisAlignment: MainAxisAlignment.start,
                        crossAxisAlignment: CrossAxisAlignment.center,
                        children: [
                          Container(
                            margin: EdgeInsets.fromLTRB(0, 0, 0, 26),
                            child: Container(
                              decoration: BoxDecoration(
                                color: Color(0xFFD9D9D9),
                              ),
                              child: Container(
                                width: 1244,
                                height: 36,
                              ),
                            ),
                          ),
                          Container(
                            margin: EdgeInsets.fromLTRB(16, 0, 31, 30),
                            decoration: BoxDecoration(
                              border: Border.all(color: Color(0xFFAA9D9D)),
                              color: Color(0xFFD9D9D9),
                            ),
                            child: Container(
                              padding: EdgeInsets.fromLTRB(20, 21, 16, 52),
                              child: Column(
                                mainAxisAlignment: MainAxisAlignment.start,
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Container(
                                    margin: EdgeInsets.fromLTRB(0, 0, 0, 20),
                                    child: SizedBox(
                                      width: 1161,
                                      child: Row(
                                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                        crossAxisAlignment: CrossAxisAlignment.start,
                                        children: [
                                          Container(
                                            margin: EdgeInsets.fromLTRB(0, 0, 0, 0),
                                            child: Row(
                                              mainAxisAlignment: MainAxisAlignment.start,
                                              crossAxisAlignment: CrossAxisAlignment.start,
                                              children: [
                                                Column(
                                                  mainAxisAlignment: MainAxisAlignment.start,
                                                  crossAxisAlignment: CrossAxisAlignment.start,
                                                  children: [
                                                    Align(
                                                      alignment: Alignment.topLeft,
                                                      child: Text(
                                                        'Data Inicial',
                                                        style: GoogleFonts.getFont(
                                                          'Fira Sans Condensed',
                                                          fontWeight: FontWeight.w600,
                                                          fontSize: 10,
                                                          color: Color(0xFF000000),
                                                        ),
                                                      ),
                                                    ),
                                                    Container(
                                                      decoration: BoxDecoration(
                                                        border: Border.all(color: Color(0xFFAAA1A1)),
                                                        color: Color(0xFFFFFFFF),
                                                      ),
                                                      child: SizedBox(
                                                        width: 187.8,
                                                        child: Container(
                                                          padding: EdgeInsets.fromLTRB(4.8, 2.3, 0, 3.5),
                                                          child: Row(
                                                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                                            crossAxisAlignment: CrossAxisAlignment.start,
                                                            children: [
                                                              SizedBox(
                                                                width: 36,
                                                                child: Row(
                                                                  mainAxisAlignment: MainAxisAlignment.start,
                                                                  crossAxisAlignment: CrossAxisAlignment.start,
                                                                  children: [
                                                                    Container(
                                                                      margin: EdgeInsets.fromLTRB(0, 0, 4.8, 0),
                                                                      child: SizedBox(
                                                                        width: 30.2,
                                                                        height: 23.4,
                                                                        child: SvgPicture.asset(
                                                                          'assets/vectors/vector_134_x2.svg',
                                                                        ),
                                                                      ),
                                                                    ),
                                                                    Container(
                                                                      margin: EdgeInsets.fromLTRB(0, 1.2, 0, 0),
                                                                      child: Container(
                                                                        decoration: BoxDecoration(
                                                                          color: Color(0xFFAA9D9D),
                                                                        ),
                                                                        child: Container(
                                                                          width: 1,
                                                                          height: 22.3,
                                                                        ),
                                                                      ),
                                                                    ),
                                                                  ],
                                                                ),
                                                              ),
                                                              Container(
                                                                margin: EdgeInsets.fromLTRB(0, 2.9, 0, 5.5),
                                                                child: Text(
                                                                  '09/11/2022',
                                                                  style: GoogleFonts.getFont(
                                                                    'Inter',
                                                                    fontWeight: FontWeight.w400,
                                                                    fontSize: 12,
                                                                    color: Color(0xFF000000),
                                                                  ),
                                                                ),
                                                              ),
                                                            ],
                                                          ),
                                                        ),
                                                      ),
                                                    ),
                                                  ],
                                                ),
                                                Column(
                                                  mainAxisAlignment: MainAxisAlignment.start,
                                                  crossAxisAlignment: CrossAxisAlignment.start,
                                                  children: [
                                                    Align(
                                                      alignment: Alignment.topLeft,
                                                      child: Text(
                                                        'Data Final',
                                                        style: GoogleFonts.getFont(
                                                          'Fira Sans Condensed',
                                                          fontWeight: FontWeight.w600,
                                                          fontSize: 10,
                                                          color: Color(0xFF000000),
                                                        ),
                                                      ),
                                                    ),
                                                    Container(
                                                      decoration: BoxDecoration(
                                                        border: Border.all(color: Color(0xFFAAA1A1)),
                                                        color: Color(0xFFFFFFFF),
                                                      ),
                                                      child: SizedBox(
                                                        width: 187.8,
                                                        child: Container(
                                                          padding: EdgeInsets.fromLTRB(4.8, 2.3, 0, 3.5),
                                                          child: Row(
                                                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                                            crossAxisAlignment: CrossAxisAlignment.start,
                                                            children: [
                                                              SizedBox(
                                                                width: 36,
                                                                child: Row(
                                                                  mainAxisAlignment: MainAxisAlignment.start,
                                                                  crossAxisAlignment: CrossAxisAlignment.start,
                                                                  children: [
                                                                    Container(
                                                                      margin: EdgeInsets.fromLTRB(0, 0, 4.8, 0),
                                                                      child: SizedBox(
                                                                        width: 30.2,
                                                                        height: 23.4,
                                                                        child: SvgPicture.asset(
                                                                          'assets/vectors/vector_192_x2.svg',
                                                                        ),
                                                                      ),
                                                                    ),
                                                                    Container(
                                                                      margin: EdgeInsets.fromLTRB(0, 1.2, 0, 0),
                                                                      child: Container(
                                                                        decoration: BoxDecoration(
                                                                          color: Color(0xFFAA9D9D),
                                                                        ),
                                                                        child: Container(
                                                                          width: 1,
                                                                          height: 22.3,
                                                                        ),
                                                                      ),
                                                                    ),
                                                                  ],
                                                                ),
                                                              ),
                                                              Container(
                                                                margin: EdgeInsets.fromLTRB(0, 2.9, 0, 5.5),
                                                                child: Text(
                                                                  '21/11/2022',
                                                                  style: GoogleFonts.getFont(
                                                                    'Inter',
                                                                    fontWeight: FontWeight.w400,
                                                                    fontSize: 12,
                                                                    color: Color(0xFF000000),
                                                                  ),
                                                                ),
                                                              ),
                                                            ],
                                                          ),
                                                        ),
                                                      ),
                                                    ),
                                                  ],
                                                ),
                                                Column(
                                                  mainAxisAlignment: MainAxisAlignment.start,
                                                  crossAxisAlignment: CrossAxisAlignment.start,
                                                  children: [
                                                    Align(
                                                      alignment: Alignment.topLeft,
                                                      child: Text(
                                                        'Setor',
                                                        style: GoogleFonts.getFont(
                                                          'Fira Sans Condensed',
                                                          fontWeight: FontWeight.w600,
                                                          fontSize: 10,
                                                          color: Color(0xFF000000),
                                                        ),
                                                      ),
                                                    ),
                                                    Container(
                                                      decoration: BoxDecoration(
                                                        border: Border.all(color: Color(0xFFAAA1A1)),
                                                        color: Color(0xFFFFFFFF),
                                                      ),
                                                      child: SizedBox(
                                                        width: 187.8,
                                                        child: Container(
                                                          padding: EdgeInsets.fromLTRB(9, 3.5, 0, 3.5),
                                                          child: Row(
                                                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                                            crossAxisAlignment: CrossAxisAlignment.start,
                                                            children: [
                                                              SizedBox(
                                                                width: 31.8,
                                                                child: Row(
                                                                  mainAxisAlignment: MainAxisAlignment.start,
                                                                  crossAxisAlignment: CrossAxisAlignment.start,
                                                                  children: [
                                                                    Container(
                                                                      margin: EdgeInsets.fromLTRB(0, 1.8, 10.8, 0.5),
                                                                      child: SizedBox(
                                                                        width: 20,
                                                                        height: 20,
                                                                        child: SvgPicture.asset(
                                                                          'assets/vectors/vector_291_x2.svg',
                                                                        ),
                                                                      ),
                                                                    ),
                                                                    Container(
                                                                      decoration: BoxDecoration(
                                                                        color: Color(0xFFAA9D9D),
                                                                      ),
                                                                      child: Container(
                                                                        width: 1,
                                                                        height: 22.3,
                                                                      ),
                                                                    ),
                                                                  ],
                                                                ),
                                                              ),
                                                              Container(
                                                                margin: EdgeInsets.fromLTRB(0, 1.8, 0, 5.5),
                                                                child: Text(
                                                                  'Bloco C',
                                                                  style: GoogleFonts.getFont(
                                                                    'Inter',
                                                                    fontWeight: FontWeight.w400,
                                                                    fontSize: 12,
                                                                    color: Color(0xFF000000),
                                                                  ),
                                                                ),
                                                              ),
                                                            ],
                                                          ),
                                                        ),
                                                      ),
                                                    ),
                                                  ],
                                                ),
                                                Stack(
                                                  children: [
                                                    Column(
                                                      mainAxisAlignment: MainAxisAlignment.start,
                                                      crossAxisAlignment: CrossAxisAlignment.start,
                                                      children: [
                                                        Align(
                                                          alignment: Alignment.topLeft,
                                                          child: Text(
                                                            'Responsavel',
                                                            style: GoogleFonts.getFont(
                                                              'Fira Sans Condensed',
                                                              fontWeight: FontWeight.w600,
                                                              fontSize: 10,
                                                              color: Color(0xFF000000),
                                                            ),
                                                          ),
                                                        ),
                                                        Container(
                                                          decoration: BoxDecoration(
                                                            border: Border.all(color: Color(0xFFAAA1A1)),
                                                            color: Color(0xFFFFFFFF),
                                                          ),
                                                          child: Stack(
                                                            children: [
                                                              Positioned(
                                                                left: 10,
                                                                top: 4.3,
                                                                child: SizedBox(
                                                                  width: 20,
                                                                  height: 20,
                                                                  child: SvgPicture.asset(
                                                                    'assets/vectors/vector_390_x2.svg',
                                                                  ),
                                                                ),
                                                              ),
                                                        SizedBox(
                                                                width: 187.8,
                                                                child: Stack(
                                                                  children: [
                                                                    Positioned(
                                                                      left: 39.8,
                                                                      bottom: 3.5,
                                                                      child: Container(
                                                                        decoration: BoxDecoration(
                                                                          color: Color(0xFFAA9D9D),
                                                                        ),
                                                                        child: Container(
                                                                          width: 1,
                                                                          height: 22.3,
                                                                        ),
                                                                      ),
                                                                    ),
                                                                    Container(
                                                                      decoration: BoxDecoration(
                                                                        border: Border.all(color: Color(0xFFAAA1A1)),
                                                                        color: Color(0xFFFFFFFF),
                                                                      ),
                                                                      child: SizedBox(
                                                                        width: 187.8,
                                                                        child: Container(
                                                                          padding: EdgeInsets.fromLTRB(10, 3.5, 0, 3.5),
                                                                          child: Row(
                                                                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                                                            crossAxisAlignment: CrossAxisAlignment.start,
                                                                            children: [
                                                                              SizedBox(
                                                                                width: 30.8,
                                                                                child: Row(
                                                                                  mainAxisAlignment: MainAxisAlignment.start,
                                                                                  crossAxisAlignment: CrossAxisAlignment.start,
                                                                                  children: [
                                                                                    Container(
                                                                                      margin: EdgeInsets.fromLTRB(0, 0.8, 9.8, 1.5),
                                                                                      child: SizedBox(
                                                                                        width: 20,
                                                                                        height: 20,
                                                                                        child: SvgPicture.asset(
                                                                                          'assets/vectors/vector_379_x2.svg',
                                                                                        ),
                                                                                      ),
                                                                                    ),
                                                                                    Container(
                                                                                      decoration: BoxDecoration(
                                                                                        color: Color(0xFFAA9D9D),
                                                                                      ),
                                                                                      child: Container(
                                                                                        width: 1,
                                                                                        height: 22.3,
                                                                                      ),
                                                                                    ),
                                                                                  ],
                                                                                ),
                                                                              ),
                                                                              Container(
                                                                                margin: EdgeInsets.fromLTRB(0, 1.8, 0, 5.5),
                                                                                child: Text(
                                                                                  'Germano',
                                                                                  style: GoogleFonts.getFont(
                                                                                    'Inter',
                                                                                    fontWeight: FontWeight.w400,
                                                                                    fontSize: 12,
                                                                                    color: Color(0xFF000000),
                                                                                  ),
                                                                                ),
                                                                              ),
                                                                            ],
                                                                          ),
                                                                        ),
                                                                      ),
                                                                    ),
                                                                  ],
                                                                ),
                                                              ),
                                                            ],
                                                          ),
                                                        ),
                                                      ],
                                                    ),
                                                    Positioned(
                                                      left: 0,
                                                      top: 0,
                                                      child: SizedBox(
                                                        height: 12,
                                                        child: Text(
                                                          'Responsavel',
                                                          style: GoogleFonts.getFont(
                                                            'Fira Sans Condensed',
                                                            fontWeight: FontWeight.w600,
                                                            fontSize: 10,
                                                            color: Color(0xFF000000),
                                                          ),
                                                        ),
                                                      ),
                                                    ),
                                                  ],
                                                ),
                                                Column(
                                                  mainAxisAlignment: MainAxisAlignment.start,
                                                  crossAxisAlignment: CrossAxisAlignment.start,
                                                  children: [
                                                    Align(
                                                      alignment: Alignment.topLeft,
                                                      child: Text(
                                                        'Situação',
                                                        style: GoogleFonts.getFont(
                                                          'Fira Sans Condensed',
                                                          fontWeight: FontWeight.w600,
                                                          fontSize: 10,
                                                          color: Color(0xFF000000),
                                                        ),
                                                      ),
                                                    ),
                                                    Container(
                                                      decoration: BoxDecoration(
                                                        border: Border.all(color: Color(0xFFAAA1A1)),
                                                        color: Color(0xFFFFFFFF),
                                                      ),
                                                      child: SizedBox(
                                                        width: 187.8,
                                                        child: Container(
                                                          padding: EdgeInsets.fromLTRB(9, 3.5, 0, 3.5),
                                                          child: Row(
                                                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                                            crossAxisAlignment: CrossAxisAlignment.start,
                                                            children: [
                                                              SizedBox(
                                                                width: 31.8,
                                                                child: Row(
                                                                  mainAxisAlignment: MainAxisAlignment.start,
                                                                  crossAxisAlignment: CrossAxisAlignment.start,
                                                                  children: [
                                                                    Container(
                                                                      margin: EdgeInsets.fromLTRB(0, 0.8, 10.8, 1.5),
                                                                      child: SizedBox(
                                                                        width: 20,
                                                                        height: 20,
                                                                        child: SvgPicture.asset(
                                                                          'assets/vectors/vector_56_x2.svg',
                                                                        ),
                                                                      ),
                                                                    ),
                                                                    Container(
                                                                      decoration: BoxDecoration(
                                                                        color: Color(0xFFAA9D9D),
                                                                      ),
                                                                      child: Container(
                                                                        width: 1,
                                                                        height: 22.3,
                                                                      ),
                                                                    ),
                                                                  ],
                                                                ),
                                                              ),
                                                              Container(
                                                                margin: EdgeInsets.fromLTRB(0, 2.8, 0, 4.5),
                                                                child: Text(
                                                                  'Reservada',
                                                                  style: GoogleFonts.getFont(
                                                                    'Inter',
                                                                    fontWeight: FontWeight.w400,
                                                                    fontSize: 12,
                                                                    color: Color(0xFF000000),
                                                                  ),
                                                                ),
                                                              ),
                                                            ],
                                                          ),
                                                        ),
                                                      ),
                                                    ),
                                                  ],
                                                ),
                                              ],
                                            ),
                                          ),
                                          Container(
                                            margin: EdgeInsets.fromLTRB(0, 13, 0, 0),
                                            child: Container(
                                              decoration: BoxDecoration(
                                                color: Color(0xFF000041),
                                              ),
                                              child: SizedBox(
                                                width: 98,
                                                child: Container(
                                                  padding: EdgeInsets.fromLTRB(13.4, 5.4, 0, 7.4),
                                                  child: Row(
                                                    mainAxisAlignment: MainAxisAlignment.start,
                                                    crossAxisAlignment: CrossAxisAlignment.start,
                                                    children: [
                                                      Container(
                                                        margin: EdgeInsets.fromLTRB(0, 0, 7.4, 0),
                                                        child: SizedBox(
                                                          width: 15.2,
                                                          height: 15.2,
                                                          child: SvgPicture.asset(
                                                            'assets/vectors/vector_94_x2.svg',
                                                          ),
                                                        ),
                                                      ),
                                                      Container(
                                                        margin: EdgeInsets.fromLTRB(0, 2.6, 0, 0.6),
                                                        child: Text(
                                                          'Consultar',
                                                          style: GoogleFonts.getFont(
                                                            'Fira Sans Condensed',
                                                            fontWeight: FontWeight.w600,
                                                            fontSize: 10,
                                                            color: Color(0xFFFFFFFF),
                                                          ),
                                                        ),
                                                      ),
                                                    ],
                                                  ),
                                                ),
                                              ),
                                            ),
                                          ),
                                        ],
                                      ),
                                    ),
                                  ),
                                  Align(
                                    alignment: Alignment.topLeft,
                                    child: Container(
                                      decoration: BoxDecoration(
                                        color: Color(0xFF000041),
                                      ),
                                      child: SizedBox(
                                        width: 144,
                                        child: Container(
                                          padding: EdgeInsets.fromLTRB(6, 7, 0, 7),
                                          child: Row(
                                            mainAxisAlignment: MainAxisAlignment.start,
                                            crossAxisAlignment: CrossAxisAlignment.start,
                                            children: [
                                              Container(
                                                margin: EdgeInsets.fromLTRB(0, 0, 10, 0),
                                                child: SizedBox(
                                                  width: 14,
                                                  height: 14,
                                                  child: SvgPicture.asset(
                                                    'assets/vectors/vector_16_x2.svg',
                                                  ),
                                                ),
                                              ),
                                              Container(
                                                margin: EdgeInsets.fromLTRB(0, 1, 0, 1),
                                                child: Text(
                                                  'Atendimento Expresso',
                                                  style: GoogleFonts.getFont(
                                                    'Fira Sans Condensed',
                                                    fontWeight: FontWeight.w600,
                                                    fontSize: 10,
                                                    color: Color(0xFFFFFFFF),
                                                  ),
                                                ),
                                              ),
                                            ],
                                          ),
                                        ),
                                      ),
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ),
                          Container(
                            margin: EdgeInsets.fromLTRB(16, 0, 31, 0),
                            child: Container(
                              decoration: BoxDecoration(
                                color: Color(0xFFD9D9D9),
                              ),
                              child: Container(
                                padding: EdgeInsets.fromLTRB(0, 1, 0, 528.7),
                                child: Column(
                                  mainAxisAlignment: MainAxisAlignment.start,
                                  crossAxisAlignment: CrossAxisAlignment.center,
                                  children: [
                                    Container(
                                      margin: EdgeInsets.fromLTRB(0, 0, 0, 15),
                                      child: Container(
                                        decoration: BoxDecoration(
                                          color: Color(0xFF212176),
                                        ),
                                        child: SizedBox(
                                          width: 1197,
                                          child: Container(
                                            padding: EdgeInsets.fromLTRB(5, 7, 0, 4),
                                            child: Row(
                                              mainAxisAlignment: MainAxisAlignment.start,
                                              crossAxisAlignment: CrossAxisAlignment.start,
                                              children: [
                                                Container(
                                                  margin: EdgeInsets.fromLTRB(0, 0, 3, 0),
                                                  child: SizedBox(
                                                    width: 20,
                                                    height: 20,
                                                    child: SvgPicture.asset(
                                                      'assets/vectors/vector_323_x2.svg',
                                                    ),
                                                  ),
                                                ),
                                                Container(
                                                  margin: EdgeInsets.fromLTRB(0, 5, 0, 3),
                                                  child: Text(
                                                    'Atividades',
                                                    style: GoogleFonts.getFont(
                                                      'Fira Sans Condensed',
                                                      fontWeight: FontWeight.w600,
                                                      fontSize: 10,
                                                      color: Color(0xFFFFFFFF),
                                                    ),
                                                  ),
                                                ),
                                              ],
                                            ),
                                          ),
                                        ),
                                      ),
                                    ),
                                    Container(
                                      margin: EdgeInsets.fromLTRB(10, 0, 46.3, 0),
                                      child: Row(
                                        mainAxisAlignment: MainAxisAlignment.start,
                                        crossAxisAlignment: CrossAxisAlignment.start,
                                        children: [
                                          Container(
                                            margin: EdgeInsets.fromLTRB(0, 0, 0.5, 0.3),
                                            child: Column(
                                              mainAxisAlignment: MainAxisAlignment.start,
                                              crossAxisAlignment: CrossAxisAlignment.center,
                                              children: [
                                                Container(
                                                  margin: EdgeInsets.fromLTRB(0, 0, 1, 6.7),
                                                  child: Stack(
                                                    children: [
                                                      Container(
                                                        decoration: BoxDecoration(
                                                          color: Color(0xFF4228D7),
                                                        ),
                                                        child: Container(
                                                          padding: EdgeInsets.fromLTRB(12, 4, 16.3, 4.3),
                                                          child: Text(
                                                            'nº Reserva',
                                                            style: GoogleFonts.getFont(
                                                              'Fira Sans Condensed',
                                                              fontWeight: FontWeight.w600,
                                                              fontSize: 10,
                                                              color: Color(0xFFFFFFFF),
                                                            ),
                                                          ),
                                                        ),
                                                      ),
                                                      Positioned(
                                                        top: 0,
                                                        bottom: 0,
                                                        child: Container(
                                                          decoration: BoxDecoration(
                                                            color: Color(0xFF4228D7),
                                                          ),
                                                          child: Container(
                                                            height: 20.3,
                                                            padding: EdgeInsets.fromLTRB(12, 4, 16.3, 4.3),
                                                            child: Text(
                                                              'nº Reserva',
                                                              style: GoogleFonts.getFont(
                                                                'Fira Sans Condensed',
                                                                fontWeight: FontWeight.w600,
                                                                fontSize: 10,
                                                                color: Color(0xFFFFFFFF),
                                                              ),
                                                            ),
                                                          ),
                                                        ),
                                                      ),
                                                    ],
                                                  ),
                                                ),
                                                Container(
                                                  margin: EdgeInsets.fromLTRB(0, 0, 1, 7),
                                                  child: SizedBox(
                                                    width: 73.2,
                                                    child: Container(
                                                      padding: EdgeInsets.fromLTRB(0, 0, 0.9, 4),
                                                      child: Stack(
                                                        clipBehavior: Clip.none,
                                                        children: [
                                                          Positioned(
                                                            left: 0,
                                                            right: 0,
                                                            bottom: 0,
                                                            child: Container(
                                                              width: 73.2,
                                                              height: 14.3,
                                                              decoration: BoxDecoration(
                                                                border: Border(
                                                                  bottom: BorderSize(
                                                                    color: Color(0xFFAA9D9D),
                                                                    width: 1,
                                                                  ),
                                                                ),
                                                              ),
                                                            ),
                                                          ),
                                                          Text(
                                                            '254',
                                                            style: GoogleFonts.getFont(
                                                              'Fira Sans Condensed',
                                                              fontWeight: FontWeight.w500,
                                                              fontSize: 10,
                                                              color: Color(0xFF3E3636),
                                                            ),
                                                          ),
                                                        ],
                                                      ),
                                                    ),
                                                  ),
                                                ),
                                                Container(
                                                  margin: EdgeInsets.fromLTRB(0, 0, 1, 5),
                                                  child: SizedBox(
                                                    width: 73.2,
                                                    child: Container(
                                                      padding: EdgeInsets.fromLTRB(0, 0, 1.2, 4),
                                                      child: Stack(
                                                        clipBehavior: Clip.none,
                                                        children: [
                                                          Positioned(
                                                            left: 0,
                                                            right: 0,
                                                            bottom: 0,
                                                            child: Container(
                                                              width: 73.2,
                                                              height: 14.3,
                                                              decoration: BoxDecoration(
                                                                border: Border(
                                                                  bottom: BorderSize(
                                                                    color: Color(0xFFAA9D9D),
                                                                    width: 1,
                                                                  ),
                                                                ),
                                                              ),
                                                            ),
                                                          ),
                                                          Text(
                                                            '255',
                                                            style: GoogleFonts.getFont(
                                                              'Fira Sans Condensed',
                                                              fontWeight: FontWeight.w500,
                                                              fontSize: 10,
                                                              color: Color(0xFF3E3636),
                                                            ),
                                                          ),
                                                        ],
                                                      ),
                                                    ),
                                                  ),
                                                ),
                                                Container(
                                                  margin: EdgeInsets.fromLTRB(1, 0, 0, 0),
                                                  child: SizedBox(
                                                    width: 73.2,
                                                    child: Container(
                                                      padding: EdgeInsets.fromLTRB(0, 0, 0.8, 4),
                                                      child: Stack(
                                                        clipBehavior: Clip.none,
                                                        children: [
                                                          Positioned(
                                                            left: 0,
                                                            right: 0,
                                                            bottom: 0,
                                                            child: Container(
                                                              width: 73.2,
                                                              height: 14.3,
                                                              decoration: BoxDecoration(
                                                                border: Border(
                                                                  bottom: BorderSize(
                                                                    color: Color(0xFFAA9D9D),
                                                                    width: 1,
                                                                  ),
                                                                ),
                                                              ),
                                                            ),
                                                          ),
                                                          Text(
                                                            '256',
                                                            style: GoogleFonts.getFont(
                                                              'Fira Sans Condensed',
                                                              fontWeight: FontWeight.w500,
                                                              fontSize: 10,
                                                              color: Color(0xFF3E3636),
                                                            ),
                                                          ),
                                                          Positioned(
                                                            left: 0,
                                                            right: 0,
                                                            top: 0,
                                                            bottom: 0,
                                                            child: SizedBox(
                                                              width: 73.2,
                                                              height: 16,
                                                              child: Container(
                                                                padding: EdgeInsets.fromLTRB(0, 0, 0.8, 4),
                                                                child: Stack(
                                                                  clipBehavior: Clip.none,
                                                                  children: [
                                                                    Positioned(
                                                                      left: 0,
                                                                      right: 0,
                                                                      bottom: 0,
                                                                      child: Container(
                                                                        width: 73.2,
                                                                        height: 14.3,
                                                                        decoration: BoxDecoration(
                                                                          border: Border(
                                                                            bottom: BorderSize(
                                                                              color: Color(0xFFAA9D9D),
                                                                              width: 1,
                                                                            ),
                                                                          ),
                                                                        ),
                                                                      ),
                                                                    ),
                                                                    Text(
                                                                      '256',
                                                                      style: GoogleFonts.getFont(
                                                                        'Fira Sans Condensed',
                                                                        fontWeight: FontWeight.w500,
                                                                        fontSize: 10,
                                                                        color: Color(0xFF3E3636),
                                                                      ),
                                                                    ),
                                                                  ],
                                                                ),
                                                              ),
                                                            ),
                                                          ),
                                                        ],
                                                      ),
                                                    ),
                                                  ),
                                                ),
                                              ],
                                            ),
                                          ),
                                          Container(
                                            margin: EdgeInsets.fromLTRB(0, 0, 0.1, 0.3),
                                            child: SizedBox(
                                              width: 108.2,
                                              child: Column(
                                                mainAxisAlignment: MainAxisAlignment.start,
                                                crossAxisAlignment: CrossAxisAlignment.start,
                                                children: [
                                                  Container(
                                                    margin: EdgeInsets.fromLTRB(0, 0, 1.4, 6.7),
                                                    child: Container(
                                                      decoration: BoxDecoration(
                                                        color: Color(0xFF4228D7),
                                                      ),
                                                      child: Container(
                                                        padding: EdgeInsets.fromLTRB(19.4, 4, 19.4, 4.3),
                                                        child: Stack(
                                                          clipBehavior: Clip.none,
                                                          children: [
                                                            Text(
                                                              'Data de retirada',
                                                              style: GoogleFonts.getFont(
                                                                'Fira Sans Condensed',
                                                                fontWeight: FontWeight.w600,
                                                                fontSize: 10,
                                                                color: Color(0xFFFFFFFF),
                                                              ),
                                                            ),
                                                            Positioned(
                                                              left: -19.4,
                                                              right: -19.4,
                                                              top: -4,
                                                              bottom: -4.3,
                                                              child: Container(
                                                                decoration: BoxDecoration(
                                                                  color: Color(0xFF4228D7),
                                                                ),
                                                                child: Container(
                                                                  width: 106.8,
                                                                  height: 20.3,
                                                                  padding: EdgeInsets.fromLTRB(19.4, 4, 19.4, 4.3),
                                                                  child: Text(
                                                                    'Data de retirada',
                                                                    style: GoogleFonts.getFont(
                                                                      'Fira Sans Condensed',
                                                                      fontWeight: FontWeight.w600,
                                                                      fontSize: 10,
                                                                      color: Color(0xFFFFFFFF),
                                                                    ),
                                                                  ),
                                                                ),
                                                              ),
                                                            ),
                                                          ],
                                                        ),
                                                      ),
                                                    ),
                                                  ),
                                                  Container(
                                                    margin: EdgeInsets.fromLTRB(0, 0, 1.4, 7),
                                                    child: SizedBox(
                                                      width: 106.8,
                                                      child: Container(
                                                        padding: EdgeInsets.fromLTRB(0, 0, 4.2, 4),
                                                        child: Stack(
                                                          clipBehavior: Clip.none,
                                                          children: [
                                                            Positioned(
                                                              left: 0,
                                                              right: 0,
                                                              bottom: 0,
                                                              child: Container(
                                                                width: 106.8,
                                                                height: 14.3,
                                                                decoration: BoxDecoration(
                                                                  border: Border(
                                                                    bottom: BorderSize(
                                                                      color: Color(0xFFAA9D9D),
                                                                      width: 1,
                                                                    ),
                                                                  ),
                                                                ),
                                                              ),
                                                            ),
                                                            Text(
                                                              '11/12/2022',
                                                              style: GoogleFonts.getFont(
                                                                'Fira Sans Condensed',
                                                                fontWeight: FontWeight.w500,
                                                                fontSize: 10,
                                                                color: Color(0xFF3E3636),
                                                              ),
                                                            ),
                                                          ],
                                                        ),
                                                      ),
                                                    ),
                                                  ),
                                                  Container(
                                                    margin: EdgeInsets.fromLTRB(0, 0, 1.4, 5),
                                                    child: SizedBox(
                                                      width: 106.8,
                                                      child: Container(
                                                        padding: EdgeInsets.fromLTRB(0, 0, 4.2, 4),
                                                        child: Stack(
                                                          clipBehavior: Clip.none,
                                                          children: [
                                                            Positioned(
                                                              left: 0,
                                                              right: 0,
                                                              bottom: 0,
                                                              child: Container(
                                                                width: 106.8,
                                                                height: 14.3,
                                                                decoration: BoxDecoration(
                                                                  border: Border(
                                                                    bottom: BorderSize(
                                                                      color: Color(0xFFAA9D9D),
                                                                      width: 1,
                                                                    ),
                                                                  ),
                                                                ),
                                                              ),
                                                            ),
                                                            Text(
                                                              '11/12/2022',
                                                              style: GoogleFonts.getFont(
                                                                'Fira Sans Condensed',
                                                                fontWeight: FontWeight.w500,
                                                                fontSize: 10,
                                                                color: Color(0xFF3E3636),
                                                              ),
                                                            ),
                                                          ],
                                                        ),
                                                      ),
                                                    ),
                                                  ),
                                                  Container(
                                                    margin: EdgeInsets.fromLTRB(1.4, 0, 0, 0),
                                                    child: SizedBox(
                                                      width: 106.8,
                                                      child: Container(
                                                        padding: EdgeInsets.fromLTRB(0, 0, 3.2, 4),
                                                        child: Stack(
                                                          clipBehavior: Clip.none,
                                                          children: [
                                                            Positioned(
                                                              left: 0,
                                                              right: 0,
                                                              bottom: 0,
                                                              child: Container(
                                                                width: 106.8,
                                                                height: 14.3,
                                                                decoration: BoxDecoration(
                                                                  border: Border(
                                                                    bottom: BorderSize(
                                                                      color: Color(0xFFAA9D9D),
                                                                      width: 1,
                                                                    ),
                                                                  ),
                                                                ),
                                                              ),
                                                            ),
                                                            Text(
                                                              '25/12/2022',
                                                              style: GoogleFonts.getFont(
                                                                'Fira Sans Condensed',
                                                                fontWeight: FontWeight.w500,
                                                                fontSize: 10,
                                                                color: Color(0xFF3E3636),
                                                              ),
                                                            ),
                                                            Positioned(
                                                              left: 0,
                                                              right: 0,
                                                              top: 0,
                                                              bottom: 0,
                                                              child: SizedBox(
                                                                width: 106.8,
                                                                height: 16,
                                                                child: Container(
                                                                  padding: EdgeInsets.fromLTRB(0, 0, 3.2, 4),
                                                                  child: Stack(
                                                                    clipBehavior: Clip.none,
                                                                    children: [
                                                                      Positioned(
                                                                        left: 0,
                                                                        right: 0,
                                                                        bottom: 0,
                                                                        child: Container(
                                                                          width: 106.8,
                                                                          height: 14.3,
                                                                          decoration: BoxDecoration(
                                                                            border: Border(
                                                                              bottom: BorderSize(
                                                                                color: Color(0xFFAA9D9D),
                                                                                width: 1,
                                                                              ),
                                                                            ),
                                                                          ),
                                                                        ),
                                                                      ),
                                                                      Text(
                                                                        '25/12/2022',
                                                                        style: GoogleFonts.getFont(
                                                                          'Fira Sans Condensed',
                                                                          fontWeight: FontWeight.w500,
                                                                          fontSize: 10,
                                                                          color: Color(0xFF3E3636),
                                                                        ),
                                                                      ),
                                                                    ],
                                                                  ),
                                                                ),
                                                              ),
                                                            ),
                                                          ],
                                                        ),
                                                      ),
                                                    ),
                                                  ),
                                                ],
                                              ),
                                            ),
                                          ),
                                          Container(
                                            margin: EdgeInsets.fromLTRB(0, 0, 0.4, 0.3),
                                            child: SizedBox(
                                              width: 107.9,
                                              child: Column(
                                                mainAxisAlignment: MainAxisAlignment.start,
                                                crossAxisAlignment: CrossAxisAlignment.start,
                                                children: [
                                                  Container(
                                                    margin: EdgeInsets.fromLTRB(0, 0, 1, 6.7),
                                                    child: Container(
                                                      decoration: BoxDecoration(
                                                        color: Color(0xFF4228D7),
                                                      ),
                                                      child: Container(
                                                        padding: EdgeInsets.fromLTRB(2.9, 2.4, 2.9, 5.9),
                                                        child: Stack(
                                                          clipBehavior: Clip.none,
                                                          children: [
                                                            Text(
                                                              'Data de entrega',
                                                              style: GoogleFonts.getFont(
                                                                'Fira Sans Condensed',
                                                                fontWeight: FontWeight.w600,
                                                                fontSize: 10,
                                                                color: Color(0xFFFFFFFF),
                                                              ),
                                                            ),
                                                            Positioned(
                                                              left: -2.9,
                                                              right: -2.9,
                                                              top: -2.4,
                                                              bottom: -5.9,
                                                              child: Container(
                                                                decoration: BoxDecoration(
                                                                  color: Color(0xFF4228D7),
                                                                ),
                                                                child: Container(
                                                                  width: 106.8,
                                                                  height: 20.3,
                                                                  padding: EdgeInsets.fromLTRB(19.1, 4, 19.1, 4.3),
                                                                  child: Text(
                                                                    'Data de entrega',
                                                                    style: GoogleFonts.getFont(
                                                                      'Fira Sans Condensed',
                                                                      fontWeight: FontWeight.w600,
                                                                      fontSize: 10,
                                                                      color: Color(0xFFFFFFFF),
                                                                    ),
                                                                  ),
                                                                ),
                                                              ),
                                                            ),
                                                          ],
                                                        ),
                                                      ),
                                                    ),
                                                  ),
                                                  Container(
                                                    margin: EdgeInsets.fromLTRB(0, 0, 1, 7),
                                                    child: SizedBox(
                                                      width: 106.8,
                                                      child: Container(
                                                        padding: EdgeInsets.fromLTRB(9, 0, 0, 4),
                                                        child: Stack(
                                                          clipBehavior: Clip.none,
                                                          children: [
                                                            Positioned(
                                                              left: -9,
                                                              right: 0,
                                                              bottom: -4,
                                                              child: Container(
                                                                width: 106.8,
                                                                height: 14.3,
                                                                decoration: BoxDecoration(
                                                                  border: Border(
                                                                    bottom: BorderSize(
                                                                      color: Color(0xFFAA9D9D),
                                                                      width: 1,
                                                                    ),
                                                                  ),
                                                                ),
                                                              ),
                                                            ),
                                                            Text(
                                                              '05/12/2022',
                                                              style: GoogleFonts.getFont(
                                                                'Fira Sans Condensed',
                                                                fontWeight: FontWeight.w500,
                                                                fontSize: 10,
                                                                color: Color(0xFF3E3636),
                                                              ),
                                                            ),
                                                            Positioned(
                                                              bottom: -4,
                                                              child: Container(
                                                                width: 106.8,
                                                                height: 14.3,
                                                                child: Container(
                                                                  width: 106.8,
                                                                  height: 14.3,
                                                                  decoration: BoxDecoration(
                                                                    border: Border(
                                                                      bottom: BorderSize(
                                                                        color: Color(0xFFAA9D9D),
                                                                        width: 1,
                                                                      ),
                                                                    ),
                                                                  ),
                                                                ),
                                                              ),
                                                            ),
                                                          ],
                                                        ),
                                                      ),
                                                    ),
                                                  ),
                                                  Container(
                                                    margin: EdgeInsets.fromLTRB(0, 0, 1, 5),
                                                    child: SizedBox(
                                                      width: 106.8,
                                                      child: Container(
                                                        padding: EdgeInsets.fromLTRB(9, 0, 0, 4),
                                                        child: Stack(
                                                          clipBehavior: Clip.none,
                                                          children: [
                                                            Positioned(
                                                              left: -9,
                                                              right: 0,
                                                              bottom: -4,
                                                              child: Container(
                                                                width: 106.8,
                                                                height: 14.3,
                                                                decoration: BoxDecoration(
                                                                  border: Border(
                                                                    bottom: BorderSize(
                                                                      color: Color(0xFFAA9D9D),
                                                                      width: 1,
                                                                    ),
                                                                  ),
                                                                ),
                                                              ),
                                                            ),
                                                            Text(
                                                              '05/12/2022',
                                                              style: GoogleFonts.getFont(
                                                                'Fira Sans Condensed',
                                                                fontWeight: FontWeight.w500,
                                                                fontSize: 10,
                                                                color: Color(0xFF3E3636),
                                                              ),
                                                            ),
                                                          ],
                                                        ),
                                                      ),
                                                    ),
                                                  ),
                                                  Container(
                                                    margin: EdgeInsets.fromLTRB(1, 0, 0, 0),
                                                    child: SizedBox(
                                                      width: 106.8,
                                                      child: Container(
                                                        padding: EdgeInsets.fromLTRB(9, 0, 0, 4),
                                                        child: Stack(
                                                          clipBehavior: Clip.none,
                                                          children: [
                                                            Positioned(
                                                              left: -9,
                                                              right: 0,
                                                              bottom: -4,
                                                              child: Container(
                                                                width: 106.8,
                                                                height: 14.3,
                                                                decoration: BoxDecoration(
                                                                  border: Border(
                                                                    bottom: BorderSize(
                                                                      color: Color(0xFFAA9D9D),
                                                                      width: 1,
                                                                    ),
                                                                  ),
                                                                ),
                                                              ),
                                                            ),
                                                            Text(
                                                              '05/12/2022',
                                                              style: GoogleFonts.getFont(
                                                                'Fira Sans Condensed',
                                                                fontWeight: FontWeight.w500,
                                                                fontSize: 10,
                                                                color: Color(0xFF3E3636),
                                                              ),
                                                            ),
                                                            Positioned(
                                                              bottom: -4,
                                                              child: Container(
                                                                width: 106.8,
                                                                height: 14.3,
                                                                child: Container(
                                                                  width: 106.8,
                                                                  height: 14.3,
                                                                  decoration: BoxDecoration(
                                                                    border: Border(
                                                                      bottom: BorderSize(
                                                                        color: Color(0xFFAA9D9D),
                                                                        width: 1,
                                                                      ),
                                                                    ),
                                                                  ),
                                                                ),
                                                              ),
                                                            ),
                                                          ],
                                                        ),
                                                      ),
                                                    ),
                                                  ),
                                                ],
                                              ),
                                            ),
                                          ),
                                          Container(
                                            margin: EdgeInsets.fromLTRB(0, 0, 0.1, 0.3),
                                            child: SizedBox(
                                              width: 127.3,
                                              child: Column(
                                                mainAxisAlignment: MainAxisAlignment.start,
                                                crossAxisAlignment: CrossAxisAlignment.center,
                                                children: [
                                                  Container(
                                                    margin: EdgeInsets.fromLTRB(0, 0, 0.7, 7.7),
                                                    child: Container(
                                                      decoration: BoxDecoration(
                                                        color: Color(0xFF4228D7),
                                                      ),
                                                      child: SizedBox(
                                                        width: 126.5,
                                                        child: Container(
                                                          padding: EdgeInsets.fromLTRB(3.3, 4, 0, 4.3),
                                                          child: Stack(
                                                            clipBehavior: Clip.none,
                                                            children: [
                                                              Text(
                                                                'Setor',
                                                                style: GoogleFonts.getFont(
                                                                  'Fira Sans Condensed',
                                                                  fontWeight: FontWeight.w600,
                                                                  fontSize: 10,
                                                                  color: Color(0xFFFFFFFF),
                                                                ),
                                                              ),
                                                              Positioned(
                                                                left: -3.3,
                                                                right: 0,
                                                                top: -4,
                                                                bottom: -4.3,
                                                                child: Container(
                                                                  decoration: BoxDecoration(
                                                                    color: Color(0xFF4228D7),
                                                                  ),
                                                                  child: Container(
                                                                    width: 126.5,
                                                                    height: 20.3,
                                                                    padding: EdgeInsets.fromLTRB(3.3, 4, 0, 4.3),
                                                                    child: Text(
                                                                      'Setor',
                                                                      style: GoogleFonts.getFont(
                                                                        'Fira Sans Condensed',
                                                                        fontWeight: FontWeight.w600,
                                                                        fontSize: 10,
                                                                        color: Color(0xFFFFFFFF),
                                                                      ),
                                                                    ),
                                                                  ),
                                                                ),
                                                              ),
                                                            ],
                                                          ),
                                                        ),
                                                      ),
                                                    ),
                                                  ),
                                                  Container(
                                                    margin: EdgeInsets.fromLTRB(0, 0, 0.7, 8),
                                                    child: SizedBox(
                                                      width: 126.5,
                                                      child: Container(
                                                        padding: EdgeInsets.fromLTRB(5.3, 0, 0, 3),
                                                        child: Stack(
                                                          clipBehavior: Clip.none,
                                                          children: [
                                                            Positioned(
                                                              left: -5.3,
                                                              right: 0,
                                                              bottom: -3,
                                                              child: Container(
                                                                width: 126.5,
                                                                height: 14.3,
                                                                decoration: BoxDecoration(
                                                                  border: Border(
                                                                    bottom: BorderSize(
                                                                      color: Color(0xFFAA9D9D),
                                                                      width: 1,
                                                                    ),
                                                                  ),
                                                                ),
                                                              ),
                                                            ),
                                                            Text(
                                                              'Bloco C',
                                                              style: GoogleFonts.getFont(
                                                                'Fira Sans Condensed',
                                                                fontWeight: FontWeight.w500,
                                                                fontSize: 10,
                                                                color: Color(0xFF3E3636),
                                                              ),
                                                            ),
                                                          ],
                                                        ),
                                                      ),
                                                    ),
                                                  ),
                                                  Container(
                                                    margin: EdgeInsets.fromLTRB(0, 0, 0.7, 6),
                                                    child: SizedBox(
                                                      width: 126.5,
                                                      child: Container(
                                                        padding: EdgeInsets.fromLTRB(5.3, 0, 0, 3),
                                                        child: Stack(
                                                          clipBehavior: Clip.none,
                                                          children: [
                                                            Positioned(
                                                              left: -5.3,
                                                              right: 0,
                                                              bottom: -3,
                                                              child: Container(
                                                                width: 126.5,
                                                                height: 14.3,
                                                                decoration: BoxDecoration(
                                                                  border: Border(
                                                                    bottom: BorderSize(
                                                                      color: Color(0xFFAA9D9D),
                                                                      width: 1,
                                                                    ),
                                                                  ),
                                                                ),
                                                              ),
                                                            ),
                                                            Text(
                                                              'Bloco C',
                                                              style: GoogleFonts.getFont(
                                                                'Fira Sans Condensed',
                                                                fontWeight: FontWeight.w500,
                                                                fontSize: 10,
                                                                color: Color(0xFF3E3636),
                                                              ),
                                                            ),
                                                          ],
                                                        ),
                                                      ),
                                                    ),
                                                  ),
                                                  Container(
                                                    margin: EdgeInsets.fromLTRB(0.7, 0, 0, 0),
                                                    child: SizedBox(
                                                      width: 126.5,
                                                      child: Container(
                                                        padding: EdgeInsets.fromLTRB(5.3, 0, 0, 3),
                                                        child: Stack(
                                                          clipBehavior: Clip.none,
                                                          children: [
                                                            Positioned(
                                                              left: -5.3,
                                                              right: 0,
                                                              bottom: -3,
                                                              child: Container(
                                                                width: 126.5,
                                                                height: 14.3,
                                                                decoration: BoxDecoration(
                                                                  border: Border(
                                                                    bottom: BorderSize(
                                                                      color: Color(0xFFAA9D9D),
                                                                      width: 1,
                                                                    ),
                                                                  ),
                                                                ),
                                                              ),
                                                            ),
                                                            Text(
                                                              'Bloco C',
                                                              style: GoogleFonts.getFont(
                                                                'Fira Sans Condensed',
                                                                fontWeight: FontWeight.w500,
                                                                fontSize: 10,
                                                                color: Color(0xFF3E3636),
                                                              ),
                                                            ),
                                                            Positioned(
                                                              left: -5.3,
                                                              right: 0,
                                                              top: 0,
                                                              bottom: -3,
                                                              child: SizedBox(
                                                                width: 126.5,
                                                                height: 15,
                                                                child: Container(
                                                                  padding: EdgeInsets.fromLTRB(5.3, 0, 0, 3),
                                                                  child: Stack(
                                                                    clipBehavior: Clip.none,
                                                                    children: [
                                                                      Positioned(
                                                                        left: -5.3,
                                                                        right: 0,
                                                                        bottom: -3,
                                                                        child: Container(
                                                                          width: 126.5,
                                                                          height: 14.3,
                                                                          decoration: BoxDecoration(
                                                                            border: Border(
                                                                              bottom: BorderSize(
                                                                                color: Color(0xFFAA9D9D),
                                                                                width: 1,
                                                                              ),
                                                                            ),
                                                                          ),
                                                                        ),
                                                                      ),
                                                                      Text(
                                                                        'Bloco C',
                                                                        style: GoogleFonts.getFont(
                                                                          'Fira Sans Condensed',
                                                                          fontWeight: FontWeight.w500,
                                                                          fontSize: 10,
                                                                          color: Color(0xFF3E3636),
                                                                        ),
                                                                      ),
                                                                    ],
                                                                  ),
                                                                ),
                                                              ),
                                                            ),
                                                          ],
                                                        ),
                                                      ),
                                                    ),
                                                  ),
                                                ],
                                              ),
                                            ),
                                          ),
                                          Container(
                                            margin: EdgeInsets.fromLTRB(0, 0, 0.4, 0.3),
                                            child: SizedBox(
                                              width: 146,
                                              child: Column(
                                                mainAxisAlignment: MainAxisAlignment.start,
                                                crossAxisAlignment: CrossAxisAlignment.center,
                                                children: [
                                                  Container(
                                                    margin: EdgeInsets.fromLTRB(0, 0, 1.4, 7.7),
                                                    child: Container(
                                                      decoration: BoxDecoration(
                                                        color: Color(0xFF4228D7),
                                                      ),
                                                      child: Container(
                                                        width: 144.6,
                                                        padding: EdgeInsets.fromLTRB(2.3, 4, 0, 4.3),
                                                        child: Text(
                                                          'Requerente',
                                                          style: GoogleFonts.getFont(
                                                            'Fira Sans Condensed',
                                                            fontWeight: FontWeight.w600,
                                                            fontSize: 10,
                                                            color: Color(0xFFFFFFFF),
                                                          ),
                                                        ),
                                                      ),
                                                    ),
                                                  ),
                                                  Container(
                                                    margin: EdgeInsets.fromLTRB(0, 0, 1.4, 8),
                                                    child: SizedBox(
                                                      width: 144.6,
                                                      child: Container(
                                                        padding: EdgeInsets.fromLTRB(0, 0, 2.2, 3),
                                                        child: Stack(
                                                          clipBehavior: Clip.none,
                                                          children: [
                                                            Positioned(
                                                              left: 0,
                                                              right: 0,
                                                              bottom: 0,
                                                              child: Container(
                                                                width: 144.6,
                                                                height: 14.3,
                                                                decoration: BoxDecoration(
                                                                  border: Border(
                                                                    bottom: BorderSize(
                                                                      color: Color(0xFFAA9D9D),
                                                                      width: 1,
                                                                    ),
                                                                  ),
                                                                ),
                                                              ),
                                                            ),
                                                            Text(
                                                              'Germano',
                                                              style: GoogleFonts.getFont(
                                                                'Fira Sans Condensed',
                                                                fontWeight: FontWeight.w500,
                                                                fontSize: 10,
                                                                color: Color(0xFF3E3636),
                                                              ),
                                                            ),
                                                          ],
                                                        ),
                                                      ),
                                                    ),
                                                  ),
                                                  Container(
                                                    margin: EdgeInsets.fromLTRB(0, 0, 1.4, 6),
                                                    child: SizedBox(
                                                      width: 144.6,
                                                      child: Container(
                                                        padding: EdgeInsets.fromLTRB(0, 0, 2.2, 3),
                                                        child: Stack(
                                                          clipBehavior: Clip.none,
                                                          children: [
                                                            Positioned(
                                                              left: 0,
                                                              right: 0,
                                                              bottom: 0,
                                                              child: Container(
                                                                width: 144.6,
                                                                height: 14.3,
                                                                decoration: BoxDecoration(
                                                                  border: Border(
                                                                    bottom: BorderSize(
                                                                      color: Color(0xFFAA9D9D),
                                                                      width: 1,
                                                                    ),
                                                                  ),
                                                                ),
                                                              ),
                                                            ),
                                                            Text(
                                                              'Germano',
                                                              style: GoogleFonts.getFont(
                                                                'Fira Sans Condensed',
                                                                fontWeight: FontWeight.w500,
                                                                fontSize: 10,
                                                                color: Color(0xFF3E3636),
                                                              ),
                                                            ),
                                                          ],
                                                        ),
                                                      ),
                                                    ),
                                                  ),
                                                  Container(
                                                    margin: EdgeInsets.fromLTRB(1.4, 0, 0, 0),
                                                    child: SizedBox(
                                                      width: 144.6,
                                                      child: Container(
                                                        padding: EdgeInsets.fromLTRB(0, 0, 2.2, 3),
                                                        child: Stack(
                                                          clipBehavior: Clip.none,
                                                          children: [
                                                            Positioned(
                                                              left: 0,
                                                              right: 0,
                                                              bottom: 0,
                                                              child: Container(
                                                                width: 144.6,
                                                                height: 14.3,
                                                                decoration: BoxDecoration(
                                                                  border: Border(
                                                                    bottom: BorderSize(
                                                                      color: Color(0xFFAA9D9D),
                                                                      width: 1,
                                                                    ),
                                                                  ),
                                                                ),
                                                              ),
                                                            ),
                                                            Text(
                                                              'Germano',
                                                              style: GoogleFonts.getFont(
                                                                'Fira Sans Condensed',
                                                                fontWeight: FontWeight.w500,
                                                                fontSize: 10,
                                                                color: Color(0xFF3E3636),
                                                              ),
                                                            ),
                                                            Positioned(
                                                              left: 0,
                                                              right: 0,
                                                              top: 0,
                                                              bottom: 0,
                                                              child: SizedBox(
                                                                width: 144.6,
                                                                height: 15,
                                                                child: Container(
                                                                  padding: EdgeInsets.fromLTRB(0, 0, 2.2, 3),
                                                                  child: Stack(
                                                                    clipBehavior: Clip.none,
                                                                    children: [
                                                                      Positioned(
                                                                        left: 0,
                                                                        right: 0,
                                                                        bottom: 0,
                                                                        child: Container(
                                                                          width: 144.6,
                                                                          height: 14.3,
                                                                          decoration: BoxDecoration(
                                                                            border: Border(
                                                                              bottom: BorderSize(
                                                                                color: Color(0xFFAA9D9D),
                                                                                width: 1,
                                                                              ),
                                                                            ),
                                                                          ),
                                                                        ),
                                                                      ),
                                                                      Text(
                                                                        'Germano',
                                                                        style: GoogleFonts.getFont(
                                                                          'Fira Sans Condensed',
                                                                          fontWeight: FontWeight.w500,
                                                                          fontSize: 10,
                                                                          color: Color(0xFF3E3636),
                                                                        ),
                                                                      ),
                                                                    ],
                                                                  ),
                                                                ),
                                                              ),
                                                            ),
                                                          ],
                                                        ),
                                                      ),
                                                    ),
                                                  ),
                                                ],
                                              ),
                                            ),
                                          ),
                                          Container(
                                            margin: EdgeInsets.fromLTRB(0, 0, 0.8, 0.3),
                                            child: SizedBox(
                                              width: 145.6,
                                              child: Column(
                                                mainAxisAlignment: MainAxisAlignment.start,
                                                crossAxisAlignment: CrossAxisAlignment.center,
                                                children: [
                                                  Container(
                                                    margin: EdgeInsets.fromLTRB(0, 0, 1, 7.7),
                                                    child: Container(
                                                      decoration: BoxDecoration(
                                                        color: Color(0xFF4228D7),
                                                      ),
                                                      child: Container(
                                                        width: 144.6,
                                                        padding: EdgeInsets.fromLTRB(0, 4, 4, 4.3),
                                                        child: Text(
                                                          'Equipamento',
                                                          style: GoogleFonts.getFont(
                                                            'Fira Sans Condensed',
                                                            fontWeight: FontWeight.w600,
                                                            fontSize: 10,
                                                            color: Color(0xFFFFFFFF),
                                                          ),
                                                        ),
                                                      ),
                                                    ),
                                                  ),
                                                  Container(
                                                    margin: EdgeInsets.fromLTRB(0, 0, 1, 8),
                                                    child: SizedBox(
                                                      width: 144.6,
                                                      child: Container(
                                                        padding: EdgeInsets.fromLTRB(0, 0, 3.2, 3),
                                                        child: Stack(
                                                          clipBehavior: Clip.none,
                                                          children: [
                                                            Positioned(
                                                              left: 0,
                                                              right: 0,
                                                              bottom: 0,
                                                              child: Container(
                                                                width: 144.6,
                                                                height: 14.3,
                                                                decoration: BoxDecoration(
                                                                  border: Border(
                                                                    bottom: BorderSize(
                                                                      color: Color(0xFFAA9D9D),
                                                                      width: 1,
                                                                    ),
                                                                  ),
                                                                ),
                                                              ),
                                                            ),
                                                            Text(
                                                              'Microfone',
                                                              style: GoogleFonts.getFont(
                                                                'Fira Sans Condensed',
                                                                fontWeight: FontWeight.w500,
                                                                fontSize: 10,
                                                                color: Color(0xFF3E3636),
                                                              ),
                                                            ),
                                                          ],
                                                        ),
                                                      ),
                                                    ),
                                                  ),
                                                  Container(
                                                    margin: EdgeInsets.fromLTRB(0, 0, 1, 6),
                                                    child: SizedBox(
                                                      width: 144.6,
                                                      child: Container(
                                                        padding: EdgeInsets.fromLTRB(0, 0, 7, 3),
                                                        child: Stack(
                                                          clipBehavior: Clip.none,
                                                          children: [
                                                            Positioned(
                                                              left: 0,
                                                              right: 0,
                                                              bottom: 0,
                                                              child: Container(
                                                                width: 144.6,
                                                                height: 14.3,
                                                                decoration: BoxDecoration(
                                                                  border: Border(
                                                                    bottom: BorderSize(
                                                                      color: Color(0xFFAA9D9D),
                                                                      width: 1,
                                                                    ),
                                                                  ),
                                                                ),
                                                              ),
                                                            ),
                                                            Text(
                                                              'Cabo P10',
                                                              style: GoogleFonts.getFont(
                                                                'Fira Sans Condensed',
                                                                fontWeight: FontWeight.w500,
                                                                fontSize: 10,
                                                                color: Color(0xFF3E3636),
                                                              ),
                                                            ),
                                                          ],
                                                        ),
                                                      ),
                                                    ),
                                                  ),
                                                  Container(
                                                    margin: EdgeInsets.fromLTRB(1, 0, 0, 0),
                                                    child: SizedBox(
                                                      width: 144.6,
                                                      child: Container(
                                                        padding: EdgeInsets.fromLTRB(0, 0, 4, 3),
                                                        child: Stack(
                                                          clipBehavior: Clip.none,
                                                          children: [
                                                            Positioned(
                                                              left: 0,
                                                              right: 0,
                                                              bottom: 0,
                                                              child: Container(
                                                                width: 144.6,
                                                                height: 14.3,
                                                                decoration: BoxDecoration(
                                                                  border: Border(
                                                                    bottom: BorderSize(
                                                                      color: Color(0xFFAA9D9D),
                                                                      width: 1,
                                                                    ),
                                                                  ),
                                                                ),
                                                              ),
                                                            ),
                                                            Text(
                                                              'Datashow',
                                                              style: GoogleFonts.getFont(
                                                                'Fira Sans Condensed',
                                                                fontWeight: FontWeight.w500,
                                                                fontSize: 10,
                                                                color: Color(0xFF3E3636),
                                                              ),
                                                            ),
                                                            Positioned(
                                                              left: 0,
                                                              right: 0,
                                                              top: 0,
                                                              bottom: 0,
                                                              child: SizedBox(
                                                                width: 144.6,
                                                                height: 15,
                                                                child: Container(
                                                                  padding: EdgeInsets.fromLTRB(0, 0, 4, 3),
                                                                  child: Stack(
                                                                    clipBehavior: Clip.none,
                                                                    children: [
                                                                      Positioned(
                                                                        left: 0,
                                                                        right: 0,
                                                                        bottom: 0,
                                                                        child: Container(
                                                                          width: 144.6,
                                                                          height: 14.3,
                                                                          decoration: BoxDecoration(
                                                                            border: Border(
                                                                              bottom: BorderSize(
                                                                                color: Color(0xFFAA9D9D),
                                                                                width: 1,
                                                                              ),
                                                                            ),
                                                                          ),
                                                                        ),
                                                                      ),
                                                                      Text(
                                                                        'Datashow',
                                                                        style: GoogleFonts.getFont(
                                                                          'Fira Sans Condensed',
                                                                          fontWeight: FontWeight.w500,
                                                                          fontSize: 10,
                                                                          color: Color(0xFF3E3636),
                                                                        ),
                                                                      ),
                                                                    ],
                                                                  ),
                                                                ),
                                                              ),
                                                            ),
                                                          ],
                                                        ),
                                                      ),
                                                    ),
                                                  ),
                                                ],
                                              ),
                                            ),
                                          ),
                                          Container(
                                            margin: EdgeInsets.fromLTRB(0, 0, 1.1, 0),
                                            child: SizedBox(
                                              width: 145.2,
                                              child: Column(
                                                mainAxisAlignment: MainAxisAlignment.start,
                                                crossAxisAlignment: CrossAxisAlignment.center,
                                                children: [
                                                  Container(
                                                    margin: EdgeInsets.fromLTRB(0, 0, 0.6, 8.4),
                                                    child: Container(
                                                      decoration: BoxDecoration(
                                                        color: Color(0xFF4228D7),
                                                      ),
                                                      child: SizedBox(
                                                        width: 144.6,
                                                        child: Container(
                                                          padding: EdgeInsets.fromLTRB(0, 3.6, 19.3, 4.7),
                                                          child: Stack(
                                                            clipBehavior: Clip.none,
                                                            children: [
                                                              Text(
                                                                'Nº Patrimônio',
                                                                style: GoogleFonts.getFont(
                                                                  'Fira Sans Condensed',
                                                                  fontWeight: FontWeight.w600,
                                                                  fontSize: 10,
                                                                  color: Color(0xFFFFFFFF),
                                                                ),
                                                              ),
                                                              Positioned(
                                                                left: 0,
                                                                right: 0,
                                                                top: 0,
                                                                bottom: 0,
                                                                child: Container(
                                                                  decoration: BoxDecoration(
                                                                    color: Color(0xFF4228D7),
                                                                  ),
                                                                  child: SizedBox(
                                                                    width: 144.6,
                                                                    height: 20.3,
                                                                    child: Container(
                                                                      padding: EdgeInsets.fromLTRB(0, 4, 10.9, 4.3),
                                                                      child: Stack(
                                                                        clipBehavior: Clip.none,
                                                                        children: [
                                                                          Text(
                                                                            'Nº Patrimônio',
                                                                            style: GoogleFonts.getFont(
                                                                              'Fira Sans Condensed',
                                                                              fontWeight: FontWeight.w600,
                                                                              fontSize: 10,
                                                                              color: Color(0xFFFFFFFF),
                                                                            ),
                                                                          ),
                                                                          Positioned(
                                                                            left: 0,
                                                                            right: 0,
                                                                            top: 0,
                                                                            bottom: 0,
                                                                            child: Container(
                                                                              decoration: BoxDecoration(
                                                                                color: Color(0xFF4228D7),
                                                                              ),
                                                                              child: Container(
                                                                                width: 144.6,
                                                                                height: 20.3,
                                                                                padding: EdgeInsets.fromLTRB(0, 4, 10.9, 4.3),
                                                                                child: Text(
                                                                                  'Nº Patrimônio',
                                                                                  style: GoogleFonts.getFont(
                                                                                    'Fira Sans Condensed',
                                                                                    fontWeight: FontWeight.w600,
                                                                                    fontSize: 10,
                                                                                    color: Color(0xFFFFFFFF),
                                                                                  ),
                                                                                ),
                                                                              ),
                                                                            ),
                                                                          ),
                                                                        ],
                                                                      ),
                                                                    ),
                                                                  ),
                                                                ),
                                                              ),
                                                            ],
                                                          ),
                                                        ),
                                                      ),
                                                    ),
                                                  ),
                                                  Container(
                                                    margin: EdgeInsets.fromLTRB(0, 0, 0.6, 8.7),
                                                    width: 144.6,
                                                    decoration: BoxDecoration(
                                                      border: Border(
                                                        bottom: BorderSize(
                                                          color: Color(0xFFAA9D9D),
                                                          width: 1,
                                                        ),
                                                      ),
                                                    ),
                                                    child: Container(
                                                      padding: EdgeInsets.fromLTRB(0, 0.3, 9.5, 2),
                                                      child: Stack(
                                                        clipBehavior: Clip.none,
                                                        children: [
                                                          Text(
                                                            'MIC409',
                                                            style: GoogleFonts.getFont(
                                                              'Fira Sans Condensed',
                                                              fontWeight: FontWeight.w500,
                                                              fontSize: 10,
                                                              color: Color(0xFF3E3636),
                                                            ),
                                                          ),
                                                          Positioned(
                                                            bottom: 0,
                                                            child: Container(
                                                              width: 144.6,
                                                              height: 14.3,
                                                              child: Container(
                                                                width: 144.6,
                                                                height: 14.3,
                                                                decoration: BoxDecoration(
                                                                  border: Border(
                                                                    bottom: BorderSize(
                                                                      color: Color(0xFFAA9D9D),
                                                                      width: 1,
                                                                    ),
                                                                  ),
                                                                ),
                                                              ),
                                                            ),
                                                          ),
                                                        ],
                                                      ),
                                                    ),
                                                  ),
                                                  Container(
                                                    margin: EdgeInsets.fromLTRB(0, 0, 0.6, 7),
                                                    width: 144.6,
                                                    padding: EdgeInsets.fromLTRB(0, 0.3, 8.7, 2),
                                                    decoration: BoxDecoration(
                                                      border: Border(
                                                        bottom: BorderSize(
                                                          color: Color(0xFFAA9D9D),
                                                          width: 1,
                                                        ),
                                                      ),
                                                    ),
                                                    child: Text(
                                                      'CAB010',
                                                      style: GoogleFonts.getFont(
                                                        'Fira Sans Condensed',
                                                        fontWeight: FontWeight.w500,
                                                        fontSize: 10,
                                                        color: Color(0xFF3E3636),
                                                      ),
                                                    ),
                                                  ),
                                                  Container(
                                                    margin: EdgeInsets.fromLTRB(0.6, 0, 0, 0),
                                                    width: 144.6,
                                                    decoration: BoxDecoration(
                                                      border: Border(
                                                        bottom: BorderSize(
                                                          color: Color(0xFFAA9D9D),
                                                          width: 1,
                                                        ),
                                                      ),
                                                    ),
                                                    child: Container(
                                                      padding: EdgeInsets.fromLTRB(0, 0.3, 9.7, 2),
                                                      child: Stack(
                                                        clipBehavior: Clip.none,
                                                        children: [
                                                          Text(
                                                            'Dat500',
                                                            style: GoogleFonts.getFont(
                                                              'Fira Sans Condensed',
                                                              fontWeight: FontWeight.w500,
                                                              fontSize: 10,
                                                              color: Color(0xFF3E3636),
                                                            ),
                                                          ),
                                                          Positioned(
                                                            left: 0,
                                                            right: 0,
                                                            top: 0,
                                                            bottom: 0,
                                                            child: Container(
                                                              width: 144.6,
                                                              height: 14.3,
                                                              padding: EdgeInsets.fromLTRB(0, 0.3, 9.7, 2),
                                                              decoration: BoxDecoration(
                                                                border: Border(
                                                                  bottom: BorderSize(
                                                                    color: Color(0xFFAA9D9D),
                                                                    width: 1,
                                                                  ),
                                                                ),
                                                              ),
                                                              child: Text(
                                                                'Dat500',
                                                                style: GoogleFonts.getFont(
                                                                  'Fira Sans Condensed',
                                                                  fontWeight: FontWeight.w500,
                                                                  fontSize: 10,
                                                                  color: Color(0xFF3E3636),
                                                                ),
                                                              ),
                                                            ),
                                                          ),
                                                        ],
                                                      ),
                                                    ),
                                                  ),
                                                ],
                                              ),
                                            ),
                                          ),
                                          Container(
                                            margin: EdgeInsets.fromLTRB(0, 0, 0.4, 0.3),
                                            child: SizedBox(
                                              width: 145.9,
                                              child: Column(
                                                mainAxisAlignment: MainAxisAlignment.start,
                                                crossAxisAlignment: CrossAxisAlignment.center,
                                                children: [
                                                  Container(
                                                    margin: EdgeInsets.fromLTRB(0, 0, 1.3, 6.7),
                                                    child: Container(
                                                      decoration: BoxDecoration(
                                                        color: Color(0xFF4228D7),
                                                      ),
                                                      child: SizedBox(
                                                        width: 144.6,
                                                        child: Container(
                                                          padding: EdgeInsets.fromLTRB(0, 3.6, 19.3, 4.7),
                                                          child: Stack(
                                                            clipBehavior: Clip.none,
                                                            children: [
                                                              Text(
                                                                'Nº Patrimônio',
                                                                style: GoogleFonts.getFont(
                                                                  'Fira Sans Condensed',
                                                                  fontWeight: FontWeight.w600,
                                                                  fontSize: 10,
                                                                  color: Color(0xFFFFFFFF),
                                                                ),
                                                              ),
                                                              Positioned(
                                                                left: 0,
                                                                right: 0,
                                                                top: 0,
                                                                bottom: 0,
                                                                child: Container(
                                                                  decoration: BoxDecoration(
                                                                    color: Color(0xFF4228D7),
                                                                  ),
                                                                  child: SizedBox(
                                                                    width: 144.6,
                                                                    height: 20.3,
                                                                    child: Container(
                                                                      padding: EdgeInsets.fromLTRB(12.2, 4, 0, 4.3),
                                                                      child: Stack(
                                                                        clipBehavior: Clip.none,
                                                                        children: [
                                                                          Text(
                                                                            'Responsavel',
                                                                            style: GoogleFonts.getFont(
                                                                              'Fira Sans Condensed',
                                                                              fontWeight: FontWeight.w600,
                                                                              fontSize: 10,
                                                                              color: Color(0xFFFFFFFF),
                                                                            ),
                                                                          ),
                                                                          Positioned(
                                                                            left: -12.2,
                                                                            right: 0,
                                                                            top: -4,
                                                                            bottom: -4.3,
                                                                            child: Container(
                                                                              decoration: BoxDecoration(
                                                                                color: Color(0xFF4228D7),
                                                                              ),
                                                                              child: Container(
                                                                                width: 144.6,
                                                                                height: 20.3,
                                                                                padding: EdgeInsets.fromLTRB(12.2, 4, 0, 4.3),
                                                                                child: Text(
                                                                                  'Responsavel',
                                                                                  style: GoogleFonts.getFont(
                                                                                    'Fira Sans Condensed',
                                                                                    fontWeight: FontWeight.w600,
                                                                                    fontSize: 10,
                                                                                    color: Color(0xFFFFFFFF),
                                                                                  ),
                                                                                ),
                                                                              ),
                                                                            ),
                                                                          ),
                                                                        ],
                                                                      ),
                                                                    ),
                                                                  ),
                                                                ),
                                                              ),
                                                            ],
                                                          ),
                                                        ),
                                                      ),
                                                    ),
                                                  ),
                                                  Container(
                                                    margin: EdgeInsets.fromLTRB(0, 0, 1.3, 7),
                                                    child: SizedBox(
                                                      width: 144.6,
                                                      child: Container(
                                                        padding: EdgeInsets.fromLTRB(17.3, 0, 0, 4),
                                                        child: Stack(
                                                          clipBehavior: Clip.none,
                                                          children: [
                                                            Positioned(
                                                              left: -17.3,
                                                              right: 0,
                                                              bottom: -4,
                                                              child: Container(
                                                                width: 144.6,
                                                                height: 14.3,
                                                                decoration: BoxDecoration(
                                                                  border: Border(
                                                                    bottom: BorderSize(
                                                                      color: Color(0xFFAA9D9D),
                                                                      width: 1,
                                                                    ),
                                                                  ),
                                                                ),
                                                              ),
                                                            ),
                                                            Text(
                                                              'Waltair',
                                                              style: GoogleFonts.getFont(
                                                                'Fira Sans Condensed',
                                                                fontWeight: FontWeight.w500,
                                                                fontSize: 10,
                                                                color: Color(0xFF3E3636),
                                                              ),
                                                            ),
                                                            Positioned(
                                                              bottom: -4,
                                                              child: Container(
                                                                width: 144.6,
                                                                height: 14.3,
                                                                child: Container(
                                                                  width: 144.6,
                                                                  height: 14.3,
                                                                  decoration: BoxDecoration(
                                                                    border: Border(
                                                                      bottom: BorderSize(
                                                                        color: Color(0xFFAA9D9D),
                                                                        width: 1,
                                                                      ),
                                                                    ),
                                                                  ),
                                                                ),
                                                              ),
                                                            ),
                                                          ],
                                                        ),
                                                      ),
                                                    ),
                                                  ),
                                                  Container(
                                                    margin: EdgeInsets.fromLTRB(0, 0, 1.3, 5),
                                                    child: SizedBox(
                                                      width: 144.6,
                                                      child: Container(
                                                        padding: EdgeInsets.fromLTRB(17.3, 0, 0, 4),
                                                        child: Stack(
                                                          clipBehavior: Clip.none,
                                                          children: [
                                                            Positioned(
                                                              left: -17.3,
                                                              right: 0,
                                                              bottom: -4,
                                                              child: Container(
                                                                width: 144.6,
                                                                height: 14.3,
                                                                decoration: BoxDecoration(
                                                                  border: Border(
                                                                    bottom: BorderSize(
                                                                      color: Color(0xFFAA9D9D),
                                                                      width: 1,
                                                                    ),
                                                                  ),
                                                                ),
                                                              ),
                                                            ),
                                                            Text(
                                                              'Waltair',
                                                              style: GoogleFonts.getFont(
                                                                'Fira Sans Condensed',
                                                                fontWeight: FontWeight.w500,
                                                                fontSize: 10,
                                                                color: Color(0xFF3E3636),
                                                              ),
                                                            ),
                                                          ],
                                                        ),
                                                      ),
                                                    ),
                                                  ),
                                                  Container(
                                                    margin: EdgeInsets.fromLTRB(1.3, 0, 0, 0),
                                                    child: SizedBox(
                                                      width: 144.6,
                                                      child: Container(
                                                        padding: EdgeInsets.fromLTRB(17.3, 0, 0, 4),
                                                        child: Stack(
                                                          clipBehavior: Clip.none,
                                                          children: [
                                                            Positioned(
                                                              left: -17.3,
                                                              right: 0,
                                                              bottom: -4,
                                                              child: Container(
                                                                width: 144.6,
                                                                height: 14.3,
                                                                decoration: BoxDecoration(
                                                                  border: Border(
                                                                    bottom: BorderSize(
                                                                      color: Color(0xFFAA9D9D),
                                                                      width: 1,
                                                                    ),
                                                                  ),
                                                                ),
                                                              ),
                                                            ),
                                                            Text(
                                                              'Waltair',
                                                              style: GoogleFonts.getFont(
                                                                'Fira Sans Condensed',
                                                                fontWeight: FontWeight.w500,
                                                                fontSize: 10,
                                                                color: Color(0xFF3E3636),
                                                              ),
                                                            ),
                                                            Positioned(
                                                              left: -17.3,
                                                              right: 0,
                                                              top: 0,
                                                              bottom: -4,
                                                              child: SizedBox(
                                                                width: 144.6,
                                                                height: 16,
                                                                child: Container(
                                                                  padding: EdgeInsets.fromLTRB(17.3, 0, 0, 4),
                                                                  child: Stack(
                                                                    clipBehavior: Clip.none,
                                                                    children: [
                                                                      Positioned(
                                                                        left: -17.3,
                                                                        right: 0,
                                                                        bottom: -4,
                                                                        child: Container(
                                                                          width: 144.6,
                                                                          height: 14.3,
                                                                          decoration: BoxDecoration(
                                                                            border: Border(
                                                                              bottom: BorderSize(
                                                                                color: Color(0xFFAA9D9D),
                                                                                width: 1,
                                                                              ),
                                                                            ),
                                                                          ),
                                                                        ),
                                                                      ),
                                                                      Text(
                                                                        'Waltair',
                                                                        style: GoogleFonts.getFont(
                                                                          'Fira Sans Condensed',
                                                                          fontWeight: FontWeight.w500,
                                                                          fontSize: 10,
                                                                          color: Color(0xFF3E3636),
                                                                        ),
                                                                      ),
                                                                    ],
                                                                  ),
                                                                ),
                                                              ),
                                                            ),
                                                          ],
                                                        ),
                                                      ),
                                                    ),
                                                  ),
                                                ],
                                              ),
                                            ),
                                          ),
                                          Container(
                                            margin: EdgeInsets.fromLTRB(0, 0, 0, 0.3),
                                            child: SizedBox(
                                              width: 136.7,
                                              child: Column(
                                                mainAxisAlignment: MainAxisAlignment.start,
                                                crossAxisAlignment: CrossAxisAlignment.start,
                                                children: [
                                                  Container(
                                                    margin: EdgeInsets.fromLTRB(0.1, 0, 0.1, 0),
                                                    child: Align(
                                                      alignment: Alignment.topLeft,
                                                      child: Container(
                                                        decoration: BoxDecoration(
                                                          color: Color(0xFF4228D7),
                                                        ),
                                                        child: SizedBox(
                                                          width: 114.6,
                                                          child: Container(
                                                            padding: EdgeInsets.fromLTRB(5.1, 4, 0, 4.3),
                                                            child: Stack(
                                                              clipBehavior: Clip.none,
                                                              children: [
                                                                Text(
                                                                  'Situação',
                                                                  style: GoogleFonts.getFont(
                                                                    'Fira Sans Condensed',
                                                                    fontWeight: FontWeight.w600,
                                                                    fontSize: 10,
                                                                    color: Color(0xFFFFFFFF),
                                                                  ),
                                                                ),
                                                                Positioned(
                                                                  bottom: -4.3,
                                                                  child: Container(
                                                                    decoration: BoxDecoration(
                                                                      color: Color(0xFF4228D7),
                                                                    ),
                                                                    child: Container(
                                                                      width: 114.6,
                                                                      height: 20.3,
                                                                      padding: EdgeInsets.fromLTRB(5.1, 4, 0, 4.3),
                                                                      child: Text(
                                                                        'Situação',
                                                                        style: GoogleFonts.getFont(
                                                                          'Fira Sans Condensed',
                                                                          fontWeight: FontWeight.w600,
                                                                          fontSize: 10,
                                                                          color: Color(0xFFFFFFFF),
                                                                        ),
                                                                      ),
                                                                    ),
                                                                  ),
                                                                ),
                                                              ],
                                                            ),
                                                          ),
                                                        ),
                                                      ),
                                                    ),
                                                  ),
                                                  Container(
                                                    margin: EdgeInsets.fromLTRB(0.1, 0, 0, 1),
                                                    child: SizedBox(
                                                      width: 136.6,
                                                      child: Row(
                                                        mainAxisAlignment: MainAxisAlignment.start,
                                                        crossAxisAlignment: CrossAxisAlignment.start,
                                                        children: [
                                                          Container(
                                                            margin: EdgeInsets.fromLTRB(0, 7, 2.6, 0),
                                                            child: SizedBox(
                                                              width: 114.6,
                                                              child: Container(
                                                                padding: EdgeInsets.fromLTRB(0.6, 0, 0, 4),
                                                                child: Stack(
                                                                  clipBehavior: Clip.none,
                                                                  children: [
                                                                    Positioned(
                                                                      left: -0.6,
                                                                      right: 0,
                                                                      bottom: -4,
                                                                      child: Container(
                                                                        width: 114.6,
                                                                        height: 14.3,
                                                                        decoration: BoxDecoration(
                                                                          border: Border(
                                                                            bottom: BorderSize(
                                                                              color: Color(0xFFAA9D9D),
                                                                              width: 1,
                                                                            ),
                                                                          ),
                                                                        ),
                                                                      ),
                                                                    ),
                                                                    Text(
                                                                      'Retirado',
                                                                      style: GoogleFonts.getFont(
                                                                        'Fira Sans Condensed',
                                                                        fontWeight: FontWeight.w500,
                                                                        fontSize: 10,
                                                                        color: Color(0xFF3E3636),
                                                                      ),
                                                                    ),
                                                                  ],
                                                                ),
                                                              ),
                                                            ),
                                                          ),
                                                          Container(
                                                            margin: EdgeInsets.fromLTRB(0, 0, 0, 3),
                                                            width: 19.5,
                                                            height: 20,
                                                            child: SizedBox(
                                                              width: 19.5,
                                                              height: 20,
                                                              child: SvgPicture.asset(
                                                                'assets/vectors/vector_122_x2.svg',
                                                              ),
                                                            ),
                                                          ),
                                                        ],
                                                      ),
                                                    ),
                                                  ),
                                                  Container(
                                                    margin: EdgeInsets.fromLTRB(0, 0, 0.3, 1),
                                                    child: SizedBox(
                                                      width: 136.5,
                                                      child: Row(
                                                        mainAxisAlignment: MainAxisAlignment.start,
                                                        crossAxisAlignment: CrossAxisAlignment.start,
                                                        children: [
                                                          Container(
                                                            margin: EdgeInsets.fromLTRB(0, 6, 2.4, 0),
                                                            child: SizedBox(
                                                              width: 114.6,
                                                              child: Container(
                                                                padding: EdgeInsets.fromLTRB(0.6, 0, 0, 4),
                                                                child: Stack(
                                                                  clipBehavior: Clip.none,
                                                                  children: [
                                                                    Positioned(
                                                                      left: -0.6,
                                                                      right: 0,
                                                                      bottom: -4,
                                                                      child: Container(
                                                                        width: 114.6,
                                                                        height: 14.3,
                                                                        decoration: BoxDecoration(
                                                                          border: Border(
                                                                            bottom: BorderSize(
                                                                              color: Color(0xFFAA9D9D),
                                                                              width: 1,
                                                                            ),
                                                                          ),
                                                                        ),
                                                                      ),
                                                                    ),
                                                                    Text(
                                                                      'Retirado',
                                                                      style: GoogleFonts.getFont(
                                                                        'Fira Sans Condensed',
                                                                        fontWeight: FontWeight.w500,
                                                                        fontSize: 10,
                                                                        color: Color(0xFF3E3636),
                                                                      ),
                                                                    ),
                                                                  ],
                                                                ),
                                                              ),
                                                            ),
                                                          ),
                                                          Container(
                                                            margin: EdgeInsets.fromLTRB(0, 0, 0, 2),
                                                            child: SizedBox(
                                                              width: 19.5,
                                                              height: 20,
                                                              child: SvgPicture.asset(
                                                                'assets/vectors/vector_303_x2.svg',
                                                              ),
                                                            ),
                                                          ),
                                                        ],
                                                      ),
                                                    ),
                                                  ),
                                                  Container(
                                                    margin: EdgeInsets.fromLTRB(1, 0, 0.3, 0),
                                                    child: SizedBox(
                                                      width: 135.5,
                                                      child: Row(
                                                        mainAxisAlignment: MainAxisAlignment.start,
                                                        crossAxisAlignment: CrossAxisAlignment.start,
                                                        children: [
                                                          Container(
                                                            margin: EdgeInsets.fromLTRB(0, 4, 1.4, 0),
                                                            child: SizedBox(
                                                              width: 114.6,
                                                              child: Container(
                                                                padding: EdgeInsets.fromLTRB(0.6, 0, 0, 4),
                                                                child: Stack(
                                                                  clipBehavior: Clip.none,
                                                                  children: [
                                                                    Positioned(
                                                                      left: -0.6,
                                                                      right: 0,
                                                                      bottom: -4,
                                                                      child: Container(
                                                                        width: 114.6,
                                                                        height: 14.3,
                                                                        decoration: BoxDecoration(
                                                                          border: Border(
                                                                            bottom: BorderSize(
                                                                              color: Color(0xFFAA9D9D),
                                                                              width: 1,
                                                                            ),
                                                                          ),
                                                                        ),
                                                                      ),
                                                                    ),
                                                                    Text(
                                                                      'Retirado',
                                                                      style: GoogleFonts.getFont(
                                                                        'Fira Sans Condensed',
                                                                        fontWeight: FontWeight.w500,
                                                                        fontSize: 10,
                                                                        color: Color(0xFF3E3636),
                                                                      ),
                                                                    ),
                                                                    Positioned(
                                                                      bottom: -4,
                                                                      child: Container(
                                                                        width: 114.6,
                                                                        height: 14.3,
                                                                        child: Container(
                                                                          width: 114.6,
                                                                          height: 14.3,
                                                                          decoration: BoxDecoration(
                                                                            border: Border(
                                                                              bottom: BorderSize(
                                                                                color: Color(0xFFAA9D9D),
                                                                                width: 1,
                                                                              ),
                                                                            ),
                                                                          ),
                                                                        ),
                                                                      ),
                                                                    ),
                                                                  ],
                                                                ),
                                                              ),
                                                            ),
                                                          ),
                                                          Container(
                                                            margin: EdgeInsets.fromLTRB(0, 0, 0, 0),
                                                            child: SizedBox(
                                                              width: 19.5,
                                                              height: 20,
                                                              child: SvgPicture.asset(
                                                                'assets/vectors/vector_337_x2.svg',
                                                              ),
                                                            ),
                                                          ),
                                                        ],
                                                      ),
                                                    ),
                                                  ),
                                                ],
                                              ),
                                            ),
                                          ),
                                        ],
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                            ),
                          ),
                        ],
                      ),
                    ],
                  ),
                ],
              ),
              Positioned(
                left: -89,
                bottom: -21,
                child: Container(
                  decoration: BoxDecoration(
                    color: Color(0xFF212176),
                    borderRadius: BorderRadius.only(
                      bottomRight: Radius.circular(100),
                    ),
                  ),
                  child: SizedBox(
                    width: 278,
                    height: 959,
                    child: Container(
                      padding: EdgeInsets.fromLTRB(9.2, 15.8, 9.2, 0),
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.start,
                        crossAxisAlignment: CrossAxisAlignment.center,
                        children: [
                          Container(
                            margin: EdgeInsets.fromLTRB(0, 0, 0, 16.9),
                            child: Align(
                              alignment: Alignment.topLeft,
                              child: Row(
                                mainAxisAlignment: MainAxisAlignment.start,
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Container(
                                    margin: EdgeInsets.fromLTRB(0, 0, 43.5, 0),
                                    child: SizedBox(
                                      width: 47.3,
                                      height: 65.3,
                                      child: SvgPicture.asset(
                                        'assets/vectors/hamburger_20_x2.svg',
                                      ),
                                    ),
                                  ),
                                  Container(
                                    margin: EdgeInsets.fromLTRB(0, 32.2, 0, 13.1),
                                    child: Row(
                                      mainAxisAlignment: MainAxisAlignment.start,
                                      crossAxisAlignment: CrossAxisAlignment.start,
                                      children: [
                                        Container(
                                          margin: EdgeInsets.fromLTRB(0, 3, 8, 1),
                                          child: SizedBox(
                                            width: 17,
                                            height: 16,
                                            child: SvgPicture.asset(
                                              'assets/vectors/vector_381_x2.svg',
                                            ),
                                          ),
                                        ),
                                        Text(
                                          'Audio visual',
                                          style: GoogleFonts.getFont(
                                            'Fira Sans Condensed',
                                            fontWeight: FontWeight.w600,
                                            fontSize: 17,
                                            color: Color(0xFFFFFFFF),
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ),
                          Container(
                            margin: EdgeInsets.fromLTRB(35.8, 0, 0, 34),
                            child: Row(
                              mainAxisAlignment: MainAxisAlignment.start,
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Container(
                                  margin: EdgeInsets.fromLTRB(0, 2.5, 4.5, 2.5),
                                  child: SizedBox(
                                    width: 16.5,
                                    height: 15,
                                    child: SvgPicture.asset(
                                      'assets/vectors/vector_375_x2.svg',
                                    ),
                                  ),
                                ),
                                Text(
                                  'Equipamento',
                                  style: GoogleFonts.getFont(
                                    'Fira Sans Condensed',
                                    fontWeight: FontWeight.w600,
                                    fontSize: 17,
                                    color: Color(0xFFFFFFFF),
                                  ),
                                ),
                              ],
                            ),
                          ),
                          Container(
                            margin: EdgeInsets.fromLTRB(8.6, 0, 0, 31),
                            child: Row(
                              mainAxisAlignment: MainAxisAlignment.start,
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Container(
                                  margin: EdgeInsets.fromLTRB(0, 1, 10, 3),
                                  child: SizedBox(
                                    width: 15,
                                    height: 16,
                                    child: SvgPicture.asset(
                                      'assets/vectors/container_47_x2.svg',
                                    ),
                                  ),
                                ),
                                Text(
                                  'Usuários',
                                  style: GoogleFonts.getFont(
                                    'Fira Sans Condensed',
                                    fontWeight: FontWeight.w600,
                                    fontSize: 17,
                                    color: Color(0xFFFFFFFF),
                                  ),
                                ),
                              ],
                            ),
                          ),
                          Container(
                            margin: EdgeInsets.fromLTRB(27.6, 0, 0, 33),
                            child: Row(
                              mainAxisAlignment: MainAxisAlignment.start,
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Container(
                                  margin: EdgeInsets.fromLTRB(0, 1, 10, 3),
                                  child: SizedBox(
                                    width: 15,
                                    height: 16,
                                    child: SvgPicture.asset(
                                      'assets/vectors/container_31_x2.svg',
                                    ),
                                  ),
                                ),
                                Text(
                                  'Relatorios
                                ',
                                  style: GoogleFonts.getFont(
                                    'Fira Sans Condensed',
                                    fontWeight: FontWeight.w600,
                                    fontSize: 17,
                                    color: Color(0xFFFFFFFF),
                                  ),
                                ),
                              ],
                            ),
                          ),
                          Container(
                            margin: EdgeInsets.fromLTRB(7.2, 0, 0, 0),
                            child: Row(
                              mainAxisAlignment: MainAxisAlignment.start,
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Container(
                                  margin: EdgeInsets.fromLTRB(0, 5, 8, 0),
                                  child: SizedBox(
                                    width: 18,
                                    height: 16,
                                    child: SvgPicture.asset(
                                      'assets/vectors/vector_19_x2.svg',
                                    ),
                                  ),
                                ),
                                Container(
                                  margin: EdgeInsets.fromLTRB(0, 0, 0, 1),
                                  child: Text(
                                    'Reservas',
                                    style: GoogleFonts.getFont(
                                      'Fira Sans Condensed',
                                      fontWeight: FontWeight.w600,
                                      fontSize: 17,
                                      color: Color(0xFFFFFFFF),
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ),
              ),
              Positioned(
                right: -39,
                top: -34,
                child: Container(
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(5),
                    color: Color(0xFF000041),
                    boxShadow: [
                      BoxShadow(
                        color: Color(0x40000000),
                        offset: Offset(0, 4),
                        blurRadius: 2,
                      ),
                    ],
                  ),
                  child: SizedBox(
                    width: 1479,
                    height: 82,
                    child: Container(
                      padding: EdgeInsets.fromLTRB(0, 4, 74, 6),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Container(
                            decoration: BoxDecoration(
                              image: DecorationImage(
                                fit: BoxFit.cover,
                                image: AssetImage(
                                  'assets/images/image_2.png',
                                ),
                              ),
                            ),
                            child: Container(
                              width: 189,
                              height: 72,
                            ),
                          ),
                          Container(
                            margin: EdgeInsets.fromLTRB(0, 6, 0, 9),
                            child: Row(
                              mainAxisAlignment: MainAxisAlignment.start,
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Container(
                                  margin: EdgeInsets.fromLTRB(0, 0, 17, 0),
                                  child: SizedBox(
                                    width: 59,
                                    height: 57,
                                    child: SvgPicture.asset(
                                      'assets/vectors/group_1817_x2.svg',
                                    ),
                                  ),
                                ),
                                Container(
                                  margin: EdgeInsets.fromLTRB(0, 19, 0, 19),
                                  child: Text(
                                    'Logado: Waltair',
                                    style: GoogleFonts.getFont(
                                      'Fira Sans Condensed',
                                      fontWeight: FontWeight.w600,
                                      fontSize: 16,
                                      color: Color(0xFFFFFFFF),
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ),
                          Container(
                            margin: EdgeInsets.fromLTRB(0, 14, 0, 16),
                            child: Row(
                              mainAxisAlignment: MainAxisAlignment.start,
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Container(
                                  margin: EdgeInsets.fromLTRB(0, 0, 31, 0),
                                  child: Container(
                                    padding: EdgeInsets.fromLTRB(17, 11, 17, 12),
                                    child: Stack(
                                      clipBehavior: Clip.none,
                                      children: [
                                        Text(
                                          'Encerrar sessão',
                                          style: GoogleFonts.getFont(
                                            'Fira Sans Condensed',
                                            fontWeight: FontWeight.w600,
                                            fontSize: 16,
                                            color: Color(0xFFFFFFFF),
                                          ),
                                        ),
                                        Positioned(
                                          bottom: -12,
                                          child: Container(
                                            width: 138,
                                            height: 42,
                                            decoration: BoxDecoration(
                                              border: Border.all(color: Color(0xFFFFFFFF)),
                                              borderRadius: BorderRadius.circular(19),
                                            ),
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                ),
                                Container(
                                  decoration: BoxDecoration(
                                    color: Color(0xFF202075),
                                  ),
                                  child: SizedBox(
                                    width: 53,
                                    child: Container(
                                      padding: EdgeInsets.fromLTRB(2.7, 12.9, 7.7, 12.6),
                                      child: Stack(
                                        clipBehavior: Clip.none,
                                        children: [
                                          SizedBox(
                                            width: 42.6,
                                            child: Column(
                                              mainAxisAlignment: MainAxisAlignment.start,
                                              crossAxisAlignment: CrossAxisAlignment.center,
                                              children: [
                                                Container(
                                                  margin: EdgeInsets.fromLTRB(7.4, 0, 2.7, 4),
                                                  child: ClipRRect(
                                                    borderRadius: BorderRadius.circular(40),
                                                    child: SizedBox(
                                                      width: 32.5,
                                                      height: 2.8,
                                                      child: SvgPicture.asset(
                                                        'assets/vectors/rectangle_213_x2.svg',
                                                      ),
                                                    ),
                                                  ),
                                                ),
                                                Container(
                                                  margin: EdgeInsets.fromLTRB(7.4, 0, 2.7, 4),
                                                  child: ClipRRect(
                                                    borderRadius: BorderRadius.circular(40),
                                                    child: SizedBox(
                                                      width: 32.5,
                                                      height: 2.8,
                                                      child: SvgPicture.asset(
                                                        'assets/vectors/rectangle_318_x2.svg',
                                                      ),
                                                    ),
                                                  ),
                                                ),
                                                ClipRRect(
                                                  borderRadius: BorderRadius.circular(40),
                                                  child: SizedBox(
                                                    width: 42.6,
                                                    height: 2.8,
                                                    child: SvgPicture.asset(
                                                      'assets/vectors/rectangle_48_x2.svg',
                                                    ),
                                                  ),
                                                ),
                                              ],
                                            ),
                                          ),
                                          Positioned(
                                            left: -2.7,
                                            top: -11.9,
                                            child: Container(
                                              decoration: BoxDecoration(
                                                color: Color(0x03FFFFFF),
                                              ),
                                              child: Container(
                                                width: 48.7,
                                                height: 34.7,
                                              ),
                                            ),
                                          ),
                                        ],
                                      ),
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}