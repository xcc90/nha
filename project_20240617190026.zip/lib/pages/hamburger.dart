import 'package:flutter/material.dart';
import 'dart:ui';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:flutter_app/utils.dart';
import 'package:google_fonts/google_fonts.dart';

class Hamburger extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return 
    Container(
      padding: EdgeInsets.fromLTRB(4, 11, 5, 9),
      child: Stack(
        clipBehavior: Clip.none,
        children: [
          SizedBox(
            width: double.infinity,
            child: Column(
              mainAxisAlignment: MainAxisAlignment.start,
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                Container(
                  margin: EdgeInsets.fromLTRB(8.5, 0, 2.5, 5),
                  child: SizedBox(
                    width: 52,
                    height: 21,
                    child: SvgPicture.asset(
                      'assets/vectors/container_104_x2.svg',
                    ),
                  ),
                ),
                ClipRRect(
                  borderRadius: BorderRadius.circular(40),
                  child: SizedBox(
                    width: 63,
                    height: 15,
                    child: SvgPicture.asset(
                      'assets/vectors/rectangle_43_x2.svg',
                    ),
                  ),
                ),
              ],
            ),
          ),
          Positioned(
            left: -4,
            right: -5,
            top: -11,
            bottom: -9,
            child: Container(
              decoration: BoxDecoration(
                color: Color(0x03FFFFFF),
              ),
              child: Container(
                width: 72,
                height: 61,
              ),
            ),
          ),
        ],
      ),
    );
  }
}