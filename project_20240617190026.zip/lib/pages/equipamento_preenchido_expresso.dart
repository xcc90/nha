import 'package:flutter/material.dart';
import 'dart:ui';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:flutter_app/utils.dart';
import 'package:google_fonts/google_fonts.dart';

class EquipamentoPreenchidoExpresso extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return 
    Container(
      decoration: BoxDecoration(
        color: Color(0xFFFFFFFF),
      ),
      child: SizedBox(
        width: 1440,
        child: Container(
          padding: EdgeInsets.fromLTRB(7, 34, 0, 21),
          child: Stack(
            clipBehavior: Clip.none,
            children: [
              Column(
                mainAxisAlignment: MainAxisAlignment.start,
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  Container(
                    margin: EdgeInsets.fromLTRB(868.7, 0, 0, 33),
                    child: Text(
                      'logado: Waltair',
                      style: GoogleFonts.getFont(
                        'Fira Sans Condensed',
                        fontWeight: FontWeight.w300,
                        fontSize: 16,
                        color: Color(0xFFFFFFFF),
                      ),
                    ),
                  ),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.start,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Container(
                        margin: EdgeInsets.fromLTRB(0, 46, 45, 755),
                        child: Column(
                          mainAxisAlignment: MainAxisAlignment.start,
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Container(
                              margin: EdgeInsets.fromLTRB(0, 0, 0.2, 13),
                              child: Row(
                                mainAxisAlignment: MainAxisAlignment.start,
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Container(
                                    margin: EdgeInsets.fromLTRB(0, 5, 8, 0),
                                    child: SizedBox(
                                      width: 18,
                                      height: 16,
                                      child: SvgPicture.asset(
                                        'assets/vectors/vector_241_x2.svg',
                                      ),
                                    ),
                                  ),
                                  Container(
                                    margin: EdgeInsets.fromLTRB(0, 0, 0, 2),
                                    child: Text(
                                      'consultar reservas',
                                      style: GoogleFonts.getFont(
                                        'Fira Sans Condensed',
                                        fontWeight: FontWeight.w300,
                                        fontSize: 16,
                                        color: Color(0xFFFFFFFF),
                                      ),
                                    ),
                                  ),
                                ],
                              ),
                            ),
                            Container(
                              margin: EdgeInsets.fromLTRB(0.8, 0, 0, 10),
                              child: Row(
                                mainAxisAlignment: MainAxisAlignment.start,
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Container(
                                    margin: EdgeInsets.fromLTRB(0, 2.5, 8.8, 1.5),
                                    child: SizedBox(
                                      width: 16.5,
                                      height: 15,
                                      child: SvgPicture.asset(
                                        'assets/vectors/vector_107_x2.svg',
                                      ),
                                    ),
                                  ),
                                  Text(
                                    'adicionar material',
                                    style: GoogleFonts.getFont(
                                      'Fira Sans Condensed',
                                      fontWeight: FontWeight.w300,
                                      fontSize: 16,
                                      color: Color(0xFFFFFFFF),
                                    ),
                                  ),
                                ],
                              ),
                            ),
                            Container(
                              margin: EdgeInsets.fromLTRB(1, 0, 6.6, 15),
                              child: Row(
                                mainAxisAlignment: MainAxisAlignment.start,
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Container(
                                    margin: EdgeInsets.fromLTRB(0, 3, 8, 0),
                                    child: SizedBox(
                                      width: 17,
                                      height: 16,
                                      child: SvgPicture.asset(
                                        'assets/vectors/vector_293_x2.svg',
                                      ),
                                    ),
                                  ),
                                  Text(
                                    'adicionar reserva',
                                    style: GoogleFonts.getFont(
                                      'Fira Sans Condensed',
                                      fontWeight: FontWeight.w300,
                                      fontSize: 16,
                                      color: Color(0xFFFFFFFF),
                                    ),
                                  ),
                                ],
                              ),
                            ),
                            Container(
                              margin: EdgeInsets.fromLTRB(1, 0, 1, 0),
                              child: Align(
                                alignment: Alignment.topLeft,
                                child: Row(
                                  mainAxisAlignment: MainAxisAlignment.start,
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Container(
                                      margin: EdgeInsets.fromLTRB(0, 1, 10, 2),
                                      child: SizedBox(
                                        width: 15,
                                        height: 16,
                                        child: SvgPicture.asset(
                                          'assets/vectors/container_24_x2.svg',
                                        ),
                                      ),
                                    ),
                                    Text(
                                      'relatorios
                                    ',
                                      style: GoogleFonts.getFont(
                                        'Fira Sans Condensed',
                                        fontWeight: FontWeight.w300,
                                        fontSize: 16,
                                        color: Color(0xFFFFFFFF),
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                      Stack(
                        children: [
                          Column(
                            mainAxisAlignment: MainAxisAlignment.start,
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Container(
                                margin: EdgeInsets.fromLTRB(0, 0, 0, 26),
                                child: Container(
                                  decoration: BoxDecoration(
                                    color: Color(0xFFD9D9D9),
                                  ),
                                  child: Container(
                                    width: 1244,
                                    height: 36,
                                  ),
                                ),
                              ),
                              Container(
                                margin: EdgeInsets.fromLTRB(16, 0, 31, 30),
                                decoration: BoxDecoration(
                                  border: Border.all(color: Color(0xFFAA9D9D)),
                                  color: Color(0xFFD9D9D9),
                                ),
                                child: Container(
                                  padding: EdgeInsets.fromLTRB(20, 21, 0, 52),
                                  child: Column(
                                    mainAxisAlignment: MainAxisAlignment.start,
                                    crossAxisAlignment: CrossAxisAlignment.start,
                                    children: [
                                      Container(
                                        margin: EdgeInsets.fromLTRB(0, 0, 0, 20),
                                        child: Align(
                                          alignment: Alignment.topLeft,
                                          child: Stack(
                                            children: [
                                              Row(
                                                mainAxisAlignment: MainAxisAlignment.start,
                                                crossAxisAlignment: CrossAxisAlignment.start,
                                                children: [
                                                  ImageFiltered(
                                                    imageFilter: ImageFilter.blur(
                                                      sigmaX: 2,
                                                      sigmaY: 2,
                                                    ),
                                                    child: Column(
                                                      mainAxisAlignment: MainAxisAlignment.start,
                                                      crossAxisAlignment: CrossAxisAlignment.start,
                                                      children: [
                                                        Align(
                                                          alignment: Alignment.topLeft,
                                                          child: Text(
                                                            'Data Inicial',
                                                            style: GoogleFonts.getFont(
                                                              'Fira Sans Condensed',
                                                              fontWeight: FontWeight.w600,
                                                              fontSize: 10,
                                                              color: Color(0xFF000000),
                                                            ),
                                                          ),
                                                        ),
                                                        Container(
                                                          decoration: BoxDecoration(
                                                            border: Border.all(color: Color(0xFFAAA1A1)),
                                                            color: Color(0xFFFFFFFF),
                                                          ),
                                                          child: SizedBox(
                                                            width: 187.8,
                                                            child: Container(
                                                              padding: EdgeInsets.fromLTRB(4.8, 2.3, 0, 3.5),
                                                              child: Row(
                                                                mainAxisAlignment: MainAxisAlignment.start,
                                                                crossAxisAlignment: CrossAxisAlignment.start,
                                                                children: [
                                                                  Container(
                                                                    margin: EdgeInsets.fromLTRB(0, 0, 4.8, 0),
                                                                    child: SizedBox(
                                                                      width: 30.2,
                                                                      height: 23.4,
                                                                      child: SvgPicture.asset(
                                                                        'assets/vectors/vector_45_x2.svg',
                                                                      ),
                                                                    ),
                                                                  ),
                                                                  Container(
                                                                    margin: EdgeInsets.fromLTRB(0, 1.2, 0, 0),
                                                                    child: Container(
                                                                      decoration: BoxDecoration(
                                                                        color: Color(0xFFAA9D9D),
                                                                      ),
                                                                      child: Container(
                                                                        width: 1,
                                                                        height: 22.3,
                                                                      ),
                                                                    ),
                                                                  ),
                                                                ],
                                                              ),
                                                            ),
                                                          ),
                                                        ),
                                                      ],
                                                    ),
                                                  ),
                                                  Container(
                                                    margin: EdgeInsets.fromLTRB(0, 0, 0, 0),
                                                    child: ImageFiltered(
                                                      imageFilter: ImageFilter.blur(
                                                        sigmaX: 2,
                                                        sigmaY: 2,
                                                      ),
                                                      child: Column(
                                                        mainAxisAlignment: MainAxisAlignment.start,
                                                        crossAxisAlignment: CrossAxisAlignment.start,
                                                        children: [
                                                          Align(
                                                            alignment: Alignment.topLeft,
                                                            child: Text(
                                                              'Data Final',
                                                              style: GoogleFonts.getFont(
                                                                'Fira Sans Condensed',
                                                                fontWeight: FontWeight.w600,
                                                                fontSize: 10,
                                                                color: Color(0xFF000000),
                                                              ),
                                                            ),
                                                          ),
                                                          Container(
                                                            decoration: BoxDecoration(
                                                              border: Border.all(color: Color(0xFFAAA1A1)),
                                                              color: Color(0xFFFFFFFF),
                                                            ),
                                                            child: SizedBox(
                                                              width: 187.8,
                                                              child: Container(
                                                                padding: EdgeInsets.fromLTRB(4.8, 2.3, 0, 3.5),
                                                                child: Row(
                                                                  mainAxisAlignment: MainAxisAlignment.start,
                                                                  crossAxisAlignment: CrossAxisAlignment.start,
                                                                  children: [
                                                                    Container(
                                                                      margin: EdgeInsets.fromLTRB(0, 0, 4.8, 0),
                                                                      child: SizedBox(
                                                                        width: 30.2,
                                                                        height: 23.4,
                                                                        child: SvgPicture.asset(
                                                                          'assets/vectors/vector_27_x2.svg',
                                                                        ),
                                                                      ),
                                                                    ),
                                                                    Container(
                                                                      margin: EdgeInsets.fromLTRB(0, 1.2, 0, 0),
                                                                      child: Container(
                                                                        decoration: BoxDecoration(
                                                                          color: Color(0xFFAA9D9D),
                                                                        ),
                                                                        child: Container(
                                                                          width: 1,
                                                                          height: 22.3,
                                                                        ),
                                                                      ),
                                                                    ),
                                                                  ],
                                                                ),
                                                              ),
                                                            ),
                                                          ),
                                                        ],
                                                      ),
                                                    ),
                                                  ),
                                                  ImageFiltered(
                                                    imageFilter: ImageFilter.blur(
                                                      sigmaX: 2,
                                                      sigmaY: 2,
                                                    ),
                                                    child: Column(
                                                      mainAxisAlignment: MainAxisAlignment.start,
                                                      crossAxisAlignment: CrossAxisAlignment.start,
                                                      children: [
                                                        Align(
                                                          alignment: Alignment.topLeft,
                                                          child: Text(
                                                            'Setor',
                                                            style: GoogleFonts.getFont(
                                                              'Fira Sans Condensed',
                                                              fontWeight: FontWeight.w600,
                                                              fontSize: 10,
                                                              color: Color(0xFF000000),
                                                            ),
                                                          ),
                                                        ),
                                                        Container(
                                                          decoration: BoxDecoration(
                                                            border: Border.all(color: Color(0xFFAAA1A1)),
                                                            color: Color(0xFFFFFFFF),
                                                          ),
                                                          child: Container(
                                                            width: 187.8,
                                                            height: 29.3,
                                                            padding: EdgeInsets.fromLTRB(9, 3.5, 9, 3.5),
                                                            child: SizedBox(
                                                              width: 31.8,
                                                              height: 22.3,
                                                              child: SvgPicture.asset(
                                                                'assets/vectors/container_41_x2.svg',
                                                              ),
                                                            ),
                                                          ),
                                                        ),
                                                      ],
                                                    ),
                                                  ),
                                                  ImageFiltered(
                                                    imageFilter: ImageFilter.blur(
                                                      sigmaX: 2,
                                                      sigmaY: 2,
                                                    ),
                                                    child: Column(
                                                      mainAxisAlignment: MainAxisAlignment.start,
                                                      crossAxisAlignment: CrossAxisAlignment.start,
                                                      children: [
                                                        Align(
                                                          alignment: Alignment.topLeft,
                                                          child: Text(
                                                            'Responsavel',
                                                            style: GoogleFonts.getFont(
                                                              'Fira Sans Condensed',
                                                              fontWeight: FontWeight.w600,
                                                              fontSize: 10,
                                                              color: Color(0xFF000000),
                                                            ),
                                                          ),
                                                        ),
                                                        Container(
                                                          decoration: BoxDecoration(
                                                            border: Border.all(color: Color(0xFFAAA1A1)),
                                                            color: Color(0xFFFFFFFF),
                                                          ),
                                                          child: Container(
                                                            width: 187.8,
                                                            height: 29.3,
                                                            padding: EdgeInsets.fromLTRB(10, 3.5, 10, 3.5),
                                                            child: SizedBox(
                                                              width: 30.8,
                                                              height: 22.3,
                                                              child: SvgPicture.asset(
                                                                'assets/vectors/container_36_x2.svg',
                                                              ),
                                                            ),
                                                          ),
                                                        ),
                                                      ],
                                                    ),
                                                  ),
                                                  ImageFiltered(
                                                    imageFilter: ImageFilter.blur(
                                                      sigmaX: 2,
                                                      sigmaY: 2,
                                                    ),
                                                    child: Column(
                                                      mainAxisAlignment: MainAxisAlignment.start,
                                                      crossAxisAlignment: CrossAxisAlignment.start,
                                                      children: [
                                                        Align(
                                                          alignment: Alignment.topLeft,
                                                          child: Text(
                                                            'Situação',
                                                            style: GoogleFonts.getFont(
                                                              'Fira Sans Condensed',
                                                              fontWeight: FontWeight.w600,
                                                              fontSize: 10,
                                                              color: Color(0xFF000000),
                                                            ),
                                                          ),
                                                        ),
                                                        Container(
                                                          decoration: BoxDecoration(
                                                            border: Border.all(color: Color(0xFFAAA1A1)),
                                                            color: Color(0xFFFFFFFF),
                                                          ),
                                                          child: Container(
                                                            width: 187.8,
                                                            height: 29.3,
                                                            padding: EdgeInsets.fromLTRB(9, 3.5, 9, 3.5),
                                                            child: SizedBox(
                                                              width: 31.8,
                                                              height: 22.3,
                                                              child: SvgPicture.asset(
                                                                'assets/vectors/container_37_x2.svg',
                                                              ),
                                                            ),
                                                          ),
                                                        ),
                                                      ],
                                                    ),
                                                  ),
                                                ],
                                              ),
                                              Positioned(
                                                left: 66,
                                                bottom: 9,
                                                child: ImageFiltered(
                                                  imageFilter: ImageFilter.blur(
                                                    sigmaX: 2,
                                                    sigmaY: 2,
                                                  ),
                                                  child: SizedBox(
                                                    height: 15,
                                                    child: Text(
                                                      '01/11/2022',
                                                      style: GoogleFonts.getFont(
                                                        'Inter',
                                                        fontWeight: FontWeight.w400,
                                                        fontSize: 12,
                                                        color: Color(0xFF000000),
                                                      ),
                                                    ),
                                                  ),
                                                ),
                                              ),
                                              Positioned(
                                                left: 277,
                                                bottom: 9,
                                                child: ImageFiltered(
                                                  imageFilter: ImageFilter.blur(
                                                    sigmaX: 2,
                                                    sigmaY: 2,
                                                  ),
                                                  child: SizedBox(
                                                    height: 15,
                                                    child: Text(
                                                      '21/11/2022',
                                                      style: GoogleFonts.getFont(
                                                        'Inter',
                                                        fontWeight: FontWeight.w400,
                                                        fontSize: 12,
                                                        color: Color(0xFF000000),
                                                      ),
                                                    ),
                                                  ),
                                                ),
                                              ),
                                              Positioned(
                                                left: 480,
                                                bottom: 9,
                                                child: ImageFiltered(
                                                  imageFilter: ImageFilter.blur(
                                                    sigmaX: 2,
                                                    sigmaY: 2,
                                                  ),
                                                  child: SizedBox(
                                                    height: 15,
                                                    child: Text(
                                                      'Bloco C',
                                                      style: GoogleFonts.getFont(
                                                        'Inter',
                                                        fontWeight: FontWeight.w400,
                                                        fontSize: 12,
                                                        color: Color(0xFF000000),
                                                      ),
                                                    ),
                                                  ),
                                                ),
                                              ),
                                              Positioned(
                                                right: 276.9,
                                                bottom: 9,
                                                child: ImageFiltered(
                                                  imageFilter: ImageFilter.blur(
                                                    sigmaX: 2,
                                                    sigmaY: 2,
                                                  ),
                                                  child: SizedBox(
                                                    height: 15,
                                                    child: Text(
                                                      'Waltair',
                                                      style: GoogleFonts.getFont(
                                                        'Inter',
                                                        fontWeight: FontWeight.w400,
                                                        fontSize: 12,
                                                        color: Color(0xFF000000),
                                                      ),
                                                    ),
                                                  ),
                                                ),
                                              ),
                                              Positioned(
                                                right: 53.8,
                                                bottom: 8,
                                                child: ImageFiltered(
                                                  imageFilter: ImageFilter.blur(
                                                    sigmaX: 2,
                                                    sigmaY: 2,
                                                  ),
                                                  child: SizedBox(
                                                    height: 15,
                                                    child: Text(
                                                      'Reservada',
                                                      style: GoogleFonts.getFont(
                                                        'Inter',
                                                        fontWeight: FontWeight.w400,
                                                        fontSize: 12,
                                                        color: Color(0xFF000000),
                                                      ),
                                                    ),
                                                  ),
                                                ),
                                              ),
                                            ],
                                          ),
                                        ),
                                      ),
                                      Align(
                                        alignment: Alignment.topLeft,
                                        child: ImageFiltered(
                                          imageFilter: ImageFilter.blur(
                                            sigmaX: 2,
                                            sigmaY: 2,
                                          ),
                                          child: Stack(
                                            children: [
                                            Positioned(
                                              left: -6,
                                              top: -7,
                                              child: Container(
                                                decoration: BoxDecoration(
                                                  color: Color(0xFF000041),
                                                ),
                                                child: Container(
                                                  width: 144,
                                                  height: 28,
                                                ),
                                              ),
                                            ),
                                      Container(
                                                padding: EdgeInsets.fromLTRB(6, 7, 6, 7),
                                                child: Stack(
                                                  clipBehavior: Clip.none,
                                                  children: [
                                                    Row(
                                                      mainAxisAlignment: MainAxisAlignment.start,
                                                      crossAxisAlignment: CrossAxisAlignment.start,
                                                      children: [
                                                        Container(
                                                          margin: EdgeInsets.fromLTRB(0, 0, 10, 0),
                                                          child: SizedBox(
                                                            width: 14,
                                                            height: 14,
                                                            child: SvgPicture.asset(
                                                              'assets/vectors/vector_238_x2.svg',
                                                            ),
                                                          ),
                                                        ),
                                                        Container(
                                                          margin: EdgeInsets.fromLTRB(0, 1, 0, 1),
                                                          child: Text(
                                                            'Cadastro Expresso',
                                                            style: GoogleFonts.getFont(
                                                              'Fira Sans Condensed',
                                                              fontWeight: FontWeight.w600,
                                                              fontSize: 10,
                                                              color: Color(0xFFFFFFFF),
                                                            ),
                                                          ),
                                                        ),
                                                      ],
                                                    ),
                                                    Positioned(
                                                      left: 24,
                                                      bottom: 1,
                                                      child: SizedBox(
                                                        height: 12,
                                                        child: Text(
                                                          'Cadastro Expresso',
                                                          style: GoogleFonts.getFont(
                                                            'Fira Sans Condensed',
                                                            fontWeight: FontWeight.w600,
                                                            fontSize: 10,
                                                            color: Color(0xFFFFFFFF),
                                                          ),
                                                        ),
                                                      ),
                                                    ),
                                                  ],
                                                ),
                                              ),
                                            ],
                                          ),
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                              ),
                              Container(
                                margin: EdgeInsets.fromLTRB(16, 0, 31, 0),
                                child: Container(
                                  decoration: BoxDecoration(
                                    color: Color(0xFFD9D9D9),
                                  ),
                                  child: SizedBox(
                                    height: 663,
                                    child: Container(
                                      padding: EdgeInsets.fromLTRB(0, 1, 0, 0),
                                      child: Stack(
                                        clipBehavior: Clip.none,
                                        children: [
                                          Column(
                                            mainAxisAlignment: MainAxisAlignment.start,
                                            crossAxisAlignment: CrossAxisAlignment.start,
                                            children: [
                                              Container(
                                                margin: EdgeInsets.fromLTRB(0, 0, 0, 3),
                                                child: ImageFiltered(
                                                  imageFilter: ImageFilter.blur(
                                                    sigmaX: 2,
                                                    sigmaY: 2,
                                                  ),
                                                  child: Stack(
                                                    children: [
                                                    Positioned(
                                                      top: -7,
                                                      child: Container(
                                                        decoration: BoxDecoration(
                                                          color: Color(0xFF212176),
                                                        ),
                                                        child: Container(
                                                          width: 1197,
                                                          height: 31,
                                                        ),
                                                      ),
                                                    ),
                                              SizedBox(
                                                        width: 1197,
                                                        child: Container(
                                                          padding: EdgeInsets.fromLTRB(5, 7, 0, 16),
                                                          child: Row(
                                                            mainAxisAlignment: MainAxisAlignment.start,
                                                            crossAxisAlignment: CrossAxisAlignment.start,
                                                            children: [
                                                              Container(
                                                                margin: EdgeInsets.fromLTRB(0, 0, 3, 0),
                                                                child: SizedBox(
                                                                  width: 20,
                                                                  height: 20,
                                                                  child: SvgPicture.asset(
                                                                    'assets/vectors/vector_138_x2.svg',
                                                                  ),
                                                                ),
                                                              ),
                                                              Container(
                                                                margin: EdgeInsets.fromLTRB(0, 5, 0, 3),
                                                                child: Text(
                                                                  'Atividades',
                                                                  style: GoogleFonts.getFont(
                                                                    'Fira Sans Condensed',
                                                                    fontWeight: FontWeight.w600,
                                                                    fontSize: 10,
                                                                    color: Color(0xFFFFFFFF),
                                                                  ),
                                                                ),
                                                              ),
                                                            ],
                                                          ),
                                                        ),
                                                      ),
                                                    ],
                                                  ),
                                                ),
                                              ),
                                              Container(
                                                margin: EdgeInsets.fromLTRB(10, 0, 10, 0),
                                                child: Align(
                                                  alignment: Alignment.topLeft,
                                                  child: ImageFiltered(
                                                    imageFilter: ImageFilter.blur(
                                                      sigmaX: 2,
                                                      sigmaY: 2,
                                                    ),
                                                    child: Container(
                                                      padding: EdgeInsets.fromLTRB(0, 0, 4.7, 0),
                                                      child: Column(
                                                        mainAxisAlignment: MainAxisAlignment.start,
                                                        crossAxisAlignment: CrossAxisAlignment.center,
                                                        children: [
                                                          Container(
                                                            margin: EdgeInsets.fromLTRB(0, 0, 0, 6.7),
                                                            child: Container(
                                                              decoration: BoxDecoration(
                                                                color: Color(0xFF4228D7),
                                                              ),
                                                              child: Container(
                                                                padding: EdgeInsets.fromLTRB(12, 4, 12.4, 4.3),
                                                                child: Text(
                                                                  'nº Cadastro',
                                                                  style: GoogleFonts.getFont(
                                                                    'Fira Sans Condensed',
                                                                    fontWeight: FontWeight.w600,
                                                                    fontSize: 10,
                                                                    color: Color(0xFFFFFFFF),
                                                                  ),
                                                                ),
                                                              ),
                                                            ),
                                                          ),
                                                          Container(
                                                            margin: EdgeInsets.fromLTRB(0, 0, 0, 7),
                                                            child: SizedBox(
                                                              width: 73.2,
                                                              child: Container(
                                                                padding: EdgeInsets.fromLTRB(0, 0, 1.5, 4),
                                                                child: Stack(
                                                                  clipBehavior: Clip.none,
                                                                  children: [
                                                                    Positioned(
                                                                      bottom: 0,
                                                                      child: Container(
                                                                        width: 73.2,
                                                                        height: 14.3,
                                                                        decoration: BoxDecoration(
                                                                          border: Border(
                                                                            bottom: BorderSize(
                                                                              color: Color(0xFFAA9D9D),
                                                                              width: 1,
                                                                            ),
                                                                          ),
                                                                        ),
                                                                      ),
                                                                    ),
                                                                    Text(
                                                                      '578',
                                                                      style: GoogleFonts.getFont(
                                                                        'Fira Sans Condensed',
                                                                        fontWeight: FontWeight.w500,
                                                                        fontSize: 10,
                                                                        color: Color(0xFF3E3636),
                                                                      ),
                                                                    ),
                                                                  ],
                                                                ),
                                                              ),
                                                            ),
                                                          ),
                                                          SizedBox(
                                                            width: 73.2,
                                                            child: Container(
                                                              padding: EdgeInsets.fromLTRB(0, 0, 1.3, 4),
                                                              child: Stack(
                                                                clipBehavior: Clip.none,
                                                                children: [
                                                                  Positioned(
                                                                    bottom: 0,
                                                                    child: Container(
                                                                      width: 73.2,
                                                                      height: 14.3,
                                                                      decoration: BoxDecoration(
                                                                        border: Border(
                                                                          bottom: BorderSize(
                                                                            color: Color(0xFFAA9D9D),
                                                                            width: 1,
                                                                          ),
                                                                        ),
                                                                      ),
                                                                    ),
                                                                  ),
                                                                  Text(
                                                                    '392',
                                                                    style: GoogleFonts.getFont(
                                                                      'Fira Sans Condensed',
                                                                      fontWeight: FontWeight.w500,
                                                                      fontSize: 10,
                                                                      color: Color(0xFF3E3636),
                                                                    ),
                                                                  ),
                                                                ],
                                                              ),
                                                            ),
                                                          ),
                                                        ],
                                                      ),
                                                    ),
                                                  ),
                                                ),
                                              ),
                                            ],
                                          ),
                                          Positioned(
                                            left: 84.6,
                                            top: 47,
                                            child: ImageFiltered(
                                              imageFilter: ImageFilter.blur(
                                                sigmaX: 2,
                                                sigmaY: 2,
                                              ),
                                              child: SizedBox(
                                                width: 127.7,
                                                height: 66,
                                                child: Column(
                                                  mainAxisAlignment: MainAxisAlignment.start,
                                                  crossAxisAlignment: CrossAxisAlignment.start,
                                                  children: [
                                                    Container(
                                                      margin: EdgeInsets.fromLTRB(0, 0, 0, 6.7),
                                                      child: Align(
                                                        alignment: Alignment.topLeft,
                                                        child: Container(
                                                          decoration: BoxDecoration(
                                                            color: Color(0xFF4228D7),
                                                          ),
                                                          child: Container(
                                                            padding: EdgeInsets.fromLTRB(19.4, 4, 19.4, 4.3),
                                                            child: Text(
                                                              'Equipamento',
                                                              style: GoogleFonts.getFont(
                                                                'Fira Sans Condensed',
                                                                fontWeight: FontWeight.w600,
                                                                fontSize: 10,
                                                                color: Color(0xFFFFFFFF),
                                                              ),
                                                            ),
                                                          ),
                                                        ),
                                                      ),
                                                    ),
                                                    Container(
                                                      margin: EdgeInsets.fromLTRB(0, 0, 0, 7),
                                                      child: Align(
                                                        alignment: Alignment.topLeft,
                                                        child: SizedBox(
                                                          width: 106.8,
                                                          child: Container(
                                                            padding: EdgeInsets.fromLTRB(0, 0, 6.8, 4),
                                                            child: Stack(
                                                              clipBehavior: Clip.none,
                                                              children: [
                                                                Positioned(
                                                                  bottom: 0,
                                                                  child: Container(
                                                                    width: 106.8,
                                                                    height: 14.3,
                                                                    decoration: BoxDecoration(
                                                                      border: Border(
                                                                        bottom: BorderSize(
                                                                          color: Color(0xFFAA9D9D),
                                                                          width: 1,
                                                                        ),
                                                                      ),
                                                                    ),
                                                                  ),
                                                                ),
                                                                Text(
                                                                  'Microfone',
                                                                  style: GoogleFonts.getFont(
                                                                    'Fira Sans Condensed',
                                                                    fontWeight: FontWeight.w500,
                                                                    fontSize: 10,
                                                                    color: Color(0xFF3E3636),
                                                                  ),
                                                                ),
                                                              ],
                                                            ),
                                                          ),
                                                        ),
                                                      ),
                                                    ),
                                                    Align(
                                                      alignment: Alignment.topLeft,
                                                      child: SizedBox(
                                                        width: 106.8,
                                                        child: Container(
                                                          padding: EdgeInsets.fromLTRB(0, 0, 10.5, 4),
                                                          child: Stack(
                                                            clipBehavior: Clip.none,
                                                            children: [
                                                              Positioned(
                                                                bottom: 0,
                                                                child: Container(
                                                                  width: 106.8,
                                                                  height: 14.3,
                                                                  decoration: BoxDecoration(
                                                                    border: Border(
                                                                      bottom: BorderSize(
                                                                        color: Color(0xFFAA9D9D),
                                                                        width: 1,
                                                                      ),
                                                                    ),
                                                                  ),
                                                                ),
                                                              ),
                                                              Text(
                                                                'Cabo P10',
                                                                style: GoogleFonts.getFont(
                                                                  'Fira Sans Condensed',
                                                                  fontWeight: FontWeight.w500,
                                                                  fontSize: 10,
                                                                  color: Color(0xFF3E3636),
                                                                ),
                                                              ),
                                                            ],
                                                          ),
                                                        ),
                                                      ),
                                                    ),
                                                  ],
                                                ),
                                              ),
                                            ),
                                          ),
                                          Positioned(
                                            left: 193,
                                            top: 47,
                                            child: ImageFiltered(
                                              imageFilter: ImageFilter.blur(
                                                sigmaX: 2,
                                                sigmaY: 2,
                                              ),
                                              child: SizedBox(
                                                width: 130.4,
                                                height: 66,
                                                child: Column(
                                                  mainAxisAlignment: MainAxisAlignment.start,
                                                  crossAxisAlignment: CrossAxisAlignment.start,
                                                  children: [
                                                    Container(
                                                      margin: EdgeInsets.fromLTRB(0, 0, 0, 6.7),
                                                      child: Align(
                                                        alignment: Alignment.topLeft,
                                                        child: Container(
                                                          decoration: BoxDecoration(
                                                            color: Color(0xFF4228D7),
                                                          ),
                                                          child: Container(
                                                            padding: EdgeInsets.fromLTRB(2.9, 2.4, 2.9, 5.9),
                                                            child: Stack(
                                                              clipBehavior: Clip.none,
                                                              children: [
                                                                Text(
                                                                  'Data de entrega',
                                                                  style: GoogleFonts.getFont(
                                                                    'Fira Sans Condensed',
                                                                    fontWeight: FontWeight.w600,
                                                                    fontSize: 10,
                                                                    color: Color(0xFFFFFFFF),
                                                                  ),
                                                                ),
                                                                Positioned(
                                                                  bottom: -5.9,
                                                                  child: Container(
                                                                    decoration: BoxDecoration(
                                                                      color: Color(0xFF4228D7),
                                                                    ),
                                                                    child: Container(
                                                                      width: 106.8,
                                                                      height: 20.3,
                                                                      padding: EdgeInsets.fromLTRB(18.6, 4, 18.6, 4.3),
                                                                      child: Text(
                                                                        'Data de registro',
                                                                        style: GoogleFonts.getFont(
                                                                          'Fira Sans Condensed',
                                                                          fontWeight: FontWeight.w600,
                                                                          fontSize: 10,
                                                                          color: Color(0xFFFFFFFF),
                                                                        ),
                                                                      ),
                                                                    ),
                                                                  ),
                                                                ),
                                                              ],
                                                            ),
                                                          ),
                                                        ),
                                                      ),
                                                    ),
                                                    Container(
                                                      margin: EdgeInsets.fromLTRB(0, 0, 0, 7),
                                                      child: Align(
                                                        alignment: Alignment.topLeft,
                                                        child: SizedBox(
                                                          width: 106.8,
                                                          child: Container(
                                                            padding: EdgeInsets.fromLTRB(6.5, 0, 0, 4),
                                                            child: Stack(
                                                              clipBehavior: Clip.none,
                                                              children: [
                                                                Positioned(
                                                                  bottom: -4,
                                                                  child: Container(
                                                                    width: 106.8,
                                                                    height: 14.3,
                                                                    decoration: BoxDecoration(
                                                                      border: Border(
                                                                        bottom: BorderSize(
                                                                          color: Color(0xFFAA9D9D),
                                                                          width: 1,
                                                                        ),
                                                                      ),
                                                                    ),
                                                                  ),
                                                                ),
                                                                Text(
                                                                  '11/11/2022',
                                                                  style: GoogleFonts.getFont(
                                                                    'Fira Sans Condensed',
                                                                    fontWeight: FontWeight.w500,
                                                                    fontSize: 10,
                                                                    color: Color(0xFF3E3636),
                                                                  ),
                                                                ),
                                                                Positioned(
                                                                  bottom: -4,
                                                                  child: Container(
                                                                    width: 106.8,
                                                                    height: 14.3,
                                                                    child: Container(
                                                                      width: 106.8,
                                                                      height: 14.3,
                                                                      decoration: BoxDecoration(
                                                                        border: Border(
                                                                          bottom: BorderSize(
                                                                            color: Color(0xFFAA9D9D),
                                                                            width: 1,
                                                                          ),
                                                                        ),
                                                                      ),
                                                                    ),
                                                                  ),
                                                                ),
                                                              ],
                                                            ),
                                                          ),
                                                        ),
                                                      ),
                                                    ),
                                                    Align(
                                                      alignment: Alignment.topLeft,
                                                      child: SizedBox(
                                                        width: 106.8,
                                                        child: Container(
                                                          padding: EdgeInsets.fromLTRB(7.7, 0, 0, 4),
                                                          child: Stack(
                                                            clipBehavior: Clip.none,
                                                            children: [
                                                              Positioned(
                                                                bottom: -4,
                                                                child: Container(
                                                                  width: 106.8,
                                                                  height: 14.3,
                                                                  decoration: BoxDecoration(
                                                                    border: Border(
                                                                      bottom: BorderSize(
                                                                        color: Color(0xFFAA9D9D),
                                                                        width: 1,
                                                                      ),
                                                                    ),
                                                                  ),
                                                                ),
                                                              ),
                                                              Text(
                                                                '01/11/2022',
                                                                style: GoogleFonts.getFont(
                                                                  'Fira Sans Condensed',
                                                                  fontWeight: FontWeight.w500,
                                                                  fontSize: 10,
                                                                  color: Color(0xFF3E3636),
                                                                ),
                                                              ),
                                                            ],
                                                          ),
                                                        ),
                                                      ),
                                                    ),
                                                  ],
                                                ),
                                              ),
                                            ),
                                          ),
                                          Positioned(
                                            left: 301.3,
                                            top: 47,
                                            child: ImageFiltered(
                                              imageFilter: ImageFilter.blur(
                                                sigmaX: 2,
                                                sigmaY: 2,
                                              ),
                                              child: SizedBox(
                                                width: 182,
                                                height: 66,
                                                child: Column(
                                                  mainAxisAlignment: MainAxisAlignment.start,
                                                  crossAxisAlignment: CrossAxisAlignment.start,
                                                  children: [
                                                    Container(
                                                      margin: EdgeInsets.fromLTRB(0, 0, 0, 7.7),
                                                      child: Align(
                                                        alignment: Alignment.topLeft,
                                                        child: Container(
                                                          decoration: BoxDecoration(
                                                            color: Color(0xFF4228D7),
                                                          ),
                                                          child: Container(
                                                            width: 126.5,
                                                            padding: EdgeInsets.fromLTRB(3.3, 4, 0, 4.3),
                                                            child: Text(
                                                              'Setor',
                                                              style: GoogleFonts.getFont(
                                                                'Fira Sans Condensed',
                                                                fontWeight: FontWeight.w600,
                                                                fontSize: 10,
                                                                color: Color(0xFFFFFFFF),
                                                              ),
                                                            ),
                                                          ),
                                                        ),
                                                      ),
                                                    ),
                                                    Container(
                                                      margin: EdgeInsets.fromLTRB(0, 0, 0, 8),
                                                      child: Align(
                                                        alignment: Alignment.topLeft,
                                                        child: SizedBox(
                                                          width: 126.5,
                                                          child: Container(
                                                            padding: EdgeInsets.fromLTRB(5.3, 0, 0, 3),
                                                            child: Stack(
                                                              clipBehavior: Clip.none,
                                                              children: [
                                                                Positioned(
                                                                  bottom: -3,
                                                                  child: Container(
                                                                    width: 126.5,
                                                                    height: 14.3,
                                                                    decoration: BoxDecoration(
                                                                      border: Border(
                                                                        bottom: BorderSize(
                                                                          color: Color(0xFFAA9D9D),
                                                                          width: 1,
                                                                        ),
                                                                      ),
                                                                    ),
                                                                  ),
                                                                ),
                                                                Text(
                                                                  'Bloco C',
                                                                  style: GoogleFonts.getFont(
                                                                    'Fira Sans Condensed',
                                                                    fontWeight: FontWeight.w500,
                                                                    fontSize: 10,
                                                                    color: Color(0xFF3E3636),
                                                                  ),
                                                                ),
                                                              ],
                                                            ),
                                                          ),
                                                        ),
                                                      ),
                                                    ),
                                                    Align(
                                                      alignment: Alignment.topLeft,
                                                      child: SizedBox(
                                                        width: 126.5,
                                                        child: Container(
                                                          padding: EdgeInsets.fromLTRB(5.3, 0, 0, 3),
                                                          child: Stack(
                                                            clipBehavior: Clip.none,
                                                            children: [
                                                              Positioned(
                                                                bottom: -3,
                                                                child: Container(
                                                                  width: 126.5,
                                                                  height: 14.3,
                                                                  decoration: BoxDecoration(
                                                                    border: Border(
                                                                      bottom: BorderSize(
                                                                        color: Color(0xFFAA9D9D),
                                                                        width: 1,
                                                                      ),
                                                                    ),
                                                                  ),
                                                                ),
                                                              ),
                                                              Text(
                                                                'Bloco C',
                                                                style: GoogleFonts.getFont(
                                                                  'Fira Sans Condensed',
                                                                  fontWeight: FontWeight.w500,
                                                                  fontSize: 10,
                                                                  color: Color(0xFF3E3636),
                                                                ),
                                                              ),
                                                            ],
                                                          ),
                                                        ),
                                                      ),
                                                    ),
                                                  ],
                                                ),
                                              ),
                                            ),
                                          ),
                                          Positioned(
                                            left: 428.6,
                                            top: 47,
                                            child: ImageFiltered(
                                              imageFilter: ImageFilter.blur(
                                                sigmaX: 2,
                                                sigmaY: 2,
                                              ),
                                              child: SizedBox(
                                                width: 196,
                                                height: 66,
                                                child: Column(
                                                  mainAxisAlignment: MainAxisAlignment.start,
                                                  crossAxisAlignment: CrossAxisAlignment.start,
                                                  children: [
                                                    Container(
                                                      margin: EdgeInsets.fromLTRB(0, 0, 0, 7.7),
                                                      child: Align(
                                                        alignment: Alignment.topLeft,
                                                        child: Container(
                                                          decoration: BoxDecoration(
                                                            color: Color(0xFF4228D7),
                                                          ),
                                                          child: Container(
                                                            width: 144.6,
                                                            padding: EdgeInsets.fromLTRB(6.4, 4, 0, 4.3),
                                                            child: Text(
                                                              'Responsavel',
                                                              style: GoogleFonts.getFont(
                                                                'Fira Sans Condensed',
                                                                fontWeight: FontWeight.w600,
                                                                fontSize: 10,
                                                                color: Color(0xFFFFFFFF),
                                                              ),
                                                            ),
                                                          ),
                                                        ),
                                                      ),
                                                    ),
                                                    Container(
                                                      margin: EdgeInsets.fromLTRB(0, 0, 0, 8),
                                                      child: Align(
                                                        alignment: Alignment.topLeft,
                                                        child: SizedBox(
                                                          width: 144.6,
                                                          child: Container(
                                                            padding: EdgeInsets.fromLTRB(0, 0, 10.5, 3),
                                                            child: Stack(
                                                              clipBehavior: Clip.none,
                                                              children: [
                                                                Positioned(
                                                                  bottom: 0,
                                                                  child: Container(
                                                                    width: 144.6,
                                                                    height: 14.3,
                                                                    decoration: BoxDecoration(
                                                                      border: Border(
                                                                        bottom: BorderSize(
                                                                          color: Color(0xFFAA9D9D),
                                                                          width: 1,
                                                                        ),
                                                                      ),
                                                                    ),
                                                                  ),
                                                                ),
                                                                Text(
                                                                  'Waltair',
                                                                  style: GoogleFonts.getFont(
                                                                    'Fira Sans Condensed',
                                                                    fontWeight: FontWeight.w500,
                                                                    fontSize: 10,
                                                                    color: Color(0xFF3E3636),
                                                                  ),
                                                                ),
                                                              ],
                                                            ),
                                                          ),
                                                        ),
                                                      ),
                                                    ),
                                                    Container(
                                                      margin: EdgeInsets.fromLTRB(0, 0, 0, 0),
                                                      child: Align(
                                                        alignment: Alignment.topLeft,
                                                        child: SizedBox(
                                                          width: 144.6,
                                                          child: Container(
                                                            padding: EdgeInsets.fromLTRB(0, 0, 10.5, 3),
                                                            child: Stack(
                                                              clipBehavior: Clip.none,
                                                              children: [
                                                                Positioned(
                                                                  bottom: 0,
                                                                  child: Container(
                                                                    width: 144.6,
                                                                    height: 14.3,
                                                                    decoration: BoxDecoration(
                                                                      border: Border(
                                                                        bottom: BorderSize(
                                                                          color: Color(0xFFAA9D9D),
                                                                          width: 1,
                                                                        ),
                                                                      ),
                                                                    ),
                                                                  ),
                                                                ),
                                                                Text(
                                                                  'Waltair',
                                                                  style: GoogleFonts.getFont(
                                                                    'Fira Sans Condensed',
                                                                    fontWeight: FontWeight.w500,
                                                                    fontSize: 10,
                                                                    color: Color(0xFF3E3636),
                                                                  ),
                                                                ),
                                                              ],
                                                            ),
                                                          ),
                                                        ),
                                                      ),
                                                    ),
                                                  ],
                                                ),
                                              ),
                                            ),
                                          ),
                                          Positioned(
                                            right: 432.4,
                                            top: 47,
                                            child: ImageFiltered(
                                              imageFilter: ImageFilter.blur(
                                                sigmaX: 2,
                                                sigmaY: 2,
                                              ),
                                              child: SizedBox(
                                                width: 189.6,
                                                height: 66,
                                                child: Column(
                                                  mainAxisAlignment: MainAxisAlignment.start,
                                                  crossAxisAlignment: CrossAxisAlignment.start,
                                                  children: [
                                                    Container(
                                                      margin: EdgeInsets.fromLTRB(0, 0, 0, 7.7),
                                                      child: Align(
                                                        alignment: Alignment.topLeft,
                                                        child: Container(
                                                          decoration: BoxDecoration(
                                                            color: Color(0xFF4228D7),
                                                          ),
                                                          child: Container(
                                                            width: 144.6,
                                                            padding: EdgeInsets.fromLTRB(5.8, 4, 0, 4.3),
                                                            child: Text(
                                                              'Nº Patrimônio
                                                            ',
                                                              style: GoogleFonts.getFont(
                                                                'Fira Sans Condensed',
                                                                fontWeight: FontWeight.w600,
                                                                fontSize: 10,
                                                                color: Color(0xFFFFFFFF),
                                                              ),
                                                            ),
                                                          ),
                                                        ),
                                                      ),
                                                    ),
                                                    Container(
                                                      margin: EdgeInsets.fromLTRB(0, 0, 0, 8),
                                                      child: Align(
                                                        alignment: Alignment.topLeft,
                                                        child: SizedBox(
                                                          width: 144.6,
                                                          child: Container(
                                                            padding: EdgeInsets.fromLTRB(0, 0, 14.8, 3),
                                                            child: Stack(
                                                              clipBehavior: Clip.none,
                                                              children: [
                                                                Positioned(
                                                                  bottom: 0,
                                                                  child: Container(
                                                                    width: 144.6,
                                                                    height: 14.3,
                                                                    decoration: BoxDecoration(
                                                                      border: Border(
                                                                        bottom: BorderSize(
                                                                          color: Color(0xFFAA9D9D),
                                                                          width: 1,
                                                                        ),
                                                                      ),
                                                                    ),
                                                                  ),
                                                                ),
                                                                Text(
                                                                  'MIC409',
                                                                  style: GoogleFonts.getFont(
                                                                    'Fira Sans Condensed',
                                                                    fontWeight: FontWeight.w500,
                                                                    fontSize: 10,
                                                                    color: Color(0xFF3E3636),
                                                                  ),
                                                                ),
                                                              ],
                                                            ),
                                                          ),
                                                        ),
                                                      ),
                                                    ),
                                                    Align(
                                                      alignment: Alignment.topLeft,
                                                      child: SizedBox(
                                                        width: 144.6,
                                                        child: Container(
                                                          padding: EdgeInsets.fromLTRB(0, 0, 14, 3),
                                                          child: Stack(
                                                            clipBehavior: Clip.none,
                                                            children: [
                                                              Positioned(
                                                                bottom: 0,
                                                                child: Container(
                                                                  width: 144.6,
                                                                  height: 14.3,
                                                                  decoration: BoxDecoration(
                                                                    border: Border(
                                                                      bottom: BorderSize(
                                                                        color: Color(0xFFAA9D9D),
                                                                        width: 1,
                                                                      ),
                                                                    ),
                                                                  ),
                                                                ),
                                                              ),
                                                              Text(
                                                                'CAB010',
                                                                style: GoogleFonts.getFont(
                                                                  'Fira Sans Condensed',
                                                                  fontWeight: FontWeight.w500,
                                                                  fontSize: 10,
                                                                  color: Color(0xFF3E3636),
                                                                ),
                                                              ),
                                                            ],
                                                          ),
                                                        ),
                                                      ),
                                                    ),
                                                  ],
                                                ),
                                              ),
                                            ),
                                          ),
                                          Positioned(
                                            right: 291.4,
                                            top: 47,
                                            child: ImageFiltered(
                                              imageFilter: ImageFilter.blur(
                                                sigmaX: 2,
                                                sigmaY: 2,
                                              ),
                                              child: SizedBox(
                                                width: 184.2,
                                                height: 66.3,
                                                child: Container(
                                                  padding: EdgeInsets.fromLTRB(0, 0, 0, 0.3),
                                                  child: Column(
                                                    mainAxisAlignment: MainAxisAlignment.start,
                                                    crossAxisAlignment: CrossAxisAlignment.start,
                                                    children: [
                                                      Container(
                                                        margin: EdgeInsets.fromLTRB(0, 0, 0, 8.4),
                                                        child: Align(
                                                          alignment: Alignment.topLeft,
                                                          child: Container(
                                                            decoration: BoxDecoration(
                                                              color: Color(0xFF4228D7),
                                                            ),
                                                            child: SizedBox(
                                                              width: 144.6,
                                                              child: Container(
                                                                padding: EdgeInsets.fromLTRB(0, 3.6, 19.3, 4.7),
                                                                child: Stack(
                                                                  clipBehavior: Clip.none,
                                                                  children: [
                                                                    Text(
                                                                      'Nº Patrimônio',
                                                                      style: GoogleFonts.getFont(
                                                                        'Fira Sans Condensed',
                                                                        fontWeight: FontWeight.w600,
                                                                        fontSize: 10,
                                                                        color: Color(0xFFFFFFFF),
                                                                      ),
                                                                    ),
                                                                    Positioned(
                                                                      bottom: 0,
                                                                      child: Container(
                                                                        decoration: BoxDecoration(
                                                                          color: Color(0xFF4228D7),
                                                                        ),
                                                                        child: Container(
                                                                          width: 144.6,
                                                                          height: 20.3,
                                                                          padding: EdgeInsets.fromLTRB(0, 4, 18.9, 4.3),
                                                                          child: Text(
                                                                            'Proprietario',
                                                                            style: GoogleFonts.getFont(
                                                                              'Fira Sans Condensed',
                                                                              fontWeight: FontWeight.w600,
                                                                              fontSize: 10,
                                                                              color: Color(0xFFFFFFFF),
                                                                            ),
                                                                          ),
                                                                        ),
                                                                      ),
                                                                    ),
                                                                  ],
                                                                ),
                                                              ),
                                                            ),
                                                          ),
                                                        ),
                                                      ),
                                                      Container(
                                                        margin: EdgeInsets.fromLTRB(0, 0, 0, 8.7),
                                                        child: Align(
                                                          alignment: Alignment.topLeft,
                                                          child: Container(
                                                            width: 144.6,
                                                            decoration: BoxDecoration(
                                                              border: Border(
                                                                bottom: BorderSize(
                                                                  color: Color(0xFFAA9D9D),
                                                                  width: 1,
                                                                ),
                                                              ),
                                                            ),
                                                            child: Container(
                                                              padding: EdgeInsets.fromLTRB(0, 0.3, 11.4, 2),
                                                              child: Stack(
                                                                clipBehavior: Clip.none,
                                                                children: [
                                                                  Text(
                                                                    'Univag',
                                                                    style: GoogleFonts.getFont(
                                                                      'Fira Sans Condensed',
                                                                      fontWeight: FontWeight.w500,
                                                                      fontSize: 10,
                                                                      color: Color(0xFF3E3636),
                                                                    ),
                                                                  ),
                                                                  Positioned(
                                                                    bottom: 0,
                                                                    child: Container(
                                                                      width: 144.6,
                                                                      height: 14.3,
                                                                      child: Container(
                                                                        width: 144.6,
                                                                        height: 14.3,
                                                                        decoration: BoxDecoration(
                                                                          border: Border(
                                                                            bottom: BorderSize(
                                                                              color: Color(0xFFAA9D9D),
                                                                              width: 1,
                                                                            ),
                                                                          ),
                                                                        ),
                                                                      ),
                                                                    ),
                                                                  ),
                                                                ],
                                                              ),
                                                            ),
                                                          ),
                                                        ),
                                                      ),
                                                      Align(
                                                        alignment: Alignment.topLeft,
                                                        child: Container(
                                                          width: 144.6,
                                                          padding: EdgeInsets.fromLTRB(0, 0.3, 11.4, 2),
                                                          decoration: BoxDecoration(
                                                            border: Border(
                                                              bottom: BorderSize(
                                                                color: Color(0xFFAA9D9D),
                                                                width: 1,
                                                              ),
                                                            ),
                                                          ),
                                                          child: Text(
                                                            'Univag',
                                                            style: GoogleFonts.getFont(
                                                              'Fira Sans Condensed',
                                                              fontWeight: FontWeight.w500,
                                                              fontSize: 10,
                                                              color: Color(0xFF3E3636),
                                                            ),
                                                          ),
                                                        ),
                                                      ),
                                                    ],
                                                  ),
                                                ),
                                              ),
                                            ),
                                          ),
                                          Positioned(
                                            right: 130.4,
                                            top: 47,
                                            child: ImageFiltered(
                                              imageFilter: ImageFilter.blur(
                                                sigmaX: 2,
                                                sigmaY: 2,
                                              ),
                                              child: SizedBox(
                                                width: 198.9,
                                                height: 66,
                                                child: Column(
                                                  mainAxisAlignment: MainAxisAlignment.start,
                                                  crossAxisAlignment: CrossAxisAlignment.start,
                                                  children: [
                                                    Container(
                                                      margin: EdgeInsets.fromLTRB(0, 0, 0, 6.7),
                                                      child: Align(
                                                        alignment: Alignment.topLeft,
                                                        child: Container(
                                                          decoration: BoxDecoration(
                                                            color: Color(0xFF4228D7),
                                                          ),
                                                          child: SizedBox(
                                                            width: 144.6,
                                                            child: Container(
                                                              padding: EdgeInsets.fromLTRB(0, 3.6, 19.3, 4.7),
                                                              child: Stack(
                                                                clipBehavior: Clip.none,
                                                                children: [
                                                                  Text(
                                                                    'Nº Patrimônio',
                                                                    style: GoogleFonts.getFont(
                                                                      'Fira Sans Condensed',
                                                                      fontWeight: FontWeight.w600,
                                                                      fontSize: 10,
                                                                      color: Color(0xFFFFFFFF),
                                                                    ),
                                                                  ),
                                                                  Positioned(
                                                                    bottom: 0,
                                                                    child: Container(
                                                                      decoration: BoxDecoration(
                                                                        color: Color(0xFF4228D7),
                                                                      ),
                                                                      child: Container(
                                                                        width: 144.6,
                                                                        height: 20.3,
                                                                        padding: EdgeInsets.fromLTRB(0, 4, 4.2, 4.3),
                                                                        child: Text(
                                                                          'Situação',
                                                                          style: GoogleFonts.getFont(
                                                                            'Fira Sans Condensed',
                                                                            fontWeight: FontWeight.w600,
                                                                            fontSize: 10,
                                                                            color: Color(0xFFFFFFFF),
                                                                          ),
                                                                        ),
                                                                      ),
                                                                    ),
                                                                  ),
                                                                ],
                                                              ),
                                                            ),
                                                          ),
                                                        ),
                                                      ),
                                                    ),
                                                    Container(
                                                      margin: EdgeInsets.fromLTRB(0, 0, 0, 7),
                                                      child: Align(
                                                        alignment: Alignment.topLeft,
                                                        child: SizedBox(
                                                          width: 144.6,
                                                          child: Container(
                                                            padding: EdgeInsets.fromLTRB(3.4, 0, 0, 4),
                                                            child: Stack(
                                                              clipBehavior: Clip.none,
                                                              children: [
                                                                Positioned(
                                                                  bottom: -4,
                                                                  child: Container(
                                                                    width: 144.6,
                                                                    height: 14.3,
                                                                    decoration: BoxDecoration(
                                                                      border: Border(
                                                                        bottom: BorderSize(
                                                                          color: Color(0xFFAA9D9D),
                                                                          width: 1,
                                                                        ),
                                                                      ),
                                                                    ),
                                                                  ),
                                                                ),
                                                                Text(
                                                                  'Reservado',
                                                                  style: GoogleFonts.getFont(
                                                                    'Fira Sans Condensed',
                                                                    fontWeight: FontWeight.w500,
                                                                    fontSize: 10,
                                                                    color: Color(0xFF3E3636),
                                                                  ),
                                                                ),
                                                                Positioned(
                                                                  bottom: -4,
                                                                  child: Container(
                                                                    width: 144.6,
                                                                    height: 14.3,
                                                                    child: Container(
                                                                      width: 144.6,
                                                                      height: 14.3,
                                                                      decoration: BoxDecoration(
                                                                        border: Border(
                                                                          bottom: BorderSize(
                                                                            color: Color(0xFFAA9D9D),
                                                                            width: 1,
                                                                          ),
                                                                        ),
                                                                      ),
                                                                    ),
                                                                  ),
                                                                ),
                                                              ],
                                                            ),
                                                          ),
                                                        ),
                                                      ),
                                                    ),
                                                    Align(
                                                      alignment: Alignment.topLeft,
                                                      child: SizedBox(
                                                        width: 144.6,
                                                        child: Container(
                                                          padding: EdgeInsets.fromLTRB(3.4, 0, 0, 4),
                                                          child: Stack(
                                                            clipBehavior: Clip.none,
                                                            children: [
                                                              Positioned(
                                                                bottom: -4,
                                                                child: Container(
                                                                  width: 144.6,
                                                                  height: 14.3,
                                                                  decoration: BoxDecoration(
                                                                    border: Border(
                                                                      bottom: BorderSize(
                                                                        color: Color(0xFFAA9D9D),
                                                                        width: 1,
                                                                      ),
                                                                    ),
                                                                  ),
                                                                ),
                                                              ),
                                                              Text(
                                                                'Reservado',
                                                                style: GoogleFonts.getFont(
                                                                  'Fira Sans Condensed',
                                                                  fontWeight: FontWeight.w500,
                                                                  fontSize: 10,
                                                                  color: Color(0xFF3E3636),
                                                                ),
                                                              ),
                                                            ],
                                                          ),
                                                        ),
                                                      ),
                                                    ),
                                                  ],
                                                ),
                                              ),
                                            ),
                                          ),
                                          Positioned(
                                            right: 161,
                                            top: 65,
                                            child: ImageFiltered(
                                              imageFilter: ImageFilter.blur(
                                                sigmaX: 2,
                                                sigmaY: 2,
                                              ),
                                              child: Container(
                                                width: 24,
                                                height: 24,
                                                padding: EdgeInsets.fromLTRB(2.3, 2, 2.3, 2),
                                                child: SizedBox(
                                                  width: 19.5,
                                                  height: 20,
                                                  child: SvgPicture.asset(
                                                    'assets/vectors/vector_413_x2.svg',
                                                  ),
                                                ),
                                              ),
                                            ),
                                          ),
                                          Positioned(
                                            right: 161,
                                            top: 90,
                                            child: ImageFiltered(
                                              imageFilter: ImageFilter.blur(
                                                sigmaX: 2,
                                                sigmaY: 2,
                                              ),
                                              child: Container(
                                                width: 24,
                                                height: 24,
                                                padding: EdgeInsets.fromLTRB(2.3, 2, 2.3, 2),
                                                child: SizedBox(
                                                  width: 19.5,
                                                  height: 20,
                                                  child: SvgPicture.asset(
                                                    'assets/vectors/vector_207_x2.svg',
                                                  ),
                                                ),
                                              ),
                                            ),
                                          ),
                                        ],
                                      ),
                                    ),
                                  ),
                                ),
                              ),
                            ],
                          ),
                          Positioned(
                            right: 168.3,
                            top: 222,
                            child: Container(
                              height: 286,
                              child: ClipRect(
                                child: BackdropFilter(
                                  filter: ImageFilter.blur(
                                    sigmaX: 2,
                                    sigmaY: 2,
                                  ),
                                  child: Container(
                                    decoration: BoxDecoration(
                                      borderRadius: BorderRadius.circular(10),
                                      boxShadow: [
                                        BoxShadow(
                                          color: Color(0x40000000),
                                          offset: Offset(0, 4),
                                          blurRadius: 2,
                                        ),
                                      ],
                                    ),
                                    child: Stack(
                                      children: [
                                    Positioned(
                                      left: -16.5,
                                      top: -1,
                                      child: SizedBox(
                                        width: 898.2,
                                        height: 31,
                                        child: SvgPicture.asset(
                                          'assets/vectors/group_811_x2.svg',
                                        ),
                                      ),
                                    ),
                              Container(
                                          padding: EdgeInsets.fromLTRB(16.5, 1, 12.7, 121.3),
                                          child: Column(
                                            mainAxisAlignment: MainAxisAlignment.start,
                                            crossAxisAlignment: CrossAxisAlignment.start,
                                            children: [
                                              Container(
                                                margin: EdgeInsets.fromLTRB(0, 0, 0, 9.2),
                                                child: Align(
                                                  alignment: Alignment.topRight,
                                                  child: SizedBox(
                                                    width: 522.6,
                                                    child: Row(
                                                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                                      crossAxisAlignment: CrossAxisAlignment.start,
                                                      children: [
                                                        Container(
                                                          margin: EdgeInsets.fromLTRB(0, 0, 12, 4),
                                                          child: SizedBox(
                                                            width: 477.6,
                                                            child: Text(
                                                              'CADASTRO RAPIDO',
                                                              style: GoogleFonts.getFont(
                                                                'Inter',
                                                                fontWeight: FontWeight.w600,
                                                                fontSize: 20,
                                                                color: Color(0xFFFFFFFF),
                                                              ),
                                                            ),
                                                          ),
                                                        ),
                                                        Container(
                                                          decoration: BoxDecoration(
                                                            color: Color(0xFF212176),
                                                          ),
                                                          child: Container(
                                                            padding: EdgeInsets.fromLTRB(8, 2, 12.2, 2),
                                                            child: Text(
                                                              'X',
                                                              style: GoogleFonts.getFont(
                                                                'Inter',
                                                                fontWeight: FontWeight.w400,
                                                                fontSize: 20,
                                                                color: Color(0xFFFFFFFF),
                                                              ),
                                                            ),
                                                          ),
                                                        ),
                                                      ],
                                                    ),
                                                  ),
                                                ),
                                              ),
                                              Container(
                                                margin: EdgeInsets.fromLTRB(0, 0, 12.7, 23),
                                                child: Row(
                                                  mainAxisAlignment: MainAxisAlignment.start,
                                                  crossAxisAlignment: CrossAxisAlignment.start,
                                                  children: [
                                                    Container(
                                                      margin: EdgeInsets.fromLTRB(0, 0, 27.6, 0.3),
                                                      child: Column(
                                                        mainAxisAlignment: MainAxisAlignment.start,
                                                        crossAxisAlignment: CrossAxisAlignment.start,
                                                        children: [
                                                          Container(
                                                            margin: EdgeInsets.fromLTRB(0, 0, 0, 2.7),
                                                            child: Align(
                                                              alignment: Alignment.topLeft,
                                                              child: Text(
                                                                'Numero do patrimonio',
                                                                style: GoogleFonts.getFont(
                                                                  'Fira Sans Condensed',
                                                                  fontWeight: FontWeight.w600,
                                                                  fontSize: 10,
                                                                  color: Color(0xFF000000),
                                                                ),
                                                              ),
                                                            ),
                                                          ),
                                                          Container(
                                                            decoration: BoxDecoration(
                                                              border: Border.all(color: Color(0xFFAAA1A1)),
                                                              color: Color(0xFFFFFFFF),
                                                            ),
                                                            child: SizedBox(
                                                              width: 193.4,
                                                              child: Container(
                                                                padding: EdgeInsets.fromLTRB(10.3, 4.4, 0, 4.4),
                                                                child: Row(
                                                                  mainAxisAlignment: MainAxisAlignment.start,
                                                                  crossAxisAlignment: CrossAxisAlignment.start,
                                                                  children: [
                                                                    Container(
                                                                      margin: EdgeInsets.fromLTRB(0, 1, 10.1, 1.9),
                                                                      child: SizedBox(
                                                                        width: 20.6,
                                                                        height: 25.2,
                                                                        child: SvgPicture.asset(
                                                                          'assets/vectors/vector_407_x2.svg',
                                                                        ),
                                                                      ),
                                                                    ),
                                                                    Container(
                                                                      margin: EdgeInsets.fromLTRB(0, 0, 25.5, 0),
                                                                      child: Container(
                                                                        decoration: BoxDecoration(
                                                                          color: Color(0xFFAA9D9D),
                                                                        ),
                                                                        child: Container(
                                                                          width: 1,
                                                                          height: 28,
                                                                        ),
                                                                      ),
                                                                    ),
                                                                    Container(
                                                                      margin: EdgeInsets.fromLTRB(0, 5, 0, 8),
                                                                      child: Text(
                                                                        'Dat690',
                                                                        style: GoogleFonts.getFont(
                                                                          'Inter',
                                                                          fontWeight: FontWeight.w400,
                                                                          fontSize: 12,
                                                                          color: Color(0xFF000000),
                                                                        ),
                                                                      ),
                                                                    ),
                                                                  ],
                                                                ),
                                                              ),
                                                            ),
                                                          ),
                                                        ],
                                                      ),
                                                    ),
                                                    Container(
                                                      margin: EdgeInsets.fromLTRB(0, 0, 27.6, 0.3),
                                                      child: Column(
                                                        mainAxisAlignment: MainAxisAlignment.start,
                                                        crossAxisAlignment: CrossAxisAlignment.start,
                                                        children: [
                                                          Container(
                                                            margin: EdgeInsets.fromLTRB(0, 0, 0, 2.7),
                                                            child: Align(
                                                              alignment: Alignment.topLeft,
                                                              child: Text(
                                                                'Proprietario',
                                                                style: GoogleFonts.getFont(
                                                                  'Fira Sans Condensed',
                                                                  fontWeight: FontWeight.w600,
                                                                  fontSize: 10,
                                                                  color: Color(0xFF000000),
                                                                ),
                                                              ),
                                                            ),
                                                          ),
                                                          Container(
                                                            decoration: BoxDecoration(
                                                              border: Border.all(color: Color(0xFFAAA1A1)),
                                                              color: Color(0xFFFFFFFF),
                                                            ),
                                                            child: SizedBox(
                                                              width: 193.4,
                                                              child: Container(
                                                                padding: EdgeInsets.fromLTRB(10.3, 4.4, 0, 4.4),
                                                                child: Row(
                                                                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                                                  crossAxisAlignment: CrossAxisAlignment.start,
                                                                  children: [
                                                                    SizedBox(
                                                                      width: 31.7,
                                                                      child: Row(
                                                                        mainAxisAlignment: MainAxisAlignment.start,
                                                                        crossAxisAlignment: CrossAxisAlignment.start,
                                                                        children: [
                                                                          Container(
                                                                            margin: EdgeInsets.fromLTRB(0, 1, 10.1, 1.9),
                                                                            child: SizedBox(
                                                                              width: 20.6,
                                                                              height: 25.2,
                                                                              child: SvgPicture.asset(
                                                                                'assets/vectors/vector_145_x2.svg',
                                                                              ),
                                                                            ),
                                                                          ),
                                                                          Container(
                                                                            decoration: BoxDecoration(
                                                                              color: Color(0xFFAA9D9D),
                                                                            ),
                                                                            child: Container(
                                                                              width: 1,
                                                                              height: 28,
                                                                            ),
                                                                          ),
                                                                        ],
                                                                      ),
                                                                    ),
                                                                    Container(
                                                                      margin: EdgeInsets.fromLTRB(0, 6.6, 0, 6.4),
                                                                      child: Text(
                                                                        'Univag',
                                                                        style: GoogleFonts.getFont(
                                                                          'Inter',
                                                                          fontWeight: FontWeight.w400,
                                                                          fontSize: 12,
                                                                          color: Color(0xFF000000),
                                                                        ),
                                                                      ),
                                                                    ),
                                                                  ],
                                                                ),
                                                              ),
                                                            ),
                                                          ),
                                                        ],
                                                      ),
                                                    ),
                                                    Container(
                                                      margin: EdgeInsets.fromLTRB(0, 0.3, 27.9, 0),
                                                      child: Column(
                                                        mainAxisAlignment: MainAxisAlignment.start,
                                                        crossAxisAlignment: CrossAxisAlignment.start,
                                                        children: [
                                                          Container(
                                                            margin: EdgeInsets.fromLTRB(0, 0, 0, 2.7),
                                                            child: Align(
                                                              alignment: Alignment.topLeft,
                                                              child: Text(
                                                                'Responsavel',
                                                                style: GoogleFonts.getFont(
                                                                  'Fira Sans Condensed',
                                                                  fontWeight: FontWeight.w600,
                                                                  fontSize: 10,
                                                                  color: Color(0xFF000000),
                                                                ),
                                                              ),
                                                            ),
                                                          ),
                                                          Container(
                                                            decoration: BoxDecoration(
                                                              border: Border.all(color: Color(0xFFAAA1A1)),
                                                              color: Color(0xFFFFFFFF),
                                                            ),
                                                            child: SizedBox(
                                                              width: 193.4,
                                                              child: Container(
                                                                padding: EdgeInsets.fromLTRB(10.3, 4.4, 0, 4.4),
                                                                child: Row(
                                                                  mainAxisAlignment: MainAxisAlignment.start,
                                                                  crossAxisAlignment: CrossAxisAlignment.start,
                                                                  children: [
                                                                    Container(
                                                                      margin: EdgeInsets.fromLTRB(0, 1, 10.1, 1.9),
                                                                      child: SizedBox(
                                                                        width: 20.6,
                                                                        height: 25.2,
                                                                        child: SvgPicture.asset(
                                                                          'assets/vectors/vector_89_x2.svg',
                                                                        ),
                                                                      ),
                                                                    ),
                                                                    Container(
                                                                      margin: EdgeInsets.fromLTRB(0, 0, 26.1, 0),
                                                                      child: Container(
                                                                        decoration: BoxDecoration(
                                                                          color: Color(0xFFAA9D9D),
                                                                        ),
                                                                        child: Container(
                                                                          width: 1,
                                                                          height: 28,
                                                                        ),
                                                                      ),
                                                                    ),
                                                                    Container(
                                                                      margin: EdgeInsets.fromLTRB(0, 4.8, 0, 8.2),
                                                                      child: Text(
                                                                        'Waltair',
                                                                        style: GoogleFonts.getFont(
                                                                          'Inter',
                                                                          fontWeight: FontWeight.w400,
                                                                          fontSize: 12,
                                                                          color: Color(0xFF000000),
                                                                        ),
                                                                      ),
                                                                    ),
                                                                  ],
                                                                ),
                                                              ),
                                                            ),
                                                          ),
                                                        ],
                                                      ),
                                                    ),
                                                    Container(
                                                      margin: EdgeInsets.fromLTRB(0, 0, 0, 0.3),
                                                      child: Column(
                                                        mainAxisAlignment: MainAxisAlignment.start,
                                                        crossAxisAlignment: CrossAxisAlignment.start,
                                                        children: [
                                                          Container(
                                                            margin: EdgeInsets.fromLTRB(0, 0, 0, 2.7),
                                                            child: Align(
                                                              alignment: Alignment.topLeft,
                                                              child: Text(
                                                                'Setor',
                                                                style: GoogleFonts.getFont(
                                                                  'Fira Sans Condensed',
                                                                  fontWeight: FontWeight.w600,
                                                                  fontSize: 10,
                                                                  color: Color(0xFF000000),
                                                                ),
                                                              ),
                                                            ),
                                                          ),
                                                          Container(
                                                            decoration: BoxDecoration(
                                                              border: Border.all(color: Color(0xFFAAA1A1)),
                                                              color: Color(0xFFFFFFFF),
                                                            ),
                                                            child: SizedBox(
                                                              width: 193.4,
                                                              child: Container(
                                                                padding: EdgeInsets.fromLTRB(10.3, 4.4, 0, 4.4),
                                                                child: Row(
                                                                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                                                  crossAxisAlignment: CrossAxisAlignment.start,
                                                                  children: [
                                                                    SizedBox(
                                                                      width: 31.7,
                                                                      child: Row(
                                                                        mainAxisAlignment: MainAxisAlignment.start,
                                                                        crossAxisAlignment: CrossAxisAlignment.start,
                                                                        children: [
                                                                          Container(
                                                                            margin: EdgeInsets.fromLTRB(0, 1, 10.1, 1.9),
                                                                            child: SizedBox(
                                                                              width: 20.6,
                                                                              height: 25.2,
                                                                              child: SvgPicture.asset(
                                                                                'assets/vectors/vector_190_x2.svg',
                                                                              ),
                                                                            ),
                                                                          ),
                                                                          Container(
                                                                            decoration: BoxDecoration(
                                                                              color: Color(0xFFAA9D9D),
                                                                            ),
                                                                            child: Container(
                                                                              width: 1,
                                                                              height: 28,
                                                                            ),
                                                                          ),
                                                                        ],
                                                                      ),
                                                                    ),
                                                                    Container(
                                                                      margin: EdgeInsets.fromLTRB(0, 6.2, 0, 6.8),
                                                                      child: Text(
                                                                        'Bloco C',
                                                                        style: GoogleFonts.getFont(
                                                                          'Inter',
                                                                          fontWeight: FontWeight.w400,
                                                                          fontSize: 12,
                                                                          color: Color(0xFF000000),
                                                                        ),
                                                                      ),
                                                                    ),
                                                                  ],
                                                                ),
                                                              ),
                                                            ),
                                                          ),
                                                        ],
                                                      ),
                                                    ),
                                                  ],
                                                ),
                                              ),
                                              Container(
                                                margin: EdgeInsets.fromLTRB(2.1, 0, 2.1, 0),
                                                child: Align(
                                                  alignment: Alignment.topLeft,
                                                  child: SizedBox(
                                                    width: 372.8,
                                                    child: Row(
                                                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                                      crossAxisAlignment: CrossAxisAlignment.start,
                                                      children: [
                                                        Column(
                                                          mainAxisAlignment: MainAxisAlignment.start,
                                                          crossAxisAlignment: CrossAxisAlignment.start,
                                                          children: [
                                                            Container(
                                                              margin: EdgeInsets.fromLTRB(0, 0, 0, 2.7),
                                                              child: Align(
                                                                alignment: Alignment.topLeft,
                                                                child: Text(
                                                                  'Equimento',
                                                                  style: GoogleFonts.getFont(
                                                                    'Fira Sans Condensed',
                                                                    fontWeight: FontWeight.w600,
                                                                    fontSize: 10,
                                                                    color: Color(0xFF000000),
                                                                  ),
                                                                ),
                                                              ),
                                                            ),
                                                            Container(
                                                              decoration: BoxDecoration(
                                                                border: Border.all(color: Color(0xFFAAA1A1)),
                                                                color: Color(0xFFFFFFFF),
                                                              ),
                                                              child: SizedBox(
                                                                width: 193.4,
                                                                child: Container(
                                                                  padding: EdgeInsets.fromLTRB(10.3, 4.4, 0, 4.4),
                                                                  child: Row(
                                                                    mainAxisAlignment: MainAxisAlignment.start,
                                                                    crossAxisAlignment: CrossAxisAlignment.start,
                                                                    children: [
                                                                      Container(
                                                                        margin: EdgeInsets.fromLTRB(0, 1, 10.1, 1.9),
                                                                        child: SizedBox(
                                                                          width: 20.6,
                                                                          height: 25.2,
                                                                          child: SvgPicture.asset(
                                                                            'assets/vectors/vector_329_x2.svg',
                                                                          ),
                                                                        ),
                                                                      ),
                                                                      Container(
                                                                        margin: EdgeInsets.fromLTRB(0, 0, 23.4, 0),
                                                                        child: Container(
                                                                          decoration: BoxDecoration(
                                                                            color: Color(0xFFAA9D9D),
                                                                          ),
                                                                          child: Container(
                                                                            width: 1,
                                                                            height: 28,
                                                                          ),
                                                                        ),
                                                                      ),
                                                                      Container(
                                                                        margin: EdgeInsets.fromLTRB(0, 5, 0, 8),
                                                                        child: Text(
                                                                          'DataShow',
                                                                          style: GoogleFonts.getFont(
                                                                            'Inter',
                                                                            fontWeight: FontWeight.w400,
                                                                            fontSize: 12,
                                                                            color: Color(0xFF000000),
                                                                          ),
                                                                        ),
                                                                      ),
                                                                    ],
                                                                  ),
                                                                ),
                                                              ),
                                                            ),
                                                          ],
                                                        ),
                                                        Container(
                                                          margin: EdgeInsets.fromLTRB(0, 18.9, 0, 0.7),
                                                          child: Container(
                                                            decoration: BoxDecoration(
                                                              color: Color(0xFF000041),
                                                            ),
                                                            child: SizedBox(
                                                              width: 112.5,
                                                              child: Container(
                                                                padding: EdgeInsets.fromLTRB(10, 7, 0, 7.7),
                                                                child: Row(
                                                                  mainAxisAlignment: MainAxisAlignment.start,
                                                                  crossAxisAlignment: CrossAxisAlignment.start,
                                                                  children: [
                                                                    Container(
                                                                      margin: EdgeInsets.fromLTRB(0, 0, 9.2, 0),
                                                                      child: SizedBox(
                                                                        width: 18.8,
                                                                        height: 17.3,
                                                                        child: SvgPicture.asset(
                                                                          'assets/vectors/vector_304_x2.svg',
                                                                        ),
                                                                      ),
                                                                    ),
                                                                    Container(
                                                                      margin: EdgeInsets.fromLTRB(0, 4, 0, 1.3),
                                                                      child: Text(
                                                                        'Registrar',
                                                                        style: GoogleFonts.getFont(
                                                                          'Fira Sans Condensed',
                                                                          fontWeight: FontWeight.w600,
                                                                          fontSize: 10,
                                                                          color: Color(0xFFFFFFFF),
                                                                        ),
                                                                      ),
                                                                    ),
                                                                  ],
                                                                ),
                                                              ),
                                                            ),
                                                          ),
                                                        ),
                                                      ],
                                                    ),
                                                  ),
                                                ),
                                              ),
                                            ],
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                ),
                              ),
                            ),
                          ),
                        ],
                      ),
                    ],
                  ),
                ],
              ),
              Positioned(
                left: -89,
                bottom: -21,
                child: Container(
                  decoration: BoxDecoration(
                    color: Color(0xFF212176),
                    borderRadius: BorderRadius.only(
                      bottomRight: Radius.circular(100),
                    ),
                  ),
                  child: SizedBox(
                    width: 278,
                    height: 959,
                    child: Container(
                      padding: EdgeInsets.fromLTRB(9.2, 15.8, 9.2, 0),
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.start,
                        crossAxisAlignment: CrossAxisAlignment.center,
                        children: [
                          Container(
                            margin: EdgeInsets.fromLTRB(0, 0, 0, 16.9),
                            child: Align(
                              alignment: Alignment.topLeft,
                              child: Row(
                                mainAxisAlignment: MainAxisAlignment.start,
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Container(
                                    margin: EdgeInsets.fromLTRB(0, 0, 43.5, 0),
                                    child: SizedBox(
                                      width: 47.3,
                                      height: 65.3,
                                      child: SvgPicture.asset(
                                        'assets/vectors/hamburger_17_x2.svg',
                                      ),
                                    ),
                                  ),
                                  Container(
                                    margin: EdgeInsets.fromLTRB(0, 32.2, 0, 13.1),
                                    child: Row(
                                      mainAxisAlignment: MainAxisAlignment.start,
                                      crossAxisAlignment: CrossAxisAlignment.start,
                                      children: [
                                        Container(
                                          margin: EdgeInsets.fromLTRB(0, 3, 8, 1),
                                          child: SizedBox(
                                            width: 17,
                                            height: 16,
                                            child: SvgPicture.asset(
                                              'assets/vectors/vector_316_x2.svg',
                                            ),
                                          ),
                                        ),
                                        Text(
                                          'Audio visual',
                                          style: GoogleFonts.getFont(
                                            'Fira Sans Condensed',
                                            fontWeight: FontWeight.w600,
                                            fontSize: 17,
                                            color: Color(0xFFFFFFFF),
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ),
                          Container(
                            margin: EdgeInsets.fromLTRB(35.8, 0, 0, 34),
                            child: Row(
                              mainAxisAlignment: MainAxisAlignment.start,
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Container(
                                  margin: EdgeInsets.fromLTRB(0, 2.5, 4.5, 2.5),
                                  child: SizedBox(
                                    width: 16.5,
                                    height: 15,
                                    child: SvgPicture.asset(
                                      'assets/vectors/vector_414_x2.svg',
                                    ),
                                  ),
                                ),
                                Text(
                                  'Equipamento',
                                  style: GoogleFonts.getFont(
                                    'Fira Sans Condensed',
                                    fontWeight: FontWeight.w600,
                                    fontSize: 17,
                                    color: Color(0xFFFFFFFF),
                                  ),
                                ),
                              ],
                            ),
                          ),
                          Container(
                            margin: EdgeInsets.fromLTRB(8.6, 0, 0, 31),
                            child: Row(
                              mainAxisAlignment: MainAxisAlignment.start,
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Container(
                                  margin: EdgeInsets.fromLTRB(0, 1, 10, 3),
                                  child: SizedBox(
                                    width: 15,
                                    height: 16,
                                    child: SvgPicture.asset(
                                      'assets/vectors/container_22_x2.svg',
                                    ),
                                  ),
                                ),
                                Text(
                                  'Usuários',
                                  style: GoogleFonts.getFont(
                                    'Fira Sans Condensed',
                                    fontWeight: FontWeight.w600,
                                    fontSize: 17,
                                    color: Color(0xFFFFFFFF),
                                  ),
                                ),
                              ],
                            ),
                          ),
                          Container(
                            margin: EdgeInsets.fromLTRB(27.6, 0, 0, 33),
                            child: Row(
                              mainAxisAlignment: MainAxisAlignment.start,
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Container(
                                  margin: EdgeInsets.fromLTRB(0, 1, 10, 3),
                                  child: SizedBox(
                                    width: 15,
                                    height: 16,
                                    child: SvgPicture.asset(
                                      'assets/vectors/container_83_x2.svg',
                                    ),
                                  ),
                                ),
                                Text(
                                  'Relatorios
                                ',
                                  style: GoogleFonts.getFont(
                                    'Fira Sans Condensed',
                                    fontWeight: FontWeight.w600,
                                    fontSize: 17,
                                    color: Color(0xFFFFFFFF),
                                  ),
                                ),
                              ],
                            ),
                          ),
                          Container(
                            margin: EdgeInsets.fromLTRB(7.2, 0, 0, 0),
                            child: Row(
                              mainAxisAlignment: MainAxisAlignment.start,
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Container(
                                  margin: EdgeInsets.fromLTRB(0, 5, 8, 0),
                                  child: SizedBox(
                                    width: 18,
                                    height: 16,
                                    child: SvgPicture.asset(
                                      'assets/vectors/vector_43_x2.svg',
                                    ),
                                  ),
                                ),
                                Container(
                                  margin: EdgeInsets.fromLTRB(0, 0, 0, 1),
                                  child: Text(
                                    'Reservas',
                                    style: GoogleFonts.getFont(
                                      'Fira Sans Condensed',
                                      fontWeight: FontWeight.w600,
                                      fontSize: 17,
                                      color: Color(0xFFFFFFFF),
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ),
              ),
              Positioned(
                right: -39,
                top: -34,
                child: Container(
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(5),
                    color: Color(0xFF000041),
                    boxShadow: [
                      BoxShadow(
                        color: Color(0x40000000),
                        offset: Offset(0, 4),
                        blurRadius: 2,
                      ),
                    ],
                  ),
                  child: SizedBox(
                    width: 1479,
                    height: 82,
                    child: Container(
                      padding: EdgeInsets.fromLTRB(0, 4, 74, 6),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Container(
                            decoration: BoxDecoration(
                              image: DecorationImage(
                                fit: BoxFit.cover,
                                image: AssetImage(
                                  'assets/images/image_2.png',
                                ),
                              ),
                            ),
                            child: Container(
                              width: 189,
                              height: 72,
                            ),
                          ),
                          Container(
                            margin: EdgeInsets.fromLTRB(0, 6, 0, 9),
                            child: Row(
                              mainAxisAlignment: MainAxisAlignment.start,
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Container(
                                  margin: EdgeInsets.fromLTRB(0, 0, 17, 0),
                                  child: SizedBox(
                                    width: 59,
                                    height: 57,
                                    child: SvgPicture.asset(
                                      'assets/vectors/group_182_x2.svg',
                                    ),
                                  ),
                                ),
                                Container(
                                  margin: EdgeInsets.fromLTRB(0, 19, 0, 19),
                                  child: Text(
                                    'Logado: Waltair',
                                    style: GoogleFonts.getFont(
                                      'Fira Sans Condensed',
                                      fontWeight: FontWeight.w600,
                                      fontSize: 16,
                                      color: Color(0xFFFFFFFF),
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ),
                          Container(
                            margin: EdgeInsets.fromLTRB(0, 14, 0, 16),
                            child: Row(
                              mainAxisAlignment: MainAxisAlignment.start,
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Container(
                                  margin: EdgeInsets.fromLTRB(0, 0, 31, 0),
                                  child: Container(
                                    padding: EdgeInsets.fromLTRB(17, 11, 17, 12),
                                    child: Stack(
                                      clipBehavior: Clip.none,
                                      children: [
                                        Text(
                                          'Encerrar sessão',
                                          style: GoogleFonts.getFont(
                                            'Fira Sans Condensed',
                                            fontWeight: FontWeight.w600,
                                            fontSize: 16,
                                            color: Color(0xFFFFFFFF),
                                          ),
                                        ),
                                        Positioned(
                                          bottom: -12,
                                          child: Container(
                                            width: 138,
                                            height: 42,
                                            decoration: BoxDecoration(
                                              border: Border.all(color: Color(0xFFFFFFFF)),
                                              borderRadius: BorderRadius.circular(19),
                                            ),
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                ),
                                Container(
                                  decoration: BoxDecoration(
                                    color: Color(0xFF202075),
                                  ),
                                  child: SizedBox(
                                    width: 53,
                                    child: Container(
                                      padding: EdgeInsets.fromLTRB(2.7, 12.9, 7.7, 12.6),
                                      child: Stack(
                                        clipBehavior: Clip.none,
                                        children: [
                                          SizedBox(
                                            width: 42.6,
                                            child: Column(
                                              mainAxisAlignment: MainAxisAlignment.start,
                                              crossAxisAlignment: CrossAxisAlignment.center,
                                              children: [
                                                Container(
                                                  margin: EdgeInsets.fromLTRB(7.4, 0, 2.7, 4),
                                                  child: ClipRRect(
                                                    borderRadius: BorderRadius.circular(40),
                                                    child: SizedBox(
                                                      width: 32.5,
                                                      height: 2.8,
                                                      child: SvgPicture.asset(
                                                        'assets/vectors/rectangle_222_x2.svg',
                                                      ),
                                                    ),
                                                  ),
                                                ),
                                                Container(
                                                  margin: EdgeInsets.fromLTRB(7.4, 0, 2.7, 4),
                                                  child: ClipRRect(
                                                    borderRadius: BorderRadius.circular(40),
                                                    child: SizedBox(
                                                      width: 32.5,
                                                      height: 2.8,
                                                      child: SvgPicture.asset(
                                                        'assets/vectors/rectangle_313_x2.svg',
                                                      ),
                                                    ),
                                                  ),
                                                ),
                                                ClipRRect(
                                                  borderRadius: BorderRadius.circular(40),
                                                  child: SizedBox(
                                                    width: 42.6,
                                                    height: 2.8,
                                                    child: SvgPicture.asset(
                                                      'assets/vectors/rectangle_411_x2.svg',
                                                    ),
                                                  ),
                                                ),
                                              ],
                                            ),
                                          ),
                                          Positioned(
                                            left: -2.7,
                                            top: -11.9,
                                            child: Container(
                                              decoration: BoxDecoration(
                                                color: Color(0x03FFFFFF),
                                              ),
                                              child: Container(
                                                width: 48.7,
                                                height: 34.7,
                                              ),
                                            ),
                                          ),
                                        ],
                                      ),
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ),
              ),
              Positioned(
                right: -23.1,
                top: 148,
                child: ImageFiltered(
                  imageFilter: ImageFilter.blur(
                    sigmaX: 2,
                    sigmaY: 2,
                  ),
                  child: Stack(
                    children: [
                    Positioned(
                      left: -13.4,
                      top: -5.4,
                      child: Container(
                        decoration: BoxDecoration(
                          color: Color(0xFF000041),
                        ),
                        child: Container(
                          width: 98,
                          height: 28,
                        ),
                      ),
                    ),
              SizedBox(
                        width: 168.1,
                        height: 28,
                        child: Container(
                          padding: EdgeInsets.fromLTRB(13.4, 5.4, 0, 7.4),
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.start,
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Container(
                                margin: EdgeInsets.fromLTRB(0, 0, 7.4, 0),
                                child: SizedBox(
                                  width: 15.2,
                                  height: 15.2,
                                  child: SvgPicture.asset(
                                    'assets/vectors/vector_114_x2.svg',
                                  ),
                                ),
                              ),
                              Container(
                                margin: EdgeInsets.fromLTRB(0, 2.6, 0, 0.6),
                                child: Text(
                                  'Consultar',
                                  style: GoogleFonts.getFont(
                                    'Fira Sans Condensed',
                                    fontWeight: FontWeight.w600,
                                    fontSize: 10,
                                    color: Color(0xFFFFFFFF),
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}