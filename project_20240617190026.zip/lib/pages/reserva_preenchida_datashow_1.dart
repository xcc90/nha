import 'package:flutter/material.dart';
import 'dart:ui';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:flutter_app/utils.dart';
import 'package:google_fonts/google_fonts.dart';

class ReservaPreenchidaDatashow1 extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return 
    Container(
      decoration: BoxDecoration(
        color: Color(0xFFFFFFFF),
      ),
      child: SizedBox(
        width: 1440,
        child: Container(
          padding: EdgeInsets.fromLTRB(7, 34, 0, 21),
          child: Stack(
            clipBehavior: Clip.none,
            children: [
              Column(
                mainAxisAlignment: MainAxisAlignment.start,
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  Container(
                    margin: EdgeInsets.fromLTRB(868.7, 0, 0, 33),
                    child: Text(
                      'logado: Waltair',
                      style: GoogleFonts.getFont(
                        'Fira Sans Condensed',
                        fontWeight: FontWeight.w300,
                        fontSize: 16,
                        color: Color(0xFFFFFFFF),
                      ),
                    ),
                  ),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.start,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Container(
                        margin: EdgeInsets.fromLTRB(0, 15, 45, 755),
                        child: Column(
                          mainAxisAlignment: MainAxisAlignment.start,
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Container(
                              margin: EdgeInsets.fromLTRB(1, 0, 1, 10),
                              child: Align(
                                alignment: Alignment.topLeft,
                                child: Row(
                                  mainAxisAlignment: MainAxisAlignment.start,
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Container(
                                      margin: EdgeInsets.fromLTRB(0, 0, 8, 5),
                                      child: SizedBox(
                                        width: 18,
                                        height: 16,
                                        child: SvgPicture.asset(
                                          'assets/vectors/vector_74_x2.svg',
                                        ),
                                      ),
                                    ),
                                    Container(
                                      margin: EdgeInsets.fromLTRB(0, 2, 0, 0),
                                      child: Text(
                                        'inicio
                                    ',
                                        style: GoogleFonts.getFont(
                                          'Fira Sans Condensed',
                                          fontWeight: FontWeight.w300,
                                          fontSize: 16,
                                          color: Color(0xFFFFFFFF),
                                        ),
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                            ),
                            Container(
                              margin: EdgeInsets.fromLTRB(0, 0, 0.2, 13),
                              child: Row(
                                mainAxisAlignment: MainAxisAlignment.start,
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Container(
                                    margin: EdgeInsets.fromLTRB(0, 5, 8, 0),
                                    child: SizedBox(
                                      width: 18,
                                      height: 16,
                                      child: SvgPicture.asset(
                                        'assets/vectors/vector_213_x2.svg',
                                      ),
                                    ),
                                  ),
                                  Container(
                                    margin: EdgeInsets.fromLTRB(0, 0, 0, 2),
                                    child: Text(
                                      'consultar reservas',
                                      style: GoogleFonts.getFont(
                                        'Fira Sans Condensed',
                                        fontWeight: FontWeight.w300,
                                        fontSize: 16,
                                        color: Color(0xFFFFFFFF),
                                      ),
                                    ),
                                  ),
                                ],
                              ),
                            ),
                            Container(
                              margin: EdgeInsets.fromLTRB(0.8, 0, 0, 10),
                              child: Row(
                                mainAxisAlignment: MainAxisAlignment.start,
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Container(
                                    margin: EdgeInsets.fromLTRB(0, 2.5, 8.8, 1.5),
                                    child: SizedBox(
                                      width: 16.5,
                                      height: 15,
                                      child: SvgPicture.asset(
                                        'assets/vectors/vector_285_x2.svg',
                                      ),
                                    ),
                                  ),
                                  Text(
                                    'adicionar material',
                                    style: GoogleFonts.getFont(
                                      'Fira Sans Condensed',
                                      fontWeight: FontWeight.w300,
                                      fontSize: 16,
                                      color: Color(0xFFFFFFFF),
                                    ),
                                  ),
                                ],
                              ),
                            ),
                            Container(
                              margin: EdgeInsets.fromLTRB(1, 0, 6.6, 15),
                              child: Row(
                                mainAxisAlignment: MainAxisAlignment.start,
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Container(
                                    margin: EdgeInsets.fromLTRB(0, 3, 8, 0),
                                    child: SizedBox(
                                      width: 17,
                                      height: 16,
                                      child: SvgPicture.asset(
                                        'assets/vectors/vector_108_x2.svg',
                                      ),
                                    ),
                                  ),
                                  Text(
                                    'adicionar reserva',
                                    style: GoogleFonts.getFont(
                                      'Fira Sans Condensed',
                                      fontWeight: FontWeight.w300,
                                      fontSize: 16,
                                      color: Color(0xFFFFFFFF),
                                    ),
                                  ),
                                ],
                              ),
                            ),
                            Container(
                              margin: EdgeInsets.fromLTRB(1, 0, 1, 0),
                              child: Align(
                                alignment: Alignment.topLeft,
                                child: Row(
                                  mainAxisAlignment: MainAxisAlignment.start,
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Container(
                                      margin: EdgeInsets.fromLTRB(0, 1, 10, 2),
                                      child: SizedBox(
                                        width: 15,
                                        height: 16,
                                        child: SvgPicture.asset(
                                          'assets/vectors/container_58_x2.svg',
                                        ),
                                      ),
                                    ),
                                    Text(
                                      'relatorios
                                    ',
                                      style: GoogleFonts.getFont(
                                        'Fira Sans Condensed',
                                        fontWeight: FontWeight.w300,
                                        fontSize: 16,
                                        color: Color(0xFFFFFFFF),
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                      Stack(
                        children: [
                          Column(
                            mainAxisAlignment: MainAxisAlignment.start,
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Container(
                                margin: EdgeInsets.fromLTRB(0, 0, 0, 26),
                                child: Container(
                                  decoration: BoxDecoration(
                                    color: Color(0xFFD9D9D9),
                                  ),
                                  child: Container(
                                    width: 1244,
                                    height: 36,
                                  ),
                                ),
                              ),
                              Container(
                                margin: EdgeInsets.fromLTRB(16, 0, 31, 30),
                                decoration: BoxDecoration(
                                  border: Border.all(color: Color(0xFFAA9D9D)),
                                  color: Color(0xFFD9D9D9),
                                ),
                                child: Container(
                                  padding: EdgeInsets.fromLTRB(20, 21, 0, 52),
                                  child: Column(
                                    mainAxisAlignment: MainAxisAlignment.start,
                                    crossAxisAlignment: CrossAxisAlignment.start,
                                    children: [
                                      Container(
                                        margin: EdgeInsets.fromLTRB(0, 0, 0, 20),
                                        child: Align(
                                          alignment: Alignment.topLeft,
                                          child: Stack(
                                            children: [
                                              Row(
                                                mainAxisAlignment: MainAxisAlignment.start,
                                                crossAxisAlignment: CrossAxisAlignment.start,
                                                children: [
                                                  ImageFiltered(
                                                    imageFilter: ImageFilter.blur(
                                                      sigmaX: 2,
                                                      sigmaY: 2,
                                                    ),
                                                    child: Column(
                                                      mainAxisAlignment: MainAxisAlignment.start,
                                                      crossAxisAlignment: CrossAxisAlignment.start,
                                                      children: [
                                                        Align(
                                                          alignment: Alignment.topLeft,
                                                          child: Text(
                                                            'Data Inicial',
                                                            style: GoogleFonts.getFont(
                                                              'Fira Sans Condensed',
                                                              fontWeight: FontWeight.w600,
                                                              fontSize: 10,
                                                              color: Color(0xFF000000),
                                                            ),
                                                          ),
                                                        ),
                                                        Container(
                                                          decoration: BoxDecoration(
                                                            border: Border.all(color: Color(0xFFAAA1A1)),
                                                            color: Color(0xFFFFFFFF),
                                                          ),
                                                          child: SizedBox(
                                                            width: 187.8,
                                                            child: Container(
                                                              padding: EdgeInsets.fromLTRB(4.8, 2.3, 0, 3.5),
                                                              child: Row(
                                                                mainAxisAlignment: MainAxisAlignment.start,
                                                                crossAxisAlignment: CrossAxisAlignment.start,
                                                                children: [
                                                                  Container(
                                                                    margin: EdgeInsets.fromLTRB(0, 0, 4.8, 0),
                                                                    child: SizedBox(
                                                                      width: 30.2,
                                                                      height: 23.4,
                                                                      child: SvgPicture.asset(
                                                                        'assets/vectors/vector_313_x2.svg',
                                                                      ),
                                                                    ),
                                                                  ),
                                                                  Container(
                                                                    margin: EdgeInsets.fromLTRB(0, 1.2, 0, 0),
                                                                    child: Container(
                                                                      decoration: BoxDecoration(
                                                                        color: Color(0xFFAA9D9D),
                                                                      ),
                                                                      child: Container(
                                                                        width: 1,
                                                                        height: 22.3,
                                                                      ),
                                                                    ),
                                                                  ),
                                                                ],
                                                              ),
                                                            ),
                                                          ),
                                                        ),
                                                      ],
                                                    ),
                                                  ),
                                                  Container(
                                                    margin: EdgeInsets.fromLTRB(0, 0, 0, 0),
                                                    child: ImageFiltered(
                                                      imageFilter: ImageFilter.blur(
                                                        sigmaX: 2,
                                                        sigmaY: 2,
                                                      ),
                                                      child: Column(
                                                        mainAxisAlignment: MainAxisAlignment.start,
                                                        crossAxisAlignment: CrossAxisAlignment.start,
                                                        children: [
                                                          Align(
                                                            alignment: Alignment.topLeft,
                                                            child: Text(
                                                              'Data Final',
                                                              style: GoogleFonts.getFont(
                                                                'Fira Sans Condensed',
                                                                fontWeight: FontWeight.w600,
                                                                fontSize: 10,
                                                                color: Color(0xFF000000),
                                                              ),
                                                            ),
                                                          ),
                                                          Container(
                                                            decoration: BoxDecoration(
                                                              border: Border.all(color: Color(0xFFAAA1A1)),
                                                              color: Color(0xFFFFFFFF),
                                                            ),
                                                            child: SizedBox(
                                                              width: 187.8,
                                                              child: Container(
                                                                padding: EdgeInsets.fromLTRB(4.8, 2.3, 0, 3.5),
                                                                child: Row(
                                                                  mainAxisAlignment: MainAxisAlignment.start,
                                                                  crossAxisAlignment: CrossAxisAlignment.start,
                                                                  children: [
                                                                    Container(
                                                                      margin: EdgeInsets.fromLTRB(0, 0, 4.8, 0),
                                                                      child: SizedBox(
                                                                        width: 30.2,
                                                                        height: 23.4,
                                                                        child: SvgPicture.asset(
                                                                          'assets/vectors/vector_14_x2.svg',
                                                                        ),
                                                                      ),
                                                                    ),
                                                                    Container(
                                                                      margin: EdgeInsets.fromLTRB(0, 1.2, 0, 0),
                                                                      child: Container(
                                                                        decoration: BoxDecoration(
                                                                          color: Color(0xFFAA9D9D),
                                                                        ),
                                                                        child: Container(
                                                                          width: 1,
                                                                          height: 22.3,
                                                                        ),
                                                                      ),
                                                                    ),
                                                                  ],
                                                                ),
                                                              ),
                                                            ),
                                                          ),
                                                        ],
                                                      ),
                                                    ),
                                                  ),
                                                  ImageFiltered(
                                                    imageFilter: ImageFilter.blur(
                                                      sigmaX: 2,
                                                      sigmaY: 2,
                                                    ),
                                                    child: Column(
                                                      mainAxisAlignment: MainAxisAlignment.start,
                                                      crossAxisAlignment: CrossAxisAlignment.start,
                                                      children: [
                                                        Align(
                                                          alignment: Alignment.topLeft,
                                                          child: Text(
                                                            'Setor',
                                                            style: GoogleFonts.getFont(
                                                              'Fira Sans Condensed',
                                                              fontWeight: FontWeight.w600,
                                                              fontSize: 10,
                                                              color: Color(0xFF000000),
                                                            ),
                                                          ),
                                                        ),
                                                        Container(
                                                          decoration: BoxDecoration(
                                                            border: Border.all(color: Color(0xFFAAA1A1)),
                                                            color: Color(0xFFFFFFFF),
                                                          ),
                                                          child: Container(
                                                            width: 187.8,
                                                            height: 29.3,
                                                            padding: EdgeInsets.fromLTRB(9, 3.5, 9, 3.5),
                                                            child: SizedBox(
                                                              width: 31.8,
                                                              height: 22.3,
                                                              child: SvgPicture.asset(
                                                                'assets/vectors/container_61_x2.svg',
                                                              ),
                                                            ),
                                                          ),
                                                        ),
                                                      ],
                                                    ),
                                                  ),
                                                  ImageFiltered(
                                                    imageFilter: ImageFilter.blur(
                                                      sigmaX: 2,
                                                      sigmaY: 2,
                                                    ),
                                                    child: Column(
                                                      mainAxisAlignment: MainAxisAlignment.start,
                                                      crossAxisAlignment: CrossAxisAlignment.start,
                                                      children: [
                                                        Align(
                                                          alignment: Alignment.topLeft,
                                                          child: Text(
                                                            'Responsavel',
                                                            style: GoogleFonts.getFont(
                                                              'Fira Sans Condensed',
                                                              fontWeight: FontWeight.w600,
                                                              fontSize: 10,
                                                              color: Color(0xFF000000),
                                                            ),
                                                          ),
                                                        ),
                                                        Container(
                                                          decoration: BoxDecoration(
                                                            border: Border.all(color: Color(0xFFAAA1A1)),
                                                            color: Color(0xFFFFFFFF),
                                                          ),
                                                          child: Container(
                                                            width: 187.8,
                                                            height: 29.3,
                                                            padding: EdgeInsets.fromLTRB(10, 3.5, 10, 3.5),
                                                            child: SizedBox(
                                                              width: 30.8,
                                                              height: 22.3,
                                                              child: SvgPicture.asset(
                                                                'assets/vectors/container_91_x2.svg',
                                                              ),
                                                            ),
                                                          ),
                                                        ),
                                                      ],
                                                    ),
                                                  ),
                                                  ImageFiltered(
                                                    imageFilter: ImageFilter.blur(
                                                      sigmaX: 2,
                                                      sigmaY: 2,
                                                    ),
                                                    child: Column(
                                                      mainAxisAlignment: MainAxisAlignment.start,
                                                      crossAxisAlignment: CrossAxisAlignment.start,
                                                      children: [
                                                        Align(
                                                          alignment: Alignment.topLeft,
                                                          child: Text(
                                                            'Situação',
                                                            style: GoogleFonts.getFont(
                                                              'Fira Sans Condensed',
                                                              fontWeight: FontWeight.w600,
                                                              fontSize: 10,
                                                              color: Color(0xFF000000),
                                                            ),
                                                          ),
                                                        ),
                                                        Container(
                                                          decoration: BoxDecoration(
                                                            border: Border.all(color: Color(0xFFAAA1A1)),
                                                            color: Color(0xFFFFFFFF),
                                                          ),
                                                          child: Container(
                                                            width: 187.8,
                                                            height: 29.3,
                                                            padding: EdgeInsets.fromLTRB(9, 3.5, 9, 3.5),
                                                            child: SizedBox(
                                                              width: 31.8,
                                                              height: 22.3,
                                                              child: SvgPicture.asset(
                                                                'assets/vectors/container_89_x2.svg',
                                                              ),
                                                            ),
                                                          ),
                                                        ),
                                                      ],
                                                    ),
                                                  ),
                                                ],
                                              ),
                                              Positioned(
                                                right: 207,
                                                bottom: 0,
                                                child: ImageFiltered(
                                                  imageFilter: ImageFilter.blur(
                                                    sigmaX: 2,
                                                    sigmaY: 2,
                                                  ),
                                                  child: SizedBox(
                                                    width: 187.8,
                                                    height: 41,
                                                    child: Column(
                                                      mainAxisAlignment: MainAxisAlignment.start,
                                                      crossAxisAlignment: CrossAxisAlignment.start,
                                                      children: [
                                                        Align(
                                                          alignment: Alignment.topLeft,
                                                          child: Text(
                                                            'Responsavel',
                                                            style: GoogleFonts.getFont(
                                                              'Fira Sans Condensed',
                                                              fontWeight: FontWeight.w600,
                                                              fontSize: 10,
                                                              color: Color(0xFF000000),
                                                            ),
                                                          ),
                                                        ),
                                                        Container(
                                                          decoration: BoxDecoration(
                                                            border: Border.all(color: Color(0xFFAAA1A1)),
                                                            color: Color(0xFFFFFFFF),
                                                          ),
                                                          child: Container(
                                                            width: 187.8,
                                                            height: 29.3,
                                                            padding: EdgeInsets.fromLTRB(10, 3.5, 10, 3.5),
                                                            child: SizedBox(
                                                              width: 30.8,
                                                              height: 22.3,
                                                              child: SvgPicture.asset(
                                                                'assets/vectors/container_9_x2.svg',
                                                              ),
                                                            ),
                                                          ),
                                                        ),
                                                      ],
                                                    ),
                                                  ),
                                                ),
                                              ),
                                              Positioned(
                                                left: 66,
                                                bottom: 9,
                                                child: ImageFiltered(
                                                  imageFilter: ImageFilter.blur(
                                                    sigmaX: 2,
                                                    sigmaY: 2,
                                                  ),
                                                  child: SizedBox(
                                                    height: 15,
                                                    child: Text(
                                                      '09/11/2022',
                                                      style: GoogleFonts.getFont(
                                                        'Inter',
                                                        fontWeight: FontWeight.w400,
                                                        fontSize: 12,
                                                        color: Color(0xFF000000),
                                                      ),
                                                    ),
                                                  ),
                                                ),
                                              ),
                                              Positioned(
                                                left: 277,
                                                bottom: 9,
                                                child: ImageFiltered(
                                                  imageFilter: ImageFilter.blur(
                                                    sigmaX: 2,
                                                    sigmaY: 2,
                                                  ),
                                                  child: SizedBox(
                                                    height: 15,
                                                    child: Text(
                                                      '21/11/2022',
                                                      style: GoogleFonts.getFont(
                                                        'Inter',
                                                        fontWeight: FontWeight.w400,
                                                        fontSize: 12,
                                                        color: Color(0xFF000000),
                                                      ),
                                                    ),
                                                  ),
                                                ),
                                              ),
                                              Positioned(
                                                left: 480,
                                                bottom: 9,
                                                child: ImageFiltered(
                                                  imageFilter: ImageFilter.blur(
                                                    sigmaX: 2,
                                                    sigmaY: 2,
                                                  ),
                                                  child: SizedBox(
                                                    height: 15,
                                                    child: Text(
                                                      'Bloco C',
                                                      style: GoogleFonts.getFont(
                                                        'Inter',
                                                        fontWeight: FontWeight.w400,
                                                        fontSize: 12,
                                                        color: Color(0xFF000000),
                                                      ),
                                                    ),
                                                  ),
                                                ),
                                              ),
                                              Positioned(
                                                right: 264,
                                                bottom: 9,
                                                child: ImageFiltered(
                                                  imageFilter: ImageFilter.blur(
                                                    sigmaX: 2,
                                                    sigmaY: 2,
                                                  ),
                                                  child: SizedBox(
                                                    height: 15,
                                                    child: Text(
                                                      'Germano',
                                                      style: GoogleFonts.getFont(
                                                        'Inter',
                                                        fontWeight: FontWeight.w400,
                                                        fontSize: 12,
                                                        color: Color(0xFF000000),
                                                      ),
                                                    ),
                                                  ),
                                                ),
                                              ),
                                              Positioned(
                                                right: 53.8,
                                                bottom: 8,
                                                child: ImageFiltered(
                                                  imageFilter: ImageFilter.blur(
                                                    sigmaX: 2,
                                                    sigmaY: 2,
                                                  ),
                                                  child: SizedBox(
                                                    height: 15,
                                                    child: Text(
                                                      'Reservada',
                                                      style: GoogleFonts.getFont(
                                                        'Inter',
                                                        fontWeight: FontWeight.w400,
                                                        fontSize: 12,
                                                        color: Color(0xFF000000),
                                                      ),
                                                    ),
                                                  ),
                                                ),
                                              ),
                                            ],
                                          ),
                                        ),
                                      ),
                                      Align(
                                        alignment: Alignment.topLeft,
                                        child: ImageFiltered(
                                          imageFilter: ImageFilter.blur(
                                            sigmaX: 2,
                                            sigmaY: 2,
                                          ),
                                          child: Stack(
                                            children: [
                                            Positioned(
                                              left: -6,
                                              top: -7,
                                              child: Container(
                                                decoration: BoxDecoration(
                                                  color: Color(0xFF000041),
                                                ),
                                                child: Container(
                                                  width: 144,
                                                  height: 28,
                                                ),
                                              ),
                                            ),
                                      SizedBox(
                                                width: 162.1,
                                                child: Container(
                                                  padding: EdgeInsets.fromLTRB(6, 7, 0, 7),
                                                  child: Row(
                                                    mainAxisAlignment: MainAxisAlignment.start,
                                                    crossAxisAlignment: CrossAxisAlignment.start,
                                                    children: [
                                                      Container(
                                                        margin: EdgeInsets.fromLTRB(0, 0, 10, 0),
                                                        child: SizedBox(
                                                          width: 14,
                                                          height: 14,
                                                          child: SvgPicture.asset(
                                                            'assets/vectors/vector_196_x2.svg',
                                                          ),
                                                        ),
                                                      ),
                                                      Container(
                                                        margin: EdgeInsets.fromLTRB(0, 1, 0, 1),
                                                        child: Text(
                                                          'Atendimento Expresso',
                                                          style: GoogleFonts.getFont(
                                                            'Fira Sans Condensed',
                                                            fontWeight: FontWeight.w600,
                                                            fontSize: 10,
                                                            color: Color(0xFFFFFFFF),
                                                          ),
                                                        ),
                                                      ),
                                                    ],
                                                  ),
                                                ),
                                              ),
                                            ],
                                          ),
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                              ),
                              Container(
                                margin: EdgeInsets.fromLTRB(16, 0, 31, 0),
                                child: Container(
                                  decoration: BoxDecoration(
                                    color: Color(0xFFD9D9D9),
                                  ),
                                  child: SizedBox(
                                    height: 663,
                                    child: Container(
                                      padding: EdgeInsets.fromLTRB(0, 1, 0, 0),
                                      child: Stack(
                                        clipBehavior: Clip.none,
                                        children: [
                                          Column(
                                            mainAxisAlignment: MainAxisAlignment.start,
                                            crossAxisAlignment: CrossAxisAlignment.start,
                                            children: [
                                              Container(
                                                margin: EdgeInsets.fromLTRB(0, 0, 0, 3),
                                                child: ImageFiltered(
                                                  imageFilter: ImageFilter.blur(
                                                    sigmaX: 2,
                                                    sigmaY: 2,
                                                  ),
                                                  child: Stack(
                                                    children: [
                                                    Positioned(
                                                      top: -7,
                                                      child: Container(
                                                        decoration: BoxDecoration(
                                                          color: Color(0xFF212176),
                                                        ),
                                                        child: Container(
                                                          width: 1197,
                                                          height: 31,
                                                        ),
                                                      ),
                                                    ),
                                              SizedBox(
                                                        width: 1197,
                                                        child: Container(
                                                          padding: EdgeInsets.fromLTRB(5, 7, 0, 16),
                                                          child: Row(
                                                            mainAxisAlignment: MainAxisAlignment.start,
                                                            crossAxisAlignment: CrossAxisAlignment.start,
                                                            children: [
                                                              Container(
                                                                margin: EdgeInsets.fromLTRB(0, 0, 3, 0),
                                                                child: SizedBox(
                                                                  width: 20,
                                                                  height: 20,
                                                                  child: SvgPicture.asset(
                                                                    'assets/vectors/vector_178_x2.svg',
                                                                  ),
                                                                ),
                                                              ),
                                                              Container(
                                                                margin: EdgeInsets.fromLTRB(0, 5, 0, 3),
                                                                child: Text(
                                                                  'Atividades',
                                                                  style: GoogleFonts.getFont(
                                                                    'Fira Sans Condensed',
                                                                    fontWeight: FontWeight.w600,
                                                                    fontSize: 10,
                                                                    color: Color(0xFFFFFFFF),
                                                                  ),
                                                                ),
                                                              ),
                                                            ],
                                                          ),
                                                        ),
                                                      ),
                                                    ],
                                                  ),
                                                ),
                                              ),
                                              Container(
                                                margin: EdgeInsets.fromLTRB(10, 0, 10, 0),
                                                child: Align(
                                                  alignment: Alignment.topLeft,
                                                  child: ImageFiltered(
                                                    imageFilter: ImageFilter.blur(
                                                      sigmaX: 2,
                                                      sigmaY: 2,
                                                    ),
                                                    child: Container(
                                                      padding: EdgeInsets.fromLTRB(0, 0, 3.7, 0),
                                                      child: Stack(
                                                        clipBehavior: Clip.none,
                                                        children: [
                                                          Column(
                                                            mainAxisAlignment: MainAxisAlignment.start,
                                                            crossAxisAlignment: CrossAxisAlignment.center,
                                                            children: [
                                                              Container(
                                                                margin: EdgeInsets.fromLTRB(0, 0, 1, 6.7),
                                                                child: Container(
                                                                  decoration: BoxDecoration(
                                                                    color: Color(0xFF4228D7),
                                                                  ),
                                                                  child: Container(
                                                                    padding: EdgeInsets.fromLTRB(12, 4, 16.3, 4.3),
                                                                    child: Text(
                                                                      'nº Reserva',
                                                                      style: GoogleFonts.getFont(
                                                                        'Fira Sans Condensed',
                                                                        fontWeight: FontWeight.w600,
                                                                        fontSize: 10,
                                                                        color: Color(0xFFFFFFFF),
                                                                      ),
                                                                    ),
                                                                  ),
                                                                ),
                                                              ),
                                                              Container(
                                                                margin: EdgeInsets.fromLTRB(0, 0, 1, 7),
                                                                child: SizedBox(
                                                                  width: 73.2,
                                                                  child: Container(
                                                                    padding: EdgeInsets.fromLTRB(0, 0, 0.9, 4),
                                                                    child: Stack(
                                                                      clipBehavior: Clip.none,
                                                                      children: [
                                                                        Positioned(
                                                                          bottom: 0,
                                                                          child: Container(
                                                                            width: 73.2,
                                                                            height: 14.3,
                                                                            decoration: BoxDecoration(
                                                                              border: Border(
                                                                                bottom: BorderSize(
                                                                                  color: Color(0xFFAA9D9D),
                                                                                  width: 1,
                                                                                ),
                                                                              ),
                                                                            ),
                                                                          ),
                                                                        ),
                                                                        Text(
                                                                          '254',
                                                                          style: GoogleFonts.getFont(
                                                                            'Fira Sans Condensed',
                                                                            fontWeight: FontWeight.w500,
                                                                            fontSize: 10,
                                                                            color: Color(0xFF3E3636),
                                                                          ),
                                                                        ),
                                                                      ],
                                                                    ),
                                                                  ),
                                                                ),
                                                              ),
                                                              Container(
                                                                margin: EdgeInsets.fromLTRB(0, 0, 1, 5),
                                                                child: SizedBox(
                                                                  width: 73.2,
                                                                  child: Container(
                                                                    padding: EdgeInsets.fromLTRB(0, 0, 1.2, 4),
                                                                    child: Stack(
                                                                      clipBehavior: Clip.none,
                                                                      children: [
                                                                        Positioned(
                                                                          bottom: 0,
                                                                          child: Container(
                                                                            width: 73.2,
                                                                            height: 14.3,
                                                                            decoration: BoxDecoration(
                                                                              border: Border(
                                                                                bottom: BorderSize(
                                                                                  color: Color(0xFFAA9D9D),
                                                                                  width: 1,
                                                                                ),
                                                                              ),
                                                                            ),
                                                                          ),
                                                                        ),
                                                                        Text(
                                                                          '255',
                                                                          style: GoogleFonts.getFont(
                                                                            'Fira Sans Condensed',
                                                                            fontWeight: FontWeight.w500,
                                                                            fontSize: 10,
                                                                            color: Color(0xFF3E3636),
                                                                          ),
                                                                        ),
                                                                      ],
                                                                    ),
                                                                  ),
                                                                ),
                                                              ),
                                                              Container(
                                                                margin: EdgeInsets.fromLTRB(1, 0, 0, 0),
                                                                child: SizedBox(
                                                                  width: 73.2,
                                                                  child: Container(
                                                                    padding: EdgeInsets.fromLTRB(0, 0, 0.8, 4),
                                                                    child: Stack(
                                                                      clipBehavior: Clip.none,
                                                                      children: [
                                                                        Positioned(
                                                                          bottom: 0,
                                                                          child: Container(
                                                                            width: 73.2,
                                                                            height: 14.3,
                                                                            decoration: BoxDecoration(
                                                                              border: Border(
                                                                                bottom: BorderSize(
                                                                                  color: Color(0xFFAA9D9D),
                                                                                  width: 1,
                                                                                ),
                                                                              ),
                                                                            ),
                                                                          ),
                                                                        ),
                                                                        Text(
                                                                          '256',
                                                                          style: GoogleFonts.getFont(
                                                                            'Fira Sans Condensed',
                                                                            fontWeight: FontWeight.w500,
                                                                            fontSize: 10,
                                                                            color: Color(0xFF3E3636),
                                                                          ),
                                                                        ),
                                                                        Positioned(
                                                                          bottom: 0,
                                                                          child: SizedBox(
                                                                            width: 73.2,
                                                                            height: 16,
                                                                            child: Container(
                                                                              padding: EdgeInsets.fromLTRB(0, 0, 0.8, 4),
                                                                              child: Stack(
                                                                                clipBehavior: Clip.none,
                                                                                children: [
                                                                                  Positioned(
                                                                                    left: 0,
                                                                                    right: 0,
                                                                                    bottom: 0,
                                                                                    child: Container(
                                                                                      width: 73.2,
                                                                                      height: 14.3,
                                                                                      decoration: BoxDecoration(
                                                                                        border: Border(
                                                                                          bottom: BorderSize(
                                                                                            color: Color(0xFFAA9D9D),
                                                                                            width: 1,
                                                                                          ),
                                                                                        ),
                                                                                      ),
                                                                                    ),
                                                                                  ),
                                                                                  Text(
                                                                                    '256',
                                                                                    style: GoogleFonts.getFont(
                                                                                      'Fira Sans Condensed',
                                                                                      fontWeight: FontWeight.w500,
                                                                                      fontSize: 10,
                                                                                      color: Color(0xFF3E3636),
                                                                                    ),
                                                                                  ),
                                                                                ],
                                                                              ),
                                                                            ),
                                                                          ),
                                                                        ),
                                                                      ],
                                                                    ),
                                                                  ),
                                                                ),
                                                              ),
                                                            ],
                                                          ),
                                                          Positioned(
                                                            left: 0,
                                                            top: 0,
                                                            child: Container(
                                                              decoration: BoxDecoration(
                                                                color: Color(0xFF4228D7),
                                                              ),
                                                              child: Container(
                                                                height: 20.3,
                                                                padding: EdgeInsets.fromLTRB(12, 4, 16.3, 4.3),
                                                                child: Text(
                                                                  'nº Reserva',
                                                                  style: GoogleFonts.getFont(
                                                                    'Fira Sans Condensed',
                                                                    fontWeight: FontWeight.w600,
                                                                    fontSize: 10,
                                                                    color: Color(0xFFFFFFFF),
                                                                  ),
                                                                ),
                                                              ),
                                                            ),
                                                          ),
                                                        ],
                                                      ),
                                                    ),
                                                  ),
                                                ),
                                              ),
                                            ],
                                          ),
                                          Positioned(
                                            left: 84.6,
                                            top: 47,
                                            child: ImageFiltered(
                                              imageFilter: ImageFilter.blur(
                                                sigmaX: 2,
                                                sigmaY: 2,
                                              ),
                                              child: SizedBox(
                                                width: 127.7,
                                                height: 87,
                                                child: Container(
                                                  padding: EdgeInsets.fromLTRB(0, 0, 19.5, 0),
                                                  child: Column(
                                                    mainAxisAlignment: MainAxisAlignment.start,
                                                    crossAxisAlignment: CrossAxisAlignment.start,
                                                    children: [
                                                      Container(
                                                        margin: EdgeInsets.fromLTRB(0, 0, 0, 6.7),
                                                        child: Align(
                                                          alignment: Alignment.topLeft,
                                                          child: Container(
                                                            decoration: BoxDecoration(
                                                              color: Color(0xFF4228D7),
                                                            ),
                                                            child: Container(
                                                              padding: EdgeInsets.fromLTRB(19.4, 4, 19.4, 4.3),
                                                              child: Stack(
                                                                clipBehavior: Clip.none,
                                                                children: [
                                                                  Text(
                                                                    'Data de retirada',
                                                                    style: GoogleFonts.getFont(
                                                                      'Fira Sans Condensed',
                                                                      fontWeight: FontWeight.w600,
                                                                      fontSize: 10,
                                                                      color: Color(0xFFFFFFFF),
                                                                    ),
                                                                  ),
                                                                  Positioned(
                                                                    bottom: -4.3,
                                                                    child: Container(
                                                                      decoration: BoxDecoration(
                                                                        color: Color(0xFF4228D7),
                                                                      ),
                                                                      child: Container(
                                                                        width: 106.8,
                                                                        height: 20.3,
                                                                        padding: EdgeInsets.fromLTRB(19.4, 4, 19.4, 4.3),
                                                                        child: Text(
                                                                          'Data de retirada',
                                                                          style: GoogleFonts.getFont(
                                                                            'Fira Sans Condensed',
                                                                            fontWeight: FontWeight.w600,
                                                                            fontSize: 10,
                                                                            color: Color(0xFFFFFFFF),
                                                                          ),
                                                                        ),
                                                                      ),
                                                                    ),
                                                                  ),
                                                                ],
                                                              ),
                                                            ),
                                                          ),
                                                        ),
                                                      ),
                                                      Container(
                                                        margin: EdgeInsets.fromLTRB(0, 0, 0, 7),
                                                        child: Align(
                                                          alignment: Alignment.topLeft,
                                                          child: SizedBox(
                                                            width: 106.8,
                                                            child: Container(
                                                              padding: EdgeInsets.fromLTRB(0, 0, 4.2, 4),
                                                              child: Stack(
                                                                clipBehavior: Clip.none,
                                                                children: [
                                                                  Positioned(
                                                                    bottom: 0,
                                                                    child: Container(
                                                                      width: 106.8,
                                                                      height: 14.3,
                                                                      decoration: BoxDecoration(
                                                                        border: Border(
                                                                          bottom: BorderSize(
                                                                            color: Color(0xFFAA9D9D),
                                                                            width: 1,
                                                                          ),
                                                                        ),
                                                                      ),
                                                                    ),
                                                                  ),
                                                                  Text(
                                                                    '11/12/2022',
                                                                    style: GoogleFonts.getFont(
                                                                      'Fira Sans Condensed',
                                                                      fontWeight: FontWeight.w500,
                                                                      fontSize: 10,
                                                                      color: Color(0xFF3E3636),
                                                                    ),
                                                                  ),
                                                                ],
                                                              ),
                                                            ),
                                                          ),
                                                        ),
                                                      ),
                                                      Container(
                                                        margin: EdgeInsets.fromLTRB(0, 0, 0, 5),
                                                        child: Align(
                                                          alignment: Alignment.topLeft,
                                                          child: SizedBox(
                                                            width: 106.8,
                                                            child: Container(
                                                              padding: EdgeInsets.fromLTRB(0, 0, 4.2, 4),
                                                              child: Stack(
                                                                clipBehavior: Clip.none,
                                                                children: [
                                                                  Positioned(
                                                                    bottom: 0,
                                                                    child: Container(
                                                                      width: 106.8,
                                                                      height: 14.3,
                                                                      decoration: BoxDecoration(
                                                                        border: Border(
                                                                          bottom: BorderSize(
                                                                            color: Color(0xFFAA9D9D),
                                                                            width: 1,
                                                                          ),
                                                                        ),
                                                                      ),
                                                                    ),
                                                                  ),
                                                                  Text(
                                                                    '11/12/2022',
                                                                    style: GoogleFonts.getFont(
                                                                      'Fira Sans Condensed',
                                                                      fontWeight: FontWeight.w500,
                                                                      fontSize: 10,
                                                                      color: Color(0xFF3E3636),
                                                                    ),
                                                                  ),
                                                                ],
                                                              ),
                                                            ),
                                                          ),
                                                        ),
                                                      ),
                                                      Container(
                                                        margin: EdgeInsets.fromLTRB(1.4, 0, 0, 0),
                                                        child: SizedBox(
                                                          width: 106.8,
                                                          child: Container(
                                                            padding: EdgeInsets.fromLTRB(0, 0, 3.2, 4),
                                                            child: Stack(
                                                              clipBehavior: Clip.none,
                                                              children: [
                                                                Positioned(
                                                                  left: 0,
                                                                  right: 0,
                                                                  bottom: 0,
                                                                  child: Container(
                                                                    width: 106.8,
                                                                    height: 14.3,
                                                                    decoration: BoxDecoration(
                                                                      border: Border(
                                                                        bottom: BorderSize(
                                                                          color: Color(0xFFAA9D9D),
                                                                          width: 1,
                                                                        ),
                                                                      ),
                                                                    ),
                                                                  ),
                                                                ),
                                                                Text(
                                                                  '25/12/2022',
                                                                  style: GoogleFonts.getFont(
                                                                    'Fira Sans Condensed',
                                                                    fontWeight: FontWeight.w500,
                                                                    fontSize: 10,
                                                                    color: Color(0xFF3E3636),
                                                                  ),
                                                                ),
                                                                Positioned(
                                                                  left: 0,
                                                                  right: 0,
                                                                  top: 0,
                                                                  bottom: 0,
                                                                  child: SizedBox(
                                                                    width: 106.8,
                                                                    height: 16,
                                                                    child: Container(
                                                                      padding: EdgeInsets.fromLTRB(0, 0, 3.2, 4),
                                                                      child: Stack(
                                                                        clipBehavior: Clip.none,
                                                                        children: [
                                                                          Positioned(
                                                                            left: 0,
                                                                            right: 0,
                                                                            bottom: 0,
                                                                            child: Container(
                                                                              width: 106.8,
                                                                              height: 14.3,
                                                                              decoration: BoxDecoration(
                                                                                border: Border(
                                                                                  bottom: BorderSize(
                                                                                    color: Color(0xFFAA9D9D),
                                                                                    width: 1,
                                                                                  ),
                                                                                ),
                                                                              ),
                                                                            ),
                                                                          ),
                                                                          Text(
                                                                            '25/12/2022',
                                                                            style: GoogleFonts.getFont(
                                                                              'Fira Sans Condensed',
                                                                              fontWeight: FontWeight.w500,
                                                                              fontSize: 10,
                                                                              color: Color(0xFF3E3636),
                                                                            ),
                                                                          ),
                                                                        ],
                                                                      ),
                                                                    ),
                                                                  ),
                                                                ),
                                                              ],
                                                            ),
                                                          ),
                                                        ),
                                                      ),
                                                    ],
                                                  ),
                                                ),
                                              ),
                                            ),
                                          ),
                                          Positioned(
                                            left: 193,
                                            top: 47,
                                            child: ImageFiltered(
                                              imageFilter: ImageFilter.blur(
                                                sigmaX: 2,
                                                sigmaY: 2,
                                              ),
                                              child: SizedBox(
                                                width: 130.4,
                                                height: 87,
                                                child: Container(
                                                  padding: EdgeInsets.fromLTRB(0, 0, 0, 0),
                                                  child: Column(
                                                    mainAxisAlignment: MainAxisAlignment.start,
                                                    crossAxisAlignment: CrossAxisAlignment.start,
                                                    children: [
                                                      Container(
                                                        margin: EdgeInsets.fromLTRB(0, 0, 0, 6.7),
                                                        child: Align(
                                                          alignment: Alignment.topLeft,
                                                          child: Container(
                                                            decoration: BoxDecoration(
                                                              color: Color(0xFF4228D7),
                                                            ),
                                                            child: Container(
                                                              padding: EdgeInsets.fromLTRB(2.9, 2.4, 2.9, 5.9),
                                                              child: Stack(
                                                                clipBehavior: Clip.none,
                                                                children: [
                                                                  Text(
                                                                    'Data de entrega',
                                                                    style: GoogleFonts.getFont(
                                                                      'Fira Sans Condensed',
                                                                      fontWeight: FontWeight.w600,
                                                                      fontSize: 10,
                                                                      color: Color(0xFFFFFFFF),
                                                                    ),
                                                                  ),
                                                                  Positioned(
                                                                    bottom: -5.9,
                                                                    child: Container(
                                                                      decoration: BoxDecoration(
                                                                        color: Color(0xFF4228D7),
                                                                      ),
                                                                      child: Container(
                                                                        width: 106.8,
                                                                        height: 20.3,
                                                                        padding: EdgeInsets.fromLTRB(19.1, 4, 19.1, 4.3),
                                                                        child: Text(
                                                                          'Data de entrega',
                                                                          style: GoogleFonts.getFont(
                                                                            'Fira Sans Condensed',
                                                                            fontWeight: FontWeight.w600,
                                                                            fontSize: 10,
                                                                            color: Color(0xFFFFFFFF),
                                                                          ),
                                                                        ),
                                                                      ),
                                                                    ),
                                                                  ),
                                                                ],
                                                              ),
                                                            ),
                                                          ),
                                                        ),
                                                      ),
                                                      Container(
                                                        margin: EdgeInsets.fromLTRB(0, 0, 0, 7),
                                                        child: Align(
                                                          alignment: Alignment.topLeft,
                                                          child: SizedBox(
                                                            width: 106.8,
                                                            child: Container(
                                                              padding: EdgeInsets.fromLTRB(6.9, 0, 0, 4),
                                                              child: Stack(
                                                                clipBehavior: Clip.none,
                                                                children: [
                                                                  Positioned(
                                                                    bottom: -4,
                                                                    child: Container(
                                                                      width: 106.8,
                                                                      height: 14.3,
                                                                      decoration: BoxDecoration(
                                                                        border: Border(
                                                                          bottom: BorderSize(
                                                                            color: Color(0xFFAA9D9D),
                                                                            width: 1,
                                                                          ),
                                                                        ),
                                                                      ),
                                                                    ),
                                                                  ),
                                                                  Text(
                                                                    '17/12/2022',
                                                                    style: GoogleFonts.getFont(
                                                                      'Fira Sans Condensed',
                                                                      fontWeight: FontWeight.w500,
                                                                      fontSize: 10,
                                                                      color: Color(0xFF3E3636),
                                                                    ),
                                                                  ),
                                                                  Positioned(
                                                                    bottom: -4,
                                                                    child: Container(
                                                                      width: 106.8,
                                                                      height: 14.3,
                                                                      child: Container(
                                                                        width: 106.8,
                                                                        height: 14.3,
                                                                        decoration: BoxDecoration(
                                                                          border: Border(
                                                                            bottom: BorderSize(
                                                                              color: Color(0xFFAA9D9D),
                                                                              width: 1,
                                                                            ),
                                                                          ),
                                                                        ),
                                                                      ),
                                                                    ),
                                                                  ),
                                                                ],
                                                              ),
                                                            ),
                                                          ),
                                                        ),
                                                      ),
                                                      Container(
                                                        margin: EdgeInsets.fromLTRB(0, 0, 0, 5),
                                                        child: Align(
                                                          alignment: Alignment.topLeft,
                                                          child: SizedBox(
                                                            width: 106.8,
                                                            child: Container(
                                                              padding: EdgeInsets.fromLTRB(6.9, 0, 0, 4),
                                                              child: Stack(
                                                                clipBehavior: Clip.none,
                                                                children: [
                                                                  Positioned(
                                                                    bottom: -4,
                                                                    child: Container(
                                                                      width: 106.8,
                                                                      height: 14.3,
                                                                      decoration: BoxDecoration(
                                                                        border: Border(
                                                                          bottom: BorderSize(
                                                                            color: Color(0xFFAA9D9D),
                                                                            width: 1,
                                                                          ),
                                                                        ),
                                                                      ),
                                                                    ),
                                                                  ),
                                                                  Text(
                                                                    '17/12/2022',
                                                                    style: GoogleFonts.getFont(
                                                                      'Fira Sans Condensed',
                                                                      fontWeight: FontWeight.w500,
                                                                      fontSize: 10,
                                                                      color: Color(0xFF3E3636),
                                                                    ),
                                                                  ),
                                                                ],
                                                              ),
                                                            ),
                                                          ),
                                                        ),
                                                      ),
                                                      Container(
                                                        margin: EdgeInsets.fromLTRB(1, 0, 1, 0),
                                                        child: Align(
                                                          alignment: Alignment.topLeft,
                                                          child: SizedBox(
                                                            width: 106.8,
                                                            child: Container(
                                                              padding: EdgeInsets.fromLTRB(9.1, 0, 0, 4),
                                                              child: Stack(
                                                                clipBehavior: Clip.none,
                                                                children: [
                                                                  Positioned(
                                                                    bottom: -4,
                                                                    child: Container(
                                                                      width: 106.8,
                                                                      height: 14.3,
                                                                      decoration: BoxDecoration(
                                                                        border: Border(
                                                                          bottom: BorderSize(
                                                                            color: Color(0xFFAA9D9D),
                                                                            width: 1,
                                                                          ),
                                                                        ),
                                                                      ),
                                                                    ),
                                                                  ),
                                                                  Text(
                                                                    '30/12/2022',
                                                                    style: GoogleFonts.getFont(
                                                                      'Fira Sans Condensed',
                                                                      fontWeight: FontWeight.w500,
                                                                      fontSize: 10,
                                                                      color: Color(0xFF3E3636),
                                                                    ),
                                                                  ),
                                                                  Positioned(
                                                                    bottom: -4,
                                                                    child: SizedBox(
                                                                      width: 106.8,
                                                                      height: 16,
                                                                      child: Container(
                                                                        padding: EdgeInsets.fromLTRB(9.1, 0, 0, 4),
                                                                        child: Stack(
                                                                          clipBehavior: Clip.none,
                                                                          children: [
                                                                            Positioned(
                                                                              left: -9.1,
                                                                              right: 0,
                                                                              bottom: -4,
                                                                              child: Container(
                                                                                width: 106.8,
                                                                                height: 14.3,
                                                                                decoration: BoxDecoration(
                                                                                  border: Border(
                                                                                    bottom: BorderSize(
                                                                                      color: Color(0xFFAA9D9D),
                                                                                      width: 1,
                                                                                    ),
                                                                                  ),
                                                                                ),
                                                                              ),
                                                                            ),
                                                                            Text(
                                                                              '30/12/2022',
                                                                              style: GoogleFonts.getFont(
                                                                                'Fira Sans Condensed',
                                                                                fontWeight: FontWeight.w500,
                                                                                fontSize: 10,
                                                                                color: Color(0xFF3E3636),
                                                                              ),
                                                                            ),
                                                                          ],
                                                                        ),
                                                                      ),
                                                                    ),
                                                                  ),
                                                                ],
                                                              ),
                                                            ),
                                                          ),
                                                        ),
                                                      ),
                                                    ],
                                                  ),
                                                ),
                                              ),
                                            ),
                                          ),
                                          Positioned(
                                            left: 301.3,
                                            top: 47,
                                            child: ImageFiltered(
                                              imageFilter: ImageFilter.blur(
                                                sigmaX: 2,
                                                sigmaY: 2,
                                              ),
                                              child: SizedBox(
                                                width: 182,
                                                height: 87,
                                                child: Container(
                                                  padding: EdgeInsets.fromLTRB(0, 0, 0, 0),
                                                  child: Column(
                                                    mainAxisAlignment: MainAxisAlignment.start,
                                                    crossAxisAlignment: CrossAxisAlignment.start,
                                                    children: [
                                                      Container(
                                                        margin: EdgeInsets.fromLTRB(0, 0, 0, 7.7),
                                                        child: Align(
                                                          alignment: Alignment.topLeft,
                                                          child: Container(
                                                            decoration: BoxDecoration(
                                                              color: Color(0xFF4228D7),
                                                            ),
                                                            child: SizedBox(
                                                              width: 126.5,
                                                              child: Container(
                                                                padding: EdgeInsets.fromLTRB(3.3, 4, 0, 4.3),
                                                                child: Stack(
                                                                  clipBehavior: Clip.none,
                                                                  children: [
                                                                    Text(
                                                                      'Setor',
                                                                      style: GoogleFonts.getFont(
                                                                        'Fira Sans Condensed',
                                                                        fontWeight: FontWeight.w600,
                                                                        fontSize: 10,
                                                                        color: Color(0xFFFFFFFF),
                                                                      ),
                                                                    ),
                                                                    Positioned(
                                                                      bottom: -4.3,
                                                                      child: Container(
                                                                        decoration: BoxDecoration(
                                                                          color: Color(0xFF4228D7),
                                                                        ),
                                                                        child: Container(
                                                                          width: 126.5,
                                                                          height: 20.3,
                                                                          padding: EdgeInsets.fromLTRB(3.3, 4, 0, 4.3),
                                                                          child: Text(
                                                                            'Setor',
                                                                            style: GoogleFonts.getFont(
                                                                              'Fira Sans Condensed',
                                                                              fontWeight: FontWeight.w600,
                                                                              fontSize: 10,
                                                                              color: Color(0xFFFFFFFF),
                                                                            ),
                                                                          ),
                                                                        ),
                                                                      ),
                                                                    ),
                                                                  ],
                                                                ),
                                                              ),
                                                            ),
                                                          ),
                                                        ),
                                                      ),
                                                      Container(
                                                        margin: EdgeInsets.fromLTRB(0, 0, 0, 8),
                                                        child: Align(
                                                          alignment: Alignment.topLeft,
                                                          child: SizedBox(
                                                            width: 126.5,
                                                            child: Container(
                                                              padding: EdgeInsets.fromLTRB(5.3, 0, 0, 3),
                                                              child: Stack(
                                                                clipBehavior: Clip.none,
                                                                children: [
                                                                  Positioned(
                                                                    bottom: -3,
                                                                    child: Container(
                                                                      width: 126.5,
                                                                      height: 14.3,
                                                                      decoration: BoxDecoration(
                                                                        border: Border(
                                                                          bottom: BorderSize(
                                                                            color: Color(0xFFAA9D9D),
                                                                            width: 1,
                                                                          ),
                                                                        ),
                                                                      ),
                                                                    ),
                                                                  ),
                                                                  Text(
                                                                    'Bloco C',
                                                                    style: GoogleFonts.getFont(
                                                                      'Fira Sans Condensed',
                                                                      fontWeight: FontWeight.w500,
                                                                      fontSize: 10,
                                                                      color: Color(0xFF3E3636),
                                                                    ),
                                                                  ),
                                                                ],
                                                              ),
                                                            ),
                                                          ),
                                                        ),
                                                      ),
                                                      Container(
                                                        margin: EdgeInsets.fromLTRB(0, 0, 0, 6),
                                                        child: Align(
                                                          alignment: Alignment.topLeft,
                                                          child: SizedBox(
                                                            width: 126.5,
                                                            child: Container(
                                                              padding: EdgeInsets.fromLTRB(5.3, 0, 0, 3),
                                                              child: Stack(
                                                                clipBehavior: Clip.none,
                                                                children: [
                                                                  Positioned(
                                                                    bottom: -3,
                                                                    child: Container(
                                                                      width: 126.5,
                                                                      height: 14.3,
                                                                      decoration: BoxDecoration(
                                                                        border: Border(
                                                                          bottom: BorderSize(
                                                                            color: Color(0xFFAA9D9D),
                                                                            width: 1,
                                                                          ),
                                                                        ),
                                                                      ),
                                                                    ),
                                                                  ),
                                                                  Text(
                                                                    'Bloco C',
                                                                    style: GoogleFonts.getFont(
                                                                      'Fira Sans Condensed',
                                                                      fontWeight: FontWeight.w500,
                                                                      fontSize: 10,
                                                                      color: Color(0xFF3E3636),
                                                                    ),
                                                                  ),
                                                                ],
                                                              ),
                                                            ),
                                                          ),
                                                        ),
                                                      ),
                                                      Container(
                                                        margin: EdgeInsets.fromLTRB(0.7, 0, 0.7, 0),
                                                        child: Align(
                                                          alignment: Alignment.topLeft,
                                                          child: SizedBox(
                                                            width: 126.5,
                                                            child: Container(
                                                              padding: EdgeInsets.fromLTRB(5.3, 0, 0, 3),
                                                              child: Stack(
                                                                clipBehavior: Clip.none,
                                                                children: [
                                                                  Positioned(
                                                                    bottom: -3,
                                                                    child: Container(
                                                                      width: 126.5,
                                                                      height: 14.3,
                                                                      decoration: BoxDecoration(
                                                                        border: Border(
                                                                          bottom: BorderSize(
                                                                            color: Color(0xFFAA9D9D),
                                                                            width: 1,
                                                                          ),
                                                                        ),
                                                                      ),
                                                                    ),
                                                                  ),
                                                                  Text(
                                                                    'Bloco C',
                                                                    style: GoogleFonts.getFont(
                                                                      'Fira Sans Condensed',
                                                                      fontWeight: FontWeight.w500,
                                                                      fontSize: 10,
                                                                      color: Color(0xFF3E3636),
                                                                    ),
                                                                  ),
                                                                  Positioned(
                                                                    bottom: -3,
                                                                    child: SizedBox(
                                                                      width: 126.5,
                                                                      height: 15,
                                                                      child: Container(
                                                                        padding: EdgeInsets.fromLTRB(5.3, 0, 0, 3),
                                                                        child: Stack(
                                                                          clipBehavior: Clip.none,
                                                                          children: [
                                                                            Positioned(
                                                                              left: -5.3,
                                                                              right: 0,
                                                                              bottom: -3,
                                                                              child: Container(
                                                                                width: 126.5,
                                                                                height: 14.3,
                                                                                decoration: BoxDecoration(
                                                                                  border: Border(
                                                                                    bottom: BorderSize(
                                                                                      color: Color(0xFFAA9D9D),
                                                                                      width: 1,
                                                                                    ),
                                                                                  ),
                                                                                ),
                                                                              ),
                                                                            ),
                                                                            Text(
                                                                              'Bloco C',
                                                                              style: GoogleFonts.getFont(
                                                                                'Fira Sans Condensed',
                                                                                fontWeight: FontWeight.w500,
                                                                                fontSize: 10,
                                                                                color: Color(0xFF3E3636),
                                                                              ),
                                                                            ),
                                                                          ],
                                                                        ),
                                                                      ),
                                                                    ),
                                                                  ),
                                                                ],
                                                              ),
                                                            ),
                                                          ),
                                                        ),
                                                      ),
                                                    ],
                                                  ),
                                                ),
                                              ),
                                            ),
                                          ),
                                          Positioned(
                                            left: 428.6,
                                            top: 47,
                                            child: ImageFiltered(
                                              imageFilter: ImageFilter.blur(
                                                sigmaX: 2,
                                                sigmaY: 2,
                                              ),
                                              child: SizedBox(
                                                width: 196,
                                                height: 87,
                                                child: Container(
                                                  padding: EdgeInsets.fromLTRB(0, 0, 0, 0),
                                                  child: Column(
                                                    mainAxisAlignment: MainAxisAlignment.start,
                                                    crossAxisAlignment: CrossAxisAlignment.start,
                                                    children: [
                                                      Container(
                                                        margin: EdgeInsets.fromLTRB(0, 0, 0, 7.7),
                                                        child: Align(
                                                          alignment: Alignment.topLeft,
                                                          child: Container(
                                                            decoration: BoxDecoration(
                                                              color: Color(0xFF4228D7),
                                                            ),
                                                            child: Container(
                                                              width: 144.6,
                                                              padding: EdgeInsets.fromLTRB(2.3, 4, 0, 4.3),
                                                              child: Text(
                                                                'Requerente',
                                                                style: GoogleFonts.getFont(
                                                                  'Fira Sans Condensed',
                                                                  fontWeight: FontWeight.w600,
                                                                  fontSize: 10,
                                                                  color: Color(0xFFFFFFFF),
                                                                ),
                                                              ),
                                                            ),
                                                          ),
                                                        ),
                                                      ),
                                                      Container(
                                                        margin: EdgeInsets.fromLTRB(0, 0, 0, 8),
                                                        child: Align(
                                                          alignment: Alignment.topLeft,
                                                          child: SizedBox(
                                                            width: 144.6,
                                                            child: Container(
                                                              padding: EdgeInsets.fromLTRB(0, 0, 2.2, 3),
                                                              child: Stack(
                                                                clipBehavior: Clip.none,
                                                                children: [
                                                                  Positioned(
                                                                    bottom: 0,
                                                                    child: Container(
                                                                      width: 144.6,
                                                                      height: 14.3,
                                                                      decoration: BoxDecoration(
                                                                        border: Border(
                                                                          bottom: BorderSize(
                                                                            color: Color(0xFFAA9D9D),
                                                                            width: 1,
                                                                          ),
                                                                        ),
                                                                      ),
                                                                    ),
                                                                  ),
                                                                  Text(
                                                                    'Germano',
                                                                    style: GoogleFonts.getFont(
                                                                      'Fira Sans Condensed',
                                                                      fontWeight: FontWeight.w500,
                                                                      fontSize: 10,
                                                                      color: Color(0xFF3E3636),
                                                                    ),
                                                                  ),
                                                                ],
                                                              ),
                                                            ),
                                                          ),
                                                        ),
                                                      ),
                                                      Container(
                                                        margin: EdgeInsets.fromLTRB(0, 0, 0, 6),
                                                        child: Align(
                                                          alignment: Alignment.topLeft,
                                                          child: SizedBox(
                                                            width: 144.6,
                                                            child: Container(
                                                              padding: EdgeInsets.fromLTRB(0, 0, 2.2, 3),
                                                              child: Stack(
                                                                clipBehavior: Clip.none,
                                                                children: [
                                                                  Positioned(
                                                                    bottom: 0,
                                                                    child: Container(
                                                                      width: 144.6,
                                                                      height: 14.3,
                                                                      decoration: BoxDecoration(
                                                                        border: Border(
                                                                          bottom: BorderSize(
                                                                            color: Color(0xFFAA9D9D),
                                                                            width: 1,
                                                                          ),
                                                                        ),
                                                                      ),
                                                                    ),
                                                                  ),
                                                                  Text(
                                                                    'Germano',
                                                                    style: GoogleFonts.getFont(
                                                                      'Fira Sans Condensed',
                                                                      fontWeight: FontWeight.w500,
                                                                      fontSize: 10,
                                                                      color: Color(0xFF3E3636),
                                                                    ),
                                                                  ),
                                                                ],
                                                              ),
                                                            ),
                                                          ),
                                                        ),
                                                      ),
                                                      Container(
                                                        margin: EdgeInsets.fromLTRB(1.4, 0, 1.4, 0),
                                                        child: Align(
                                                          alignment: Alignment.topLeft,
                                                          child: SizedBox(
                                                            width: 144.6,
                                                            child: Container(
                                                              padding: EdgeInsets.fromLTRB(0, 0, 2.2, 3),
                                                              child: Stack(
                                                                clipBehavior: Clip.none,
                                                                children: [
                                                                  Positioned(
                                                                    bottom: 0,
                                                                    child: Container(
                                                                      width: 144.6,
                                                                      height: 14.3,
                                                                      decoration: BoxDecoration(
                                                                        border: Border(
                                                                          bottom: BorderSize(
                                                                            color: Color(0xFFAA9D9D),
                                                                            width: 1,
                                                                          ),
                                                                        ),
                                                                      ),
                                                                    ),
                                                                  ),
                                                                  Text(
                                                                    'Germano',
                                                                    style: GoogleFonts.getFont(
                                                                      'Fira Sans Condensed',
                                                                      fontWeight: FontWeight.w500,
                                                                      fontSize: 10,
                                                                      color: Color(0xFF3E3636),
                                                                    ),
                                                                  ),
                                                                  Positioned(
                                                                    bottom: 0,
                                                                    child: SizedBox(
                                                                      width: 144.6,
                                                                      height: 15,
                                                                      child: Container(
                                                                        padding: EdgeInsets.fromLTRB(0, 0, 2.2, 3),
                                                                        child: Stack(
                                                                          clipBehavior: Clip.none,
                                                                          children: [
                                                                            Positioned(
                                                                              left: 0,
                                                                              right: 0,
                                                                              bottom: 0,
                                                                              child: Container(
                                                                                width: 144.6,
                                                                                height: 14.3,
                                                                                decoration: BoxDecoration(
                                                                                  border: Border(
                                                                                    bottom: BorderSize(
                                                                                      color: Color(0xFFAA9D9D),
                                                                                      width: 1,
                                                                                    ),
                                                                                  ),
                                                                                ),
                                                                              ),
                                                                            ),
                                                                            Text(
                                                                              'Germano',
                                                                              style: GoogleFonts.getFont(
                                                                                'Fira Sans Condensed',
                                                                                fontWeight: FontWeight.w500,
                                                                                fontSize: 10,
                                                                                color: Color(0xFF3E3636),
                                                                              ),
                                                                            ),
                                                                          ],
                                                                        ),
                                                                      ),
                                                                    ),
                                                                  ),
                                                                ],
                                                              ),
                                                            ),
                                                          ),
                                                        ),
                                                      ),
                                                    ],
                                                  ),
                                                ),
                                              ),
                                            ),
                                          ),
                                          Positioned(
                                            right: 432.4,
                                            top: 47,
                                            child: ImageFiltered(
                                              imageFilter: ImageFilter.blur(
                                                sigmaX: 2,
                                                sigmaY: 2,
                                              ),
                                              child: SizedBox(
                                                width: 189.6,
                                                height: 87,
                                                child: Container(
                                                  padding: EdgeInsets.fromLTRB(0, 0, 0, 0),
                                                  child: Column(
                                                    mainAxisAlignment: MainAxisAlignment.start,
                                                    crossAxisAlignment: CrossAxisAlignment.start,
                                                    children: [
                                                      Container(
                                                        margin: EdgeInsets.fromLTRB(0, 0, 0, 7.7),
                                                        child: Align(
                                                          alignment: Alignment.topLeft,
                                                          child: Container(
                                                            decoration: BoxDecoration(
                                                              color: Color(0xFF4228D7),
                                                            ),
                                                            child: Container(
                                                              width: 144.6,
                                                              padding: EdgeInsets.fromLTRB(0, 4, 4, 4.3),
                                                              child: Text(
                                                                'Equipamento',
                                                                style: GoogleFonts.getFont(
                                                                  'Fira Sans Condensed',
                                                                  fontWeight: FontWeight.w600,
                                                                  fontSize: 10,
                                                                  color: Color(0xFFFFFFFF),
                                                                ),
                                                              ),
                                                            ),
                                                          ),
                                                        ),
                                                      ),
                                                      Container(
                                                        margin: EdgeInsets.fromLTRB(0, 0, 0, 8),
                                                        child: Align(
                                                          alignment: Alignment.topLeft,
                                                          child: SizedBox(
                                                            width: 144.6,
                                                            child: Container(
                                                              padding: EdgeInsets.fromLTRB(0, 0, 3.2, 3),
                                                              child: Stack(
                                                                clipBehavior: Clip.none,
                                                                children: [
                                                                  Positioned(
                                                                    bottom: 0,
                                                                    child: Container(
                                                                      width: 144.6,
                                                                      height: 14.3,
                                                                      decoration: BoxDecoration(
                                                                        border: Border(
                                                                          bottom: BorderSize(
                                                                            color: Color(0xFFAA9D9D),
                                                                            width: 1,
                                                                          ),
                                                                        ),
                                                                      ),
                                                                    ),
                                                                  ),
                                                                  Text(
                                                                    'Microfone',
                                                                    style: GoogleFonts.getFont(
                                                                      'Fira Sans Condensed',
                                                                      fontWeight: FontWeight.w500,
                                                                      fontSize: 10,
                                                                      color: Color(0xFF3E3636),
                                                                    ),
                                                                  ),
                                                                ],
                                                              ),
                                                            ),
                                                          ),
                                                        ),
                                                      ),
                                                      Container(
                                                        margin: EdgeInsets.fromLTRB(0, 0, 0, 6),
                                                        child: Align(
                                                          alignment: Alignment.topLeft,
                                                          child: SizedBox(
                                                            width: 144.6,
                                                            child: Container(
                                                              padding: EdgeInsets.fromLTRB(0, 0, 7, 3),
                                                              child: Stack(
                                                                clipBehavior: Clip.none,
                                                                children: [
                                                                  Positioned(
                                                                    bottom: 0,
                                                                    child: Container(
                                                                      width: 144.6,
                                                                      height: 14.3,
                                                                      decoration: BoxDecoration(
                                                                        border: Border(
                                                                          bottom: BorderSize(
                                                                            color: Color(0xFFAA9D9D),
                                                                            width: 1,
                                                                          ),
                                                                        ),
                                                                      ),
                                                                    ),
                                                                  ),
                                                                  Text(
                                                                    'Cabo P10',
                                                                    style: GoogleFonts.getFont(
                                                                      'Fira Sans Condensed',
                                                                      fontWeight: FontWeight.w500,
                                                                      fontSize: 10,
                                                                      color: Color(0xFF3E3636),
                                                                    ),
                                                                  ),
                                                                ],
                                                              ),
                                                            ),
                                                          ),
                                                        ),
                                                      ),
                                                      Container(
                                                        margin: EdgeInsets.fromLTRB(1, 0, 1, 0),
                                                        child: Align(
                                                          alignment: Alignment.topLeft,
                                                          child: SizedBox(
                                                            width: 144.6,
                                                            child: Container(
                                                              padding: EdgeInsets.fromLTRB(0, 0, 4, 3),
                                                              child: Stack(
                                                                clipBehavior: Clip.none,
                                                                children: [
                                                                  Positioned(
                                                                    bottom: 0,
                                                                    child: Container(
                                                                      width: 144.6,
                                                                      height: 14.3,
                                                                      decoration: BoxDecoration(
                                                                        border: Border(
                                                                          bottom: BorderSize(
                                                                            color: Color(0xFFAA9D9D),
                                                                            width: 1,
                                                                          ),
                                                                        ),
                                                                      ),
                                                                    ),
                                                                  ),
                                                                  Text(
                                                                    'Datashow',
                                                                    style: GoogleFonts.getFont(
                                                                      'Fira Sans Condensed',
                                                                      fontWeight: FontWeight.w500,
                                                                      fontSize: 10,
                                                                      color: Color(0xFF3E3636),
                                                                    ),
                                                                  ),
                                                                  Positioned(
                                                                    bottom: 0,
                                                                    child: SizedBox(
                                                                      width: 144.6,
                                                                      height: 15,
                                                                      child: Container(
                                                                        padding: EdgeInsets.fromLTRB(0, 0, 4, 3),
                                                                        child: Stack(
                                                                          clipBehavior: Clip.none,
                                                                          children: [
                                                                            Positioned(
                                                                              left: 0,
                                                                              right: 0,
                                                                              bottom: 0,
                                                                              child: Container(
                                                                                width: 144.6,
                                                                                height: 14.3,
                                                                                decoration: BoxDecoration(
                                                                                  border: Border(
                                                                                    bottom: BorderSize(
                                                                                      color: Color(0xFFAA9D9D),
                                                                                      width: 1,
                                                                                    ),
                                                                                  ),
                                                                                ),
                                                                              ),
                                                                            ),
                                                                            Text(
                                                                              'Datashow',
                                                                              style: GoogleFonts.getFont(
                                                                                'Fira Sans Condensed',
                                                                                fontWeight: FontWeight.w500,
                                                                                fontSize: 10,
                                                                                color: Color(0xFF3E3636),
                                                                              ),
                                                                            ),
                                                                          ],
                                                                        ),
                                                                      ),
                                                                    ),
                                                                  ),
                                                                ],
                                                              ),
                                                            ),
                                                          ),
                                                        ),
                                                      ),
                                                    ],
                                                  ),
                                                ),
                                              ),
                                            ),
                                          ),
                                          Positioned(
                                            right: 291.4,
                                            top: 47,
                                            child: ImageFiltered(
                                              imageFilter: ImageFilter.blur(
                                                sigmaX: 2,
                                                sigmaY: 2,
                                              ),
                                              child: SizedBox(
                                                width: 184.2,
                                                height: 87.7,
                                                child: Container(
                                                  padding: EdgeInsets.fromLTRB(0, 0, 0, 0.3),
                                                  child: Column(
                                                    mainAxisAlignment: MainAxisAlignment.start,
                                                    crossAxisAlignment: CrossAxisAlignment.start,
                                                    children: [
                                                      Container(
                                                        margin: EdgeInsets.fromLTRB(0, 0, 0, 8.4),
                                                        child: Align(
                                                          alignment: Alignment.topLeft,
                                                          child: Container(
                                                            decoration: BoxDecoration(
                                                              color: Color(0xFF4228D7),
                                                            ),
                                                            child: SizedBox(
                                                              width: 144.6,
                                                              child: Container(
                                                                padding: EdgeInsets.fromLTRB(0, 3.6, 19.3, 4.7),
                                                                child: Stack(
                                                                  clipBehavior: Clip.none,
                                                                  children: [
                                                                    Text(
                                                                      'Nº Patrimônio',
                                                                      style: GoogleFonts.getFont(
                                                                        'Fira Sans Condensed',
                                                                        fontWeight: FontWeight.w600,
                                                                        fontSize: 10,
                                                                        color: Color(0xFFFFFFFF),
                                                                      ),
                                                                    ),
                                                                    Positioned(
                                                                      bottom: 0,
                                                                      child: Container(
                                                                        decoration: BoxDecoration(
                                                                          color: Color(0xFF4228D7),
                                                                        ),
                                                                        child: SizedBox(
                                                                          width: 144.6,
                                                                          height: 20.3,
                                                                          child: Container(
                                                                            padding: EdgeInsets.fromLTRB(0, 4, 10.9, 4.3),
                                                                            child: Stack(
                                                                              clipBehavior: Clip.none,
                                                                              children: [
                                                                                Text(
                                                                                  'Nº Patrimônio',
                                                                                  style: GoogleFonts.getFont(
                                                                                    'Fira Sans Condensed',
                                                                                    fontWeight: FontWeight.w600,
                                                                                    fontSize: 10,
                                                                                    color: Color(0xFFFFFFFF),
                                                                                  ),
                                                                                ),
                                                                                Positioned(
                                                                                  left: 0,
                                                                                  right: 0,
                                                                                  top: 0,
                                                                                  bottom: 0,
                                                                                  child: Container(
                                                                                    decoration: BoxDecoration(
                                                                                      color: Color(0xFF4228D7),
                                                                                    ),
                                                                                    child: Container(
                                                                                      width: 144.6,
                                                                                      height: 20.3,
                                                                                      padding: EdgeInsets.fromLTRB(0, 4, 10.9, 4.3),
                                                                                      child: Text(
                                                                                        'Nº Patrimônio',
                                                                                        style: GoogleFonts.getFont(
                                                                                          'Fira Sans Condensed',
                                                                                          fontWeight: FontWeight.w600,
                                                                                          fontSize: 10,
                                                                                          color: Color(0xFFFFFFFF),
                                                                                        ),
                                                                                      ),
                                                                                    ),
                                                                                  ),
                                                                                ),
                                                                              ],
                                                                            ),
                                                                          ),
                                                                        ),
                                                                      ),
                                                                    ),
                                                                  ],
                                                                ),
                                                              ),
                                                            ),
                                                          ),
                                                        ),
                                                      ),
                                                      Container(
                                                        margin: EdgeInsets.fromLTRB(0, 0, 0, 8.7),
                                                        child: Align(
                                                          alignment: Alignment.topLeft,
                                                          child: Container(
                                                            width: 144.6,
                                                            decoration: BoxDecoration(
                                                              border: Border(
                                                                bottom: BorderSize(
                                                                  color: Color(0xFFAA9D9D),
                                                                  width: 1,
                                                                ),
                                                              ),
                                                            ),
                                                            child: Container(
                                                              padding: EdgeInsets.fromLTRB(0, 0.3, 9.5, 2),
                                                              child: Stack(
                                                                clipBehavior: Clip.none,
                                                                children: [
                                                                  Text(
                                                                    'MIC409',
                                                                    style: GoogleFonts.getFont(
                                                                      'Fira Sans Condensed',
                                                                      fontWeight: FontWeight.w500,
                                                                      fontSize: 10,
                                                                      color: Color(0xFF3E3636),
                                                                    ),
                                                                  ),
                                                                  Positioned(
                                                                    bottom: 0,
                                                                    child: Container(
                                                                      width: 144.6,
                                                                      height: 14.3,
                                                                      child: Container(
                                                                        width: 144.6,
                                                                        height: 14.3,
                                                                        decoration: BoxDecoration(
                                                                          border: Border(
                                                                            bottom: BorderSize(
                                                                              color: Color(0xFFAA9D9D),
                                                                              width: 1,
                                                                            ),
                                                                          ),
                                                                        ),
                                                                      ),
                                                                    ),
                                                                  ),
                                                                ],
                                                              ),
                                                            ),
                                                          ),
                                                        ),
                                                      ),
                                                      Container(
                                                        margin: EdgeInsets.fromLTRB(0, 0, 0, 7),
                                                        child: Align(
                                                          alignment: Alignment.topLeft,
                                                          child: Container(
                                                            width: 144.6,
                                                            padding: EdgeInsets.fromLTRB(0, 0.3, 8.7, 2),
                                                            decoration: BoxDecoration(
                                                              border: Border(
                                                                bottom: BorderSize(
                                                                  color: Color(0xFFAA9D9D),
                                                                  width: 1,
                                                                ),
                                                              ),
                                                            ),
                                                            child: Text(
                                                              'CAB010',
                                                              style: GoogleFonts.getFont(
                                                                'Fira Sans Condensed',
                                                                fontWeight: FontWeight.w500,
                                                                fontSize: 10,
                                                                color: Color(0xFF3E3636),
                                                              ),
                                                            ),
                                                          ),
                                                        ),
                                                      ),
                                                      Container(
                                                        margin: EdgeInsets.fromLTRB(0.6, 0, 0.6, 0),
                                                        child: Align(
                                                          alignment: Alignment.topLeft,
                                                          child: Container(
                                                            width: 144.6,
                                                            decoration: BoxDecoration(
                                                              border: Border(
                                                                bottom: BorderSize(
                                                                  color: Color(0xFFAA9D9D),
                                                                  width: 1,
                                                                ),
                                                              ),
                                                            ),
                                                            child: Container(
                                                              padding: EdgeInsets.fromLTRB(0, 0.3, 9.7, 2),
                                                              child: Stack(
                                                                clipBehavior: Clip.none,
                                                                children: [
                                                                  Text(
                                                                    'Dat500',
                                                                    style: GoogleFonts.getFont(
                                                                      'Fira Sans Condensed',
                                                                      fontWeight: FontWeight.w500,
                                                                      fontSize: 10,
                                                                      color: Color(0xFF3E3636),
                                                                    ),
                                                                  ),
                                                                  Positioned(
                                                                    bottom: 0,
                                                                    child: Container(
                                                                      width: 144.6,
                                                                      height: 14.3,
                                                                      padding: EdgeInsets.fromLTRB(0, 0.3, 9.7, 2),
                                                                      decoration: BoxDecoration(
                                                                        border: Border(
                                                                          bottom: BorderSize(
                                                                            color: Color(0xFFAA9D9D),
                                                                            width: 1,
                                                                          ),
                                                                        ),
                                                                      ),
                                                                      child: Text(
                                                                        'Dat500',
                                                                        style: GoogleFonts.getFont(
                                                                          'Fira Sans Condensed',
                                                                          fontWeight: FontWeight.w500,
                                                                          fontSize: 10,
                                                                          color: Color(0xFF3E3636),
                                                                        ),
                                                                      ),
                                                                    ),
                                                                  ),
                                                                ],
                                                              ),
                                                            ),
                                                          ),
                                                        ),
                                                      ),
                                                    ],
                                                  ),
                                                ),
                                              ),
                                            ),
                                          ),
                                          Positioned(
                                            right: 130.4,
                                            top: 47,
                                            child: ImageFiltered(
                                              imageFilter: ImageFilter.blur(
                                                sigmaX: 2,
                                                sigmaY: 2,
                                              ),
                                              child: SizedBox(
                                                width: 198.9,
                                                height: 87,
                                                child: Container(
                                                  padding: EdgeInsets.fromLTRB(0, 0, 0, 0),
                                                  child: Column(
                                                    mainAxisAlignment: MainAxisAlignment.start,
                                                    crossAxisAlignment: CrossAxisAlignment.start,
                                                    children: [
                                                      Container(
                                                        margin: EdgeInsets.fromLTRB(0, 0, 0, 6.7),
                                                        child: Align(
                                                          alignment: Alignment.topLeft,
                                                          child: Container(
                                                            decoration: BoxDecoration(
                                                              color: Color(0xFF4228D7),
                                                            ),
                                                            child: SizedBox(
                                                              width: 144.6,
                                                              child: Container(
                                                                padding: EdgeInsets.fromLTRB(0, 3.6, 19.3, 4.7),
                                                                child: Stack(
                                                                  clipBehavior: Clip.none,
                                                                  children: [
                                                                    Text(
                                                                      'Nº Patrimônio',
                                                                      style: GoogleFonts.getFont(
                                                                        'Fira Sans Condensed',
                                                                        fontWeight: FontWeight.w600,
                                                                        fontSize: 10,
                                                                        color: Color(0xFFFFFFFF),
                                                                      ),
                                                                    ),
                                                                    Positioned(
                                                                      bottom: 0,
                                                                      child: Container(
                                                                        decoration: BoxDecoration(
                                                                          color: Color(0xFF4228D7),
                                                                        ),
                                                                        child: SizedBox(
                                                                          width: 144.6,
                                                                          height: 20.3,
                                                                          child: Container(
                                                                            padding: EdgeInsets.fromLTRB(12.2, 4, 0, 4.3),
                                                                            child: Stack(
                                                                              clipBehavior: Clip.none,
                                                                              children: [
                                                                                Text(
                                                                                  'Responsavel',
                                                                                  style: GoogleFonts.getFont(
                                                                                    'Fira Sans Condensed',
                                                                                    fontWeight: FontWeight.w600,
                                                                                    fontSize: 10,
                                                                                    color: Color(0xFFFFFFFF),
                                                                                  ),
                                                                                ),
                                                                                Positioned(
                                                                                  left: -12.2,
                                                                                  right: 0,
                                                                                  top: -4,
                                                                                  bottom: -4.3,
                                                                                  child: Container(
                                                                                    decoration: BoxDecoration(
                                                                                      color: Color(0xFF4228D7),
                                                                                    ),
                                                                                    child: Container(
                                                                                      width: 144.6,
                                                                                      height: 20.3,
                                                                                      padding: EdgeInsets.fromLTRB(12.2, 4, 0, 4.3),
                                                                                      child: Text(
                                                                                        'Responsavel',
                                                                                        style: GoogleFonts.getFont(
                                                                                          'Fira Sans Condensed',
                                                                                          fontWeight: FontWeight.w600,
                                                                                          fontSize: 10,
                                                                                          color: Color(0xFFFFFFFF),
                                                                                        ),
                                                                                      ),
                                                                                    ),
                                                                                  ),
                                                                                ),
                                                                              ],
                                                                            ),
                                                                          ),
                                                                        ),
                                                                      ),
                                                                    ),
                                                                  ],
                                                                ),
                                                              ),
                                                            ),
                                                          ),
                                                        ),
                                                      ),
                                                      Container(
                                                        margin: EdgeInsets.fromLTRB(0, 0, 0, 7),
                                                        child: Align(
                                                          alignment: Alignment.topLeft,
                                                          child: SizedBox(
                                                            width: 144.6,
                                                            child: Container(
                                                              padding: EdgeInsets.fromLTRB(17.3, 0, 0, 4),
                                                              child: Stack(
                                                                clipBehavior: Clip.none,
                                                                children: [
                                                                  Positioned(
                                                                    bottom: -4,
                                                                    child: Container(
                                                                      width: 144.6,
                                                                      height: 14.3,
                                                                      decoration: BoxDecoration(
                                                                        border: Border(
                                                                          bottom: BorderSize(
                                                                            color: Color(0xFFAA9D9D),
                                                                            width: 1,
                                                                          ),
                                                                        ),
                                                                      ),
                                                                    ),
                                                                  ),
                                                                  Text(
                                                                    'Waltair',
                                                                    style: GoogleFonts.getFont(
                                                                      'Fira Sans Condensed',
                                                                      fontWeight: FontWeight.w500,
                                                                      fontSize: 10,
                                                                      color: Color(0xFF3E3636),
                                                                    ),
                                                                  ),
                                                                  Positioned(
                                                                    bottom: -4,
                                                                    child: Container(
                                                                      width: 144.6,
                                                                      height: 14.3,
                                                                      child: Container(
                                                                        width: 144.6,
                                                                        height: 14.3,
                                                                        decoration: BoxDecoration(
                                                                          border: Border(
                                                                            bottom: BorderSize(
                                                                              color: Color(0xFFAA9D9D),
                                                                              width: 1,
                                                                            ),
                                                                          ),
                                                                        ),
                                                                      ),
                                                                    ),
                                                                  ),
                                                                ],
                                                              ),
                                                            ),
                                                          ),
                                                        ),
                                                      ),
                                                      Container(
                                                        margin: EdgeInsets.fromLTRB(0, 0, 0, 5),
                                                        child: Align(
                                                          alignment: Alignment.topLeft,
                                                          child: SizedBox(
                                                            width: 144.6,
                                                            child: Container(
                                                              padding: EdgeInsets.fromLTRB(17.3, 0, 0, 4),
                                                              child: Stack(
                                                                clipBehavior: Clip.none,
                                                                children: [
                                                                  Positioned(
                                                                    bottom: -4,
                                                                    child: Container(
                                                                      width: 144.6,
                                                                      height: 14.3,
                                                                      decoration: BoxDecoration(
                                                                        border: Border(
                                                                          bottom: BorderSize(
                                                                            color: Color(0xFFAA9D9D),
                                                                            width: 1,
                                                                          ),
                                                                        ),
                                                                      ),
                                                                    ),
                                                                  ),
                                                                  Text(
                                                                    'Waltair',
                                                                    style: GoogleFonts.getFont(
                                                                      'Fira Sans Condensed',
                                                                      fontWeight: FontWeight.w500,
                                                                      fontSize: 10,
                                                                      color: Color(0xFF3E3636),
                                                                    ),
                                                                  ),
                                                                ],
                                                              ),
                                                            ),
                                                          ),
                                                        ),
                                                      ),
                                                      Container(
                                                        margin: EdgeInsets.fromLTRB(1.3, 0, 1.3, 0),
                                                        child: Align(
                                                          alignment: Alignment.topLeft,
                                                          child: SizedBox(
                                                            width: 144.6,
                                                            child: Container(
                                                              padding: EdgeInsets.fromLTRB(17.3, 0, 0, 4),
                                                              child: Stack(
                                                                clipBehavior: Clip.none,
                                                                children: [
                                                                  Positioned(
                                                                    bottom: -4,
                                                                    child: Container(
                                                                      width: 144.6,
                                                                      height: 14.3,
                                                                      decoration: BoxDecoration(
                                                                        border: Border(
                                                                          bottom: BorderSize(
                                                                            color: Color(0xFFAA9D9D),
                                                                            width: 1,
                                                                          ),
                                                                        ),
                                                                      ),
                                                                    ),
                                                                  ),
                                                                  Text(
                                                                    'Waltair',
                                                                    style: GoogleFonts.getFont(
                                                                      'Fira Sans Condensed',
                                                                      fontWeight: FontWeight.w500,
                                                                      fontSize: 10,
                                                                      color: Color(0xFF3E3636),
                                                                    ),
                                                                  ),
                                                                  Positioned(
                                                                    bottom: -4,
                                                                    child: SizedBox(
                                                                      width: 144.6,
                                                                      height: 16,
                                                                      child: Container(
                                                                        padding: EdgeInsets.fromLTRB(17.3, 0, 0, 4),
                                                                        child: Stack(
                                                                          clipBehavior: Clip.none,
                                                                          children: [
                                                                            Positioned(
                                                                              left: -17.3,
                                                                              right: 0,
                                                                              bottom: -4,
                                                                              child: Container(
                                                                                width: 144.6,
                                                                                height: 14.3,
                                                                                decoration: BoxDecoration(
                                                                                  border: Border(
                                                                                    bottom: BorderSize(
                                                                                      color: Color(0xFFAA9D9D),
                                                                                      width: 1,
                                                                                    ),
                                                                                  ),
                                                                                ),
                                                                              ),
                                                                            ),
                                                                            Text(
                                                                              'Waltair',
                                                                              style: GoogleFonts.getFont(
                                                                                'Fira Sans Condensed',
                                                                                fontWeight: FontWeight.w500,
                                                                                fontSize: 10,
                                                                                color: Color(0xFF3E3636),
                                                                              ),
                                                                            ),
                                                                          ],
                                                                        ),
                                                                      ),
                                                                    ),
                                                                  ),
                                                                ],
                                                              ),
                                                            ),
                                                          ),
                                                        ),
                                                      ),
                                                    ],
                                                  ),
                                                ),
                                              ),
                                            ),
                                          ),
                                          Positioned(
                                            right: 24.8,
                                            top: 47,
                                            child: ImageFiltered(
                                              imageFilter: ImageFilter.blur(
                                                sigmaX: 2,
                                                sigmaY: 2,
                                              ),
                                              child: SizedBox(
                                                width: 158.2,
                                                height: 87,
                                                child: Container(
                                                  padding: EdgeInsets.fromLTRB(0, 0, 0, 0),
                                                  child: Column(
                                                    mainAxisAlignment: MainAxisAlignment.start,
                                                    crossAxisAlignment: CrossAxisAlignment.start,
                                                    children: [
                                                      Container(
                                                        margin: EdgeInsets.fromLTRB(0.1, 0, 0.1, 6.7),
                                                        child: Align(
                                                          alignment: Alignment.topLeft,
                                                          child: Container(
                                                            decoration: BoxDecoration(
                                                              color: Color(0xFF4228D7),
                                                            ),
                                                            child: SizedBox(
                                                              width: 114.6,
                                                              child: Container(
                                                                padding: EdgeInsets.fromLTRB(5.1, 4, 0, 4.3),
                                                                child: Stack(
                                                                  clipBehavior: Clip.none,
                                                                  children: [
                                                                    Text(
                                                                      'Situação',
                                                                      style: GoogleFonts.getFont(
                                                                        'Fira Sans Condensed',
                                                                        fontWeight: FontWeight.w600,
                                                                        fontSize: 10,
                                                                        color: Color(0xFFFFFFFF),
                                                                      ),
                                                                    ),
                                                                    Positioned(
                                                                      bottom: -4.3,
                                                                      child: Container(
                                                                        decoration: BoxDecoration(
                                                                          color: Color(0xFF4228D7),
                                                                        ),
                                                                        child: Container(
                                                                          width: 114.6,
                                                                          height: 20.3,
                                                                          padding: EdgeInsets.fromLTRB(5.1, 4, 0, 4.3),
                                                                          child: Text(
                                                                            'Situação',
                                                                            style: GoogleFonts.getFont(
                                                                              'Fira Sans Condensed',
                                                                              fontWeight: FontWeight.w600,
                                                                              fontSize: 10,
                                                                              color: Color(0xFFFFFFFF),
                                                                            ),
                                                                          ),
                                                                        ),
                                                                      ),
                                                                    ),
                                                                  ],
                                                                ),
                                                              ),
                                                            ),
                                                          ),
                                                        ),
                                                      ),
                                                      Container(
                                                        margin: EdgeInsets.fromLTRB(0.1, 0, 0.1, 7),
                                                        child: Align(
                                                          alignment: Alignment.topLeft,
                                                          child: SizedBox(
                                                            width: 114.6,
                                                            child: Container(
                                                              padding: EdgeInsets.fromLTRB(8.7, 0, 0, 4),
                                                              child: Stack(
                                                                clipBehavior: Clip.none,
                                                                children: [
                                                                  Positioned(
                                                                    bottom: -4,
                                                                    child: Container(
                                                                      width: 114.6,
                                                                      height: 14.3,
                                                                      decoration: BoxDecoration(
                                                                        border: Border(
                                                                          bottom: BorderSize(
                                                                            color: Color(0xFFAA9D9D),
                                                                            width: 1,
                                                                          ),
                                                                        ),
                                                                      ),
                                                                    ),
                                                                  ),
                                                                  Text(
                                                                    'Reservado',
                                                                    style: GoogleFonts.getFont(
                                                                      'Fira Sans Condensed',
                                                                      fontWeight: FontWeight.w500,
                                                                      fontSize: 10,
                                                                      color: Color(0xFF3E3636),
                                                                    ),
                                                                  ),
                                                                ],
                                                              ),
                                                            ),
                                                          ),
                                                        ),
                                                      ),
                                                      Container(
                                                        margin: EdgeInsets.fromLTRB(0, 0, 0, 5),
                                                        child: Align(
                                                          alignment: Alignment.topLeft,
                                                          child: SizedBox(
                                                            width: 114.6,
                                                            child: Container(
                                                              padding: EdgeInsets.fromLTRB(8.7, 0, 0, 4),
                                                              child: Stack(
                                                                clipBehavior: Clip.none,
                                                                children: [
                                                                  Positioned(
                                                                    bottom: -4,
                                                                    child: Container(
                                                                      width: 114.6,
                                                                      height: 14.3,
                                                                      decoration: BoxDecoration(
                                                                        border: Border(
                                                                          bottom: BorderSize(
                                                                            color: Color(0xFFAA9D9D),
                                                                            width: 1,
                                                                          ),
                                                                        ),
                                                                      ),
                                                                    ),
                                                                  ),
                                                                  Text(
                                                                    'Reservado',
                                                                    style: GoogleFonts.getFont(
                                                                      'Fira Sans Condensed',
                                                                      fontWeight: FontWeight.w500,
                                                                      fontSize: 10,
                                                                      color: Color(0xFF3E3636),
                                                                    ),
                                                                  ),
                                                                ],
                                                              ),
                                                            ),
                                                          ),
                                                        ),
                                                      ),
                                                      Container(
                                                        margin: EdgeInsets.fromLTRB(1, 0, 1, 0),
                                                        child: Align(
                                                          alignment: Alignment.topLeft,
                                                          child: SizedBox(
                                                            width: 114.6,
                                                            child: Container(
                                                              padding: EdgeInsets.fromLTRB(8.7, 0, 0, 4),
                                                              child: Stack(
                                                                clipBehavior: Clip.none,
                                                                children: [
                                                                  Positioned(
                                                                    bottom: -4,
                                                                    child: Container(
                                                                      width: 114.6,
                                                                      height: 14.3,
                                                                      decoration: BoxDecoration(
                                                                        border: Border(
                                                                          bottom: BorderSize(
                                                                            color: Color(0xFFAA9D9D),
                                                                            width: 1,
                                                                          ),
                                                                        ),
                                                                      ),
                                                                    ),
                                                                  ),
                                                                  Text(
                                                                    'Reservado',
                                                                    style: GoogleFonts.getFont(
                                                                      'Fira Sans Condensed',
                                                                      fontWeight: FontWeight.w500,
                                                                      fontSize: 10,
                                                                      color: Color(0xFF3E3636),
                                                                    ),
                                                                  ),
                                                                  Positioned(
                                                                    bottom: -4,
                                                                    child: SizedBox(
                                                                      width: 114.6,
                                                                      height: 16,
                                                                      child: Container(
                                                                        padding: EdgeInsets.fromLTRB(8.7, 0, 0, 4),
                                                                        child: Stack(
                                                                          clipBehavior: Clip.none,
                                                                          children: [
                                                                            Positioned(
                                                                              left: -8.7,
                                                                              right: 0,
                                                                              bottom: -4,
                                                                              child: Container(
                                                                                width: 114.6,
                                                                                height: 14.3,
                                                                                decoration: BoxDecoration(
                                                                                  border: Border(
                                                                                    bottom: BorderSize(
                                                                                      color: Color(0xFFAA9D9D),
                                                                                      width: 1,
                                                                                    ),
                                                                                  ),
                                                                                ),
                                                                              ),
                                                                            ),
                                                                            Text(
                                                                              'Reservado',
                                                                              style: GoogleFonts.getFont(
                                                                                'Fira Sans Condensed',
                                                                                fontWeight: FontWeight.w500,
                                                                                fontSize: 10,
                                                                                color: Color(0xFF3E3636),
                                                                              ),
                                                                            ),
                                                                          ],
                                                                        ),
                                                                      ),
                                                                    ),
                                                                  ),
                                                                ],
                                                              ),
                                                            ),
                                                          ),
                                                        ),
                                                      ),
                                                    ],
                                                  ),
                                                ),
                                              ),
                                            ),
                                          ),
                                          Positioned(
                                            right: 44,
                                            top: 65,
                                            child: ImageFiltered(
                                              imageFilter: ImageFilter.blur(
                                                sigmaX: 2,
                                                sigmaY: 2,
                                              ),
                                              child: Container(
                                                width: 24,
                                                height: 24,
                                                padding: EdgeInsets.fromLTRB(2.3, 2, 2.3, 2),
                                                child: SizedBox(
                                                  width: 19.5,
                                                  height: 20,
                                                  child: SvgPicture.asset(
                                                    'assets/vectors/vector_377_x2.svg',
                                                  ),
                                                ),
                                              ),
                                            ),
                                          ),
                                          Positioned(
                                            right: 46.5,
                                            top: 91,
                                            child: ImageFiltered(
                                              imageFilter: ImageFilter.blur(
                                                sigmaX: 2,
                                                sigmaY: 2,
                                              ),
                                              child: SizedBox(
                                                width: 19.5,
                                                height: 20,
                                                child: SvgPicture.asset(
                                                  'assets/vectors/vector_417_x2.svg',
                                                ),
                                              ),
                                            ),
                                          ),
                                          Positioned(
                                            right: 46.5,
                                            top: 114,
                                            child: ImageFiltered(
                                              imageFilter: ImageFilter.blur(
                                                sigmaX: 2,
                                                sigmaY: 2,
                                              ),
                                              child: SizedBox(
                                                width: 19.5,
                                                height: 20,
                                                child: SvgPicture.asset(
                                                  'assets/vectors/vector_251_x2.svg',
                                                ),
                                              ),
                                            ),
                                          ),
                                        ],
                                      ),
                                    ),
                                  ),
                                ),
                              ),
                            ],
                          ),
                          Positioned(
                            left: 312,
                            top: 223,
                            child: Container(
                              height: 332,
                              child: ClipRect(
                                child: BackdropFilter(
                                  filter: ImageFilter.blur(
                                    sigmaX: 2,
                                    sigmaY: 2,
                                  ),
                                  child: Container(
                                    decoration: BoxDecoration(
                                      borderRadius: BorderRadius.circular(10),
                                      boxShadow: [
                                        BoxShadow(
                                          color: Color(0x40000000),
                                          offset: Offset(0, 4),
                                          blurRadius: 2,
                                        ),
                                      ],
                                    ),
                                    child: Stack(
                                      children: [
                                    Positioned(
                                      left: -38,
                                      top: -1,
                                      child: SizedBox(
                                        width: 591.7,
                                        height: 36,
                                        child: SvgPicture.asset(
                                          'assets/vectors/group_814_x2.svg',
                                        ),
                                      ),
                                    ),
                              Container(
                                          padding: EdgeInsets.fromLTRB(38, 1, 33.4, 39),
                                          child: Column(
                                            mainAxisAlignment: MainAxisAlignment.start,
                                            crossAxisAlignment: CrossAxisAlignment.center,
                                            children: [
                                              Container(
                                                margin: EdgeInsets.fromLTRB(0, 0, 0, 9.8),
                                                child: Row(
                                                  mainAxisAlignment: MainAxisAlignment.start,
                                                  crossAxisAlignment: CrossAxisAlignment.start,
                                                  children: [
                                                    Container(
                                                      margin: EdgeInsets.fromLTRB(0, 4.2, 9, 5),
                                                      child: Text(
                                                        'ESCANEIE O Qr CODE PARA ASSINAR A RETIRADA',
                                                        style: GoogleFonts.getFont(
                                                          'Inter',
                                                          fontWeight: FontWeight.w600,
                                                          fontSize: 20,
                                                          color: Color(0xFFFFFFFF),
                                                        ),
                                                      ),
                                                    ),
                                                    Container(
                                                      decoration: BoxDecoration(
                                                        color: Color(0xFF22127B),
                                                      ),
                                                      child: Container(
                                                        padding: EdgeInsets.fromLTRB(6.4, 2.4, 7.3, 6.8),
                                                        child: Text(
                                                          'X',
                                                          style: GoogleFonts.getFont(
                                                            'Inter',
                                                            fontWeight: FontWeight.w400,
                                                            fontSize: 20,
                                                            color: Color(0xFFFFFFFF),
                                                          ),
                                                        ),
                                                      ),
                                                    ),
                                                  ],
                                                ),
                                              ),
                                              Container(
                                                margin: EdgeInsets.fromLTRB(0, 0, 10.6, 0),
                                                child: Container(
                                                  decoration: BoxDecoration(
                                                    image: DecorationImage(
                                                      fit: BoxFit.cover,
                                                      image: AssetImage(
                                                        'assets/images/image_4.png',
                                                      ),
                                                    ),
                                                  ),
                                                  child: Container(
                                                    width: 252,
                                                    height: 249,
                                                    padding: EdgeInsets.fromLTRB(0, 34, 12, 34),
                                                    child: Container(
                                                      decoration: BoxDecoration(
                                                        image: DecorationImage(
                                                          fit: BoxFit.cover,
                                                          image: AssetImage(
                                                            'assets/images/image_5.png',
                                                          ),
                                                        ),
                                                      ),
                                                      child: Container(
                                                        width: 174,
                                                        height: 181,
                                                      ),
                                                    ),
                                                  ),
                                                ),
                                              ),
                                            ],
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                ),
                              ),
                            ),
                          ),
                        ],
                      ),
                    ],
                  ),
                ],
              ),
              Positioned(
                left: -89,
                bottom: -21,
                child: Container(
                  decoration: BoxDecoration(
                    color: Color(0xFF212176),
                    borderRadius: BorderRadius.only(
                      bottomRight: Radius.circular(100),
                    ),
                  ),
                  child: SizedBox(
                    width: 278,
                    height: 959,
                    child: Container(
                      padding: EdgeInsets.fromLTRB(9.2, 15.8, 9.2, 0),
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.start,
                        crossAxisAlignment: CrossAxisAlignment.center,
                        children: [
                          Container(
                            margin: EdgeInsets.fromLTRB(0, 0, 0, 16.9),
                            child: Align(
                              alignment: Alignment.topLeft,
                              child: Row(
                                mainAxisAlignment: MainAxisAlignment.start,
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Container(
                                    margin: EdgeInsets.fromLTRB(0, 0, 43.5, 0),
                                    child: SizedBox(
                                      width: 47.3,
                                      height: 65.3,
                                      child: SvgPicture.asset(
                                        'assets/vectors/hamburger_6_x2.svg',
                                      ),
                                    ),
                                  ),
                                  Container(
                                    margin: EdgeInsets.fromLTRB(0, 32.2, 0, 13.1),
                                    child: Row(
                                      mainAxisAlignment: MainAxisAlignment.start,
                                      crossAxisAlignment: CrossAxisAlignment.start,
                                      children: [
                                        Container(
                                          margin: EdgeInsets.fromLTRB(0, 3, 8, 1),
                                          child: SizedBox(
                                            width: 17,
                                            height: 16,
                                            child: SvgPicture.asset(
                                              'assets/vectors/vector_82_x2.svg',
                                            ),
                                          ),
                                        ),
                                        Text(
                                          'Audio visual',
                                          style: GoogleFonts.getFont(
                                            'Fira Sans Condensed',
                                            fontWeight: FontWeight.w600,
                                            fontSize: 17,
                                            color: Color(0xFFFFFFFF),
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ),
                          Container(
                            margin: EdgeInsets.fromLTRB(35.8, 0, 0, 34),
                            child: Row(
                              mainAxisAlignment: MainAxisAlignment.start,
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Container(
                                  margin: EdgeInsets.fromLTRB(0, 2.5, 4.5, 2.5),
                                  child: SizedBox(
                                    width: 16.5,
                                    height: 15,
                                    child: SvgPicture.asset(
                                      'assets/vectors/vector_283_x2.svg',
                                    ),
                                  ),
                                ),
                                Text(
                                  'Equipamento',
                                  style: GoogleFonts.getFont(
                                    'Fira Sans Condensed',
                                    fontWeight: FontWeight.w600,
                                    fontSize: 17,
                                    color: Color(0xFFFFFFFF),
                                  ),
                                ),
                              ],
                            ),
                          ),
                          Container(
                            margin: EdgeInsets.fromLTRB(8.6, 0, 0, 31),
                            child: Row(
                              mainAxisAlignment: MainAxisAlignment.start,
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Container(
                                  margin: EdgeInsets.fromLTRB(0, 1, 10, 3),
                                  child: SizedBox(
                                    width: 15,
                                    height: 16,
                                    child: SvgPicture.asset(
                                      'assets/vectors/container_59_x2.svg',
                                    ),
                                  ),
                                ),
                                Text(
                                  'Usuários',
                                  style: GoogleFonts.getFont(
                                    'Fira Sans Condensed',
                                    fontWeight: FontWeight.w600,
                                    fontSize: 17,
                                    color: Color(0xFFFFFFFF),
                                  ),
                                ),
                              ],
                            ),
                          ),
                          Container(
                            margin: EdgeInsets.fromLTRB(27.6, 0, 0, 33),
                            child: Row(
                              mainAxisAlignment: MainAxisAlignment.start,
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Container(
                                  margin: EdgeInsets.fromLTRB(0, 1, 10, 3),
                                  child: SizedBox(
                                    width: 15,
                                    height: 16,
                                    child: SvgPicture.asset(
                                      'assets/vectors/container_38_x2.svg',
                                    ),
                                  ),
                                ),
                                Text(
                                  'Relatorios
                                ',
                                  style: GoogleFonts.getFont(
                                    'Fira Sans Condensed',
                                    fontWeight: FontWeight.w600,
                                    fontSize: 17,
                                    color: Color(0xFFFFFFFF),
                                  ),
                                ),
                              ],
                            ),
                          ),
                          Container(
                            margin: EdgeInsets.fromLTRB(7.2, 0, 0, 0),
                            child: Row(
                              mainAxisAlignment: MainAxisAlignment.start,
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Container(
                                  margin: EdgeInsets.fromLTRB(0, 5, 8, 0),
                                  child: SizedBox(
                                    width: 18,
                                    height: 16,
                                    child: SvgPicture.asset(
                                      'assets/vectors/vector_376_x2.svg',
                                    ),
                                  ),
                                ),
                                Container(
                                  margin: EdgeInsets.fromLTRB(0, 0, 0, 1),
                                  child: Text(
                                    'Reservas',
                                    style: GoogleFonts.getFont(
                                      'Fira Sans Condensed',
                                      fontWeight: FontWeight.w600,
                                      fontSize: 17,
                                      color: Color(0xFFFFFFFF),
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ),
              ),
              Positioned(
                right: -39,
                top: -34,
                child: Container(
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(5),
                    color: Color(0xFF000041),
                    boxShadow: [
                      BoxShadow(
                        color: Color(0x40000000),
                        offset: Offset(0, 4),
                        blurRadius: 2,
                      ),
                    ],
                  ),
                  child: SizedBox(
                    width: 1479,
                    height: 82,
                    child: Container(
                      padding: EdgeInsets.fromLTRB(0, 4, 74, 6),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Container(
                            decoration: BoxDecoration(
                              image: DecorationImage(
                                fit: BoxFit.cover,
                                image: AssetImage(
                                  'assets/images/image_2.png',
                                ),
                              ),
                            ),
                            child: Container(
                              width: 189,
                              height: 72,
                            ),
                          ),
                          Container(
                            margin: EdgeInsets.fromLTRB(0, 6, 0, 9),
                            child: Row(
                              mainAxisAlignment: MainAxisAlignment.start,
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Container(
                                  margin: EdgeInsets.fromLTRB(0, 0, 17, 0),
                                  child: SizedBox(
                                    width: 59,
                                    height: 57,
                                    child: SvgPicture.asset(
                                      'assets/vectors/group_185_x2.svg',
                                    ),
                                  ),
                                ),
                                Container(
                                  margin: EdgeInsets.fromLTRB(0, 19, 0, 19),
                                  child: Text(
                                    'Logado: Waltair',
                                    style: GoogleFonts.getFont(
                                      'Fira Sans Condensed',
                                      fontWeight: FontWeight.w600,
                                      fontSize: 16,
                                      color: Color(0xFFFFFFFF),
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ),
                          Container(
                            margin: EdgeInsets.fromLTRB(0, 14, 0, 16),
                            child: Row(
                              mainAxisAlignment: MainAxisAlignment.start,
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Container(
                                  margin: EdgeInsets.fromLTRB(0, 0, 31, 0),
                                  child: Container(
                                    padding: EdgeInsets.fromLTRB(17, 11, 17, 12),
                                    child: Stack(
                                      clipBehavior: Clip.none,
                                      children: [
                                        Text(
                                          'Encerrar sessão',
                                          style: GoogleFonts.getFont(
                                            'Fira Sans Condensed',
                                            fontWeight: FontWeight.w600,
                                            fontSize: 16,
                                            color: Color(0xFFFFFFFF),
                                          ),
                                        ),
                                        Positioned(
                                          bottom: -12,
                                          child: Container(
                                            width: 138,
                                            height: 42,
                                            decoration: BoxDecoration(
                                              border: Border.all(color: Color(0xFFFFFFFF)),
                                              borderRadius: BorderRadius.circular(19),
                                            ),
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                ),
                                Container(
                                  decoration: BoxDecoration(
                                    color: Color(0xFF202075),
                                  ),
                                  child: SizedBox(
                                    width: 53,
                                    child: Container(
                                      padding: EdgeInsets.fromLTRB(2.7, 12.9, 7.7, 12.6),
                                      child: Stack(
                                        clipBehavior: Clip.none,
                                        children: [
                                          SizedBox(
                                            width: 42.6,
                                            child: Column(
                                              mainAxisAlignment: MainAxisAlignment.start,
                                              crossAxisAlignment: CrossAxisAlignment.center,
                                              children: [
                                                Container(
                                                  margin: EdgeInsets.fromLTRB(7.4, 0, 2.7, 4),
                                                  child: ClipRRect(
                                                    borderRadius: BorderRadius.circular(40),
                                                    child: SizedBox(
                                                      width: 32.5,
                                                      height: 2.8,
                                                      child: SvgPicture.asset(
                                                        'assets/vectors/rectangle_210_x2.svg',
                                                      ),
                                                    ),
                                                  ),
                                                ),
                                                Container(
                                                  margin: EdgeInsets.fromLTRB(7.4, 0, 2.7, 4),
                                                  child: ClipRRect(
                                                    borderRadius: BorderRadius.circular(40),
                                                    child: SizedBox(
                                                      width: 32.5,
                                                      height: 2.8,
                                                      child: SvgPicture.asset(
                                                        'assets/vectors/rectangle_324_x2.svg',
                                                      ),
                                                    ),
                                                  ),
                                                ),
                                                ClipRRect(
                                                  borderRadius: BorderRadius.circular(40),
                                                  child: SizedBox(
                                                    width: 42.6,
                                                    height: 2.8,
                                                    child: SvgPicture.asset(
                                                      'assets/vectors/rectangle_415_x2.svg',
                                                    ),
                                                  ),
                                                ),
                                              ],
                                            ),
                                          ),
                                          Positioned(
                                            left: -2.7,
                                            top: -11.9,
                                            child: Container(
                                              decoration: BoxDecoration(
                                                color: Color(0x03FFFFFF),
                                              ),
                                              child: Container(
                                                width: 48.7,
                                                height: 34.7,
                                              ),
                                            ),
                                          ),
                                        ],
                                      ),
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ),
              ),
              Positioned(
                right: -23.1,
                top: 148,
                child: ImageFiltered(
                  imageFilter: ImageFilter.blur(
                    sigmaX: 2,
                    sigmaY: 2,
                  ),
                  child: Stack(
                    children: [
                    Positioned(
                      left: -13.4,
                      top: -5.4,
                      child: Container(
                        decoration: BoxDecoration(
                          color: Color(0xFF000041),
                        ),
                        child: Container(
                          width: 98,
                          height: 28,
                        ),
                      ),
                    ),
              SizedBox(
                        width: 168.1,
                        height: 28,
                        child: Container(
                          padding: EdgeInsets.fromLTRB(13.4, 5.4, 0, 7.4),
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.start,
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Container(
                                margin: EdgeInsets.fromLTRB(0, 0, 7.4, 0),
                                child: SizedBox(
                                  width: 15.2,
                                  height: 15.2,
                                  child: SvgPicture.asset(
                                    'assets/vectors/vector_353_x2.svg',
                                  ),
                                ),
                              ),
                              Container(
                                margin: EdgeInsets.fromLTRB(0, 2.6, 0, 0.6),
                                child: Text(
                                  'Consultar',
                                  style: GoogleFonts.getFont(
                                    'Fira Sans Condensed',
                                    fontWeight: FontWeight.w600,
                                    fontSize: 10,
                                    color: Color(0xFFFFFFFF),
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}