import 'package:flutter/material.dart';
import 'dart:ui';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:flutter_app/utils.dart';
import 'package:google_fonts/google_fonts.dart';

class Relatorio1 extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return 
    Container(
      decoration: BoxDecoration(
        color: Color(0xFFFFFFFF),
      ),
      child: SizedBox(
        width: 1440,
        child: Container(
          padding: EdgeInsets.fromLTRB(7, 34, 0, 21),
          child: Stack(
            clipBehavior: Clip.none,
            children: [
              Column(
                mainAxisAlignment: MainAxisAlignment.start,
                crossAxisAlignment: CrossAxisAlignment.end,
                children: [
                  Container(
                    margin: EdgeInsets.fromLTRB(868.7, 0, 0, 33),
                    child: Align(
                      alignment: Alignment.topCenter,
                      child: Text(
                        'logado: Waltair',
                        style: GoogleFonts.getFont(
                          'Fira Sans Condensed',
                          fontWeight: FontWeight.w300,
                          fontSize: 16,
                          color: Color(0xFFFFFFFF),
                        ),
                      ),
                    ),
                  ),
                  Container(
                    margin: EdgeInsets.fromLTRB(1, 0, 0, 10),
                    child: SizedBox(
                      width: 1432,
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Container(
                            margin: EdgeInsets.fromLTRB(0, 15, 0, 0),
                            child: Row(
                              mainAxisAlignment: MainAxisAlignment.start,
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Container(
                                  margin: EdgeInsets.fromLTRB(0, 0, 8, 5),
                                  child: SizedBox(
                                    width: 18,
                                    height: 16,
                                    child: SvgPicture.asset(
                                      'assets/vectors/vector_111_x2.svg',
                                    ),
                                  ),
                                ),
                                Container(
                                  margin: EdgeInsets.fromLTRB(0, 2, 0, 0),
                                  child: Text(
                                    'inicio
                                ',
                                    style: GoogleFonts.getFont(
                                      'Fira Sans Condensed',
                                      fontWeight: FontWeight.w300,
                                      fontSize: 16,
                                      color: Color(0xFFFFFFFF),
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ),
                          Container(
                            decoration: BoxDecoration(
                              color: Color(0xFFD9D9D9),
                            ),
                            child: Container(
                              width: 1244,
                              height: 36,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                  Container(
                    margin: EdgeInsets.fromLTRB(0, 0, 31, 30),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.start,
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Container(
                          margin: EdgeInsets.fromLTRB(0, 0, 61, 62),
                          child: Column(
                            mainAxisAlignment: MainAxisAlignment.start,
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Container(
                                margin: EdgeInsets.fromLTRB(0, 0, 0.2, 13),
                                child: Row(
                                  mainAxisAlignment: MainAxisAlignment.start,
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Container(
                                      margin: EdgeInsets.fromLTRB(0, 5, 8, 0),
                                      child: SizedBox(
                                        width: 18,
                                        height: 16,
                                        child: SvgPicture.asset(
                                          'assets/vectors/vector_335_x2.svg',
                                        ),
                                      ),
                                    ),
                                    Container(
                                      margin: EdgeInsets.fromLTRB(0, 0, 0, 2),
                                      child: Text(
                                        'consultar reservas',
                                        style: GoogleFonts.getFont(
                                          'Fira Sans Condensed',
                                          fontWeight: FontWeight.w300,
                                          fontSize: 16,
                                          color: Color(0xFFFFFFFF),
                                        ),
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                              Container(
                                margin: EdgeInsets.fromLTRB(0.8, 0, 0, 10),
                                child: Row(
                                  mainAxisAlignment: MainAxisAlignment.start,
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Container(
                                      margin: EdgeInsets.fromLTRB(0, 2.5, 8.8, 1.5),
                                      child: SizedBox(
                                        width: 16.5,
                                        height: 15,
                                        child: SvgPicture.asset(
                                          'assets/vectors/vector_126_x2.svg',
                                        ),
                                      ),
                                    ),
                                    Text(
                                      'adicionar material',
                                      style: GoogleFonts.getFont(
                                        'Fira Sans Condensed',
                                        fontWeight: FontWeight.w300,
                                        fontSize: 16,
                                        color: Color(0xFFFFFFFF),
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                              Container(
                                margin: EdgeInsets.fromLTRB(1, 0, 6.6, 15),
                                child: Row(
                                  mainAxisAlignment: MainAxisAlignment.start,
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Container(
                                      margin: EdgeInsets.fromLTRB(0, 3, 8, 0),
                                      child: SizedBox(
                                        width: 17,
                                        height: 16,
                                        child: SvgPicture.asset(
                                          'assets/vectors/vector_278_x2.svg',
                                        ),
                                      ),
                                    ),
                                    Text(
                                      'adicionar reserva',
                                      style: GoogleFonts.getFont(
                                        'Fira Sans Condensed',
                                        fontWeight: FontWeight.w300,
                                        fontSize: 16,
                                        color: Color(0xFFFFFFFF),
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                              Container(
                                margin: EdgeInsets.fromLTRB(1, 0, 1, 0),
                                child: Align(
                                  alignment: Alignment.topLeft,
                                  child: Row(
                                    mainAxisAlignment: MainAxisAlignment.start,
                                    crossAxisAlignment: CrossAxisAlignment.start,
                                    children: [
                                      Container(
                                        margin: EdgeInsets.fromLTRB(0, 1, 10, 2),
                                        child: SizedBox(
                                          width: 15,
                                          height: 16,
                                          child: SvgPicture.asset(
                                            'assets/vectors/container_84_x2.svg',
                                          ),
                                        ),
                                      ),
                                      Text(
                                        'relatorios
                                      ',
                                        style: GoogleFonts.getFont(
                                          'Fira Sans Condensed',
                                          fontWeight: FontWeight.w300,
                                          fontSize: 16,
                                          color: Color(0xFFFFFFFF),
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                        Container(
                          margin: EdgeInsets.fromLTRB(0, 16, 0, 0),
                          decoration: BoxDecoration(
                            border: Border.all(color: Color(0xFFAA9D9D)),
                            color: Color(0xFFD9D9D9),
                          ),
                          child: SizedBox(
                            width: 1197,
                            child: Container(
                              padding: EdgeInsets.fromLTRB(20, 21, 16, 100),
                              child: Row(
                                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Row(
                                    mainAxisAlignment: MainAxisAlignment.start,
                                    crossAxisAlignment: CrossAxisAlignment.start,
                                    children: [
                                      Column(
                                        mainAxisAlignment: MainAxisAlignment.start,
                                        crossAxisAlignment: CrossAxisAlignment.start,
                                        children: [
                                          Align(
                                            alignment: Alignment.topLeft,
                                            child: Text(
                                              'Data Inicial',
                                              style: GoogleFonts.getFont(
                                                'Fira Sans Condensed',
                                                fontWeight: FontWeight.w600,
                                                fontSize: 10,
                                                color: Color(0xFF000000),
                                              ),
                                            ),
                                          ),
                                          Container(
                                            decoration: BoxDecoration(
                                              border: Border.all(color: Color(0xFFAAA1A1)),
                                              color: Color(0xFFFFFFFF),
                                            ),
                                            child: SizedBox(
                                              width: 187.8,
                                              child: Container(
                                                padding: EdgeInsets.fromLTRB(4.8, 2.3, 0, 3.5),
                                                child: Row(
                                                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                                  crossAxisAlignment: CrossAxisAlignment.start,
                                                  children: [
                                                    SizedBox(
                                                      width: 36,
                                                      child: Row(
                                                        mainAxisAlignment: MainAxisAlignment.start,
                                                        crossAxisAlignment: CrossAxisAlignment.start,
                                                        children: [
                                                          Container(
                                                            margin: EdgeInsets.fromLTRB(0, 0, 4.8, 0),
                                                            child: SizedBox(
                                                              width: 30.2,
                                                              height: 23.4,
                                                              child: SvgPicture.asset(
                                                                'assets/vectors/vector_23_x2.svg',
                                                              ),
                                                            ),
                                                          ),
                                                          Container(
                                                            margin: EdgeInsets.fromLTRB(0, 1.2, 0, 0),
                                                            child: Container(
                                                              decoration: BoxDecoration(
                                                                color: Color(0xFFAA9D9D),
                                                              ),
                                                              child: Container(
                                                                width: 1,
                                                                height: 22.3,
                                                              ),
                                                            ),
                                                          ),
                                                        ],
                                                      ),
                                                    ),
                                                    Container(
                                                      margin: EdgeInsets.fromLTRB(0, 2.9, 0, 5.5),
                                                      child: Text(
                                                        '01/11/2022',
                                                        style: GoogleFonts.getFont(
                                                          'Inter',
                                                          fontWeight: FontWeight.w400,
                                                          fontSize: 12,
                                                          color: Color(0xFF000000),
                                                        ),
                                                      ),
                                                    ),
                                                  ],
                                                ),
                                              ),
                                            ),
                                          ),
                                        ],
                                      ),
                                      Column(
                                        mainAxisAlignment: MainAxisAlignment.start,
                                        crossAxisAlignment: CrossAxisAlignment.start,
                                        children: [
                                          Align(
                                            alignment: Alignment.topLeft,
                                            child: Text(
                                              'Data Final',
                                              style: GoogleFonts.getFont(
                                                'Fira Sans Condensed',
                                                fontWeight: FontWeight.w600,
                                                fontSize: 10,
                                                color: Color(0xFF000000),
                                              ),
                                            ),
                                          ),
                                          Container(
                                            decoration: BoxDecoration(
                                              border: Border.all(color: Color(0xFFAAA1A1)),
                                              color: Color(0xFFFFFFFF),
                                            ),
                                            child: SizedBox(
                                              width: 187.8,
                                              child: Container(
                                                padding: EdgeInsets.fromLTRB(4.8, 2.3, 0, 3.5),
                                                child: Row(
                                                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                                  crossAxisAlignment: CrossAxisAlignment.start,
                                                  children: [
                                                    SizedBox(
                                                      width: 36,
                                                      child: Row(
                                                        mainAxisAlignment: MainAxisAlignment.start,
                                                        crossAxisAlignment: CrossAxisAlignment.start,
                                                        children: [
                                                          Container(
                                                            margin: EdgeInsets.fromLTRB(0, 0, 4.8, 0),
                                                            child: SizedBox(
                                                              width: 30.2,
                                                              height: 23.4,
                                                              child: SvgPicture.asset(
                                                                'assets/vectors/vector_279_x2.svg',
                                                              ),
                                                            ),
                                                          ),
                                                          Container(
                                                            margin: EdgeInsets.fromLTRB(0, 1.2, 0, 0),
                                                            child: Container(
                                                              decoration: BoxDecoration(
                                                                color: Color(0xFFAA9D9D),
                                                              ),
                                                              child: Container(
                                                                width: 1,
                                                                height: 22.3,
                                                              ),
                                                            ),
                                                          ),
                                                        ],
                                                      ),
                                                    ),
                                                    Container(
                                                      margin: EdgeInsets.fromLTRB(0, 2.9, 0, 5.5),
                                                      child: Text(
                                                        '30/11/2022',
                                                        style: GoogleFonts.getFont(
                                                          'Inter',
                                                          fontWeight: FontWeight.w400,
                                                          fontSize: 12,
                                                          color: Color(0xFF000000),
                                                        ),
                                                      ),
                                                    ),
                                                  ],
                                                ),
                                              ),
                                            ),
                                          ),
                                        ],
                                      ),
                                      Column(
                                        mainAxisAlignment: MainAxisAlignment.start,
                                        crossAxisAlignment: CrossAxisAlignment.start,
                                        children: [
                                          Align(
                                            alignment: Alignment.topLeft,
                                            child: Text(
                                              'Setor',
                                              style: GoogleFonts.getFont(
                                                'Fira Sans Condensed',
                                                fontWeight: FontWeight.w600,
                                                fontSize: 10,
                                                color: Color(0xFF000000),
                                              ),
                                            ),
                                          ),
                                          Container(
                                            decoration: BoxDecoration(
                                              border: Border.all(color: Color(0xFFAAA1A1)),
                                              color: Color(0xFFFFFFFF),
                                            ),
                                            child: SizedBox(
                                              width: 187.8,
                                              child: Container(
                                                padding: EdgeInsets.fromLTRB(9, 3.5, 0, 3.5),
                                                child: Row(
                                                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                                  crossAxisAlignment: CrossAxisAlignment.start,
                                                  children: [
                                                    SizedBox(
                                                      width: 31.8,
                                                      child: Row(
                                                        mainAxisAlignment: MainAxisAlignment.start,
                                                        crossAxisAlignment: CrossAxisAlignment.start,
                                                        children: [
                                                          Container(
                                                            margin: EdgeInsets.fromLTRB(0, 1.8, 10.8, 0.5),
                                                            child: SizedBox(
                                                              width: 20,
                                                              height: 20,
                                                              child: SvgPicture.asset(
                                                                'assets/vectors/vector_76_x2.svg',
                                                              ),
                                                            ),
                                                          ),
                                                          Container(
                                                            decoration: BoxDecoration(
                                                              color: Color(0xFFAA9D9D),
                                                            ),
                                                            child: Container(
                                                              width: 1,
                                                              height: 22.3,
                                                            ),
                                                          ),
                                                        ],
                                                      ),
                                                    ),
                                                    Container(
                                                      margin: EdgeInsets.fromLTRB(0, 4.8, 0, 2.5),
                                                      child: Text(
                                                        '-',
                                                        style: GoogleFonts.getFont(
                                                          'Inter',
                                                          fontWeight: FontWeight.w400,
                                                          fontSize: 12,
                                                          color: Color(0xFF000000),
                                                        ),
                                                      ),
                                                    ),
                                                  ],
                                                ),
                                              ),
                                            ),
                                          ),
                                        ],
                                      ),
                                      Column(
                                        mainAxisAlignment: MainAxisAlignment.start,
                                        crossAxisAlignment: CrossAxisAlignment.start,
                                        children: [
                                          Align(
                                            alignment: Alignment.topLeft,
                                            child: Text(
                                              'Responsavel',
                                              style: GoogleFonts.getFont(
                                                'Fira Sans Condensed',
                                                fontWeight: FontWeight.w600,
                                                fontSize: 10,
                                                color: Color(0xFF000000),
                                              ),
                                            ),
                                          ),
                                          Container(
                                            decoration: BoxDecoration(
                                              border: Border.all(color: Color(0xFFAAA1A1)),
                                              color: Color(0xFFFFFFFF),
                                            ),
                                            child: SizedBox(
                                              width: 187.8,
                                              child: Container(
                                                padding: EdgeInsets.fromLTRB(10, 3.5, 0, 3.5),
                                                child: Row(
                                                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                                  crossAxisAlignment: CrossAxisAlignment.start,
                                                  children: [
                                                    SizedBox(
                                                      width: 30.8,
                                                      child: Row(
                                                        mainAxisAlignment: MainAxisAlignment.start,
                                                        crossAxisAlignment: CrossAxisAlignment.start,
                                                        children: [
                                                          Container(
                                                            margin: EdgeInsets.fromLTRB(0, 0.8, 9.8, 1.5),
                                                            child: SizedBox(
                                                              width: 20,
                                                              height: 20,
                                                              child: SvgPicture.asset(
                                                                'assets/vectors/vector_282_x2.svg',
                                                              ),
                                                            ),
                                                          ),
                                                          Container(
                                                            decoration: BoxDecoration(
                                                              color: Color(0xFFAA9D9D),
                                                            ),
                                                            child: Container(
                                                              width: 1,
                                                              height: 22.3,
                                                            ),
                                                          ),
                                                        ],
                                                      ),
                                                    ),
                                                    Container(
                                                      margin: EdgeInsets.fromLTRB(0, 4.8, 0, 2.5),
                                                      child: Text(
                                                        '-',
                                                        style: GoogleFonts.getFont(
                                                          'Inter',
                                                          fontWeight: FontWeight.w400,
                                                          fontSize: 12,
                                                          color: Color(0xFF000000),
                                                        ),
                                                      ),
                                                    ),
                                                  ],
                                                ),
                                              ),
                                            ),
                                          ),
                                        ],
                                      ),
                                      Column(
                                        mainAxisAlignment: MainAxisAlignment.start,
                                        crossAxisAlignment: CrossAxisAlignment.start,
                                        children: [
                                          Align(
                                            alignment: Alignment.topLeft,
                                            child: Text(
                                              'Situação',
                                              style: GoogleFonts.getFont(
                                                'Fira Sans Condensed',
                                                fontWeight: FontWeight.w600,
                                                fontSize: 10,
                                                color: Color(0xFF000000),
                                              ),
                                            ),
                                          ),
                                          Container(
                                            decoration: BoxDecoration(
                                              border: Border.all(color: Color(0xFFAAA1A1)),
                                              color: Color(0xFFFFFFFF),
                                            ),
                                            child: SizedBox(
                                              width: 187.8,
                                              child: Container(
                                                padding: EdgeInsets.fromLTRB(9, 3.5, 0, 3.5),
                                                child: Row(
                                                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                                  crossAxisAlignment: CrossAxisAlignment.start,
                                                  children: [
                                                    SizedBox(
                                                      width: 31.8,
                                                      child: Row(
                                                        mainAxisAlignment: MainAxisAlignment.start,
                                                        crossAxisAlignment: CrossAxisAlignment.start,
                                                        children: [
                                                          Container(
                                                            margin: EdgeInsets.fromLTRB(0, 0.8, 10.8, 1.5),
                                                            child: SizedBox(
                                                              width: 20,
                                                              height: 20,
                                                              child: SvgPicture.asset(
                                                                'assets/vectors/vector_318_x2.svg',
                                                              ),
                                                            ),
                                                          ),
                                                          Container(
                                                            decoration: BoxDecoration(
                                                              color: Color(0xFFAA9D9D),
                                                            ),
                                                            child: Container(
                                                              width: 1,
                                                              height: 22.3,
                                                            ),
                                                          ),
                                                        ],
                                                      ),
                                                    ),
                                                    Container(
                                                      margin: EdgeInsets.fromLTRB(0, 2.8, 0, 4.5),
                                                      child: Text(
                                                        'Reserva',
                                                        style: GoogleFonts.getFont(
                                                          'Inter',
                                                          fontWeight: FontWeight.w400,
                                                          fontSize: 12,
                                                          color: Color(0xFF000000),
                                                        ),
                                                      ),
                                                    ),
                                                  ],
                                                ),
                                              ),
                                            ),
                                          ),
                                        ],
                                      ),
                                    ],
                                  ),
                                  Container(
                                    margin: EdgeInsets.fromLTRB(0, 13, 0, 0),
                                    child: Container(
                                      decoration: BoxDecoration(
                                        color: Color(0xFF000041),
                                      ),
                                      child: SizedBox(
                                        width: 98,
                                        child: Container(
                                          padding: EdgeInsets.fromLTRB(13.4, 5.4, 0, 7.4),
                                          child: Row(
                                            mainAxisAlignment: MainAxisAlignment.start,
                                            crossAxisAlignment: CrossAxisAlignment.start,
                                            children: [
                                              Container(
                                                margin: EdgeInsets.fromLTRB(0, 0, 7.4, 0),
                                                child: SizedBox(
                                                  width: 15.2,
                                                  height: 15.2,
                                                  child: SvgPicture.asset(
                                                    'assets/vectors/vector_58_x2.svg',
                                                  ),
                                                ),
                                              ),
                                              Container(
                                                margin: EdgeInsets.fromLTRB(0, 2.6, 0, 0.6),
                                                child: Text(
                                                  'Consultar',
                                                  style: GoogleFonts.getFont(
                                                    'Fira Sans Condensed',
                                                    fontWeight: FontWeight.w600,
                                                    fontSize: 10,
                                                    color: Color(0xFFFFFFFF),
                                                  ),
                                                ),
                                              ),
                                            ],
                                          ),
                                        ),
                                      ),
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                  Container(
                    margin: EdgeInsets.fromLTRB(31, 0, 31, 0),
                    child: Container(
                      decoration: BoxDecoration(
                        color: Color(0xFFD9D9D9),
                      ),
                      child: SizedBox(
                        height: 663,
                        child: Container(
                          padding: EdgeInsets.fromLTRB(0, 1, 0, 0),
                          child: Stack(
                            clipBehavior: Clip.none,
                            children: [
                              Positioned(
                                right: 0,
                                bottom: 156.5,
                                child: Container(
                                  decoration: BoxDecoration(
                                    color: Color(0xFFA1A1A1),
                                  ),
                                  child: Container(
                                    width: 1197,
                                    height: 1,
                                  ),
                                ),
                              ),
                              Positioned(
                                left: 0,
                                bottom: 250.1,
                                child: Container(
                                  decoration: BoxDecoration(
                                    color: Color(0xFFA1A1A1),
                                  ),
                                  child: Container(
                                    width: 1197,
                                    height: 1,
                                  ),
                                ),
                              ),
                              Positioned(
                                right: 0,
                                top: 317.5,
                                child: Container(
                                  decoration: BoxDecoration(
                                    color: Color(0xFFA1A1A1),
                                  ),
                                  child: Container(
                                    width: 1197,
                                    height: 1,
                                  ),
                                ),
                              ),
                              Positioned(
                                right: 0,
                                bottom: 203.5,
                                child: Container(
                                  decoration: BoxDecoration(
                                    color: Color(0xFFA1A1A1),
                                  ),
                                  child: Container(
                                    width: 1197,
                                    height: 1,
                                  ),
                                ),
                              ),
                              Positioned(
                                left: 0,
                                bottom: 297.8,
                                child: Container(
                                  decoration: BoxDecoration(
                                    color: Color(0xFFA1A1A1),
                                  ),
                                  child: Container(
                                    width: 1197,
                                    height: 1,
                                  ),
                                ),
                              ),
                              Positioned(
                                right: 0,
                                top: 278,
                                child: Container(
                                  decoration: BoxDecoration(
                                    color: Color(0xFFA1A1A1),
                                  ),
                                  child: Container(
                                    width: 1197,
                                    height: 1,
                                  ),
                                ),
                              ),
                              Column(
                                mainAxisAlignment: MainAxisAlignment.start,
                                crossAxisAlignment: CrossAxisAlignment.center,
                                children: [
                                  Container(
                                    margin: EdgeInsets.fromLTRB(0, 0, 0, 18.5),
                                    child: Container(
                                      decoration: BoxDecoration(
                                        color: Color(0xFF212176),
                                      ),
                                      child: SizedBox(
                                        width: 1197,
                                        child: Container(
                                          padding: EdgeInsets.fromLTRB(5, 7, 0, 4),
                                          child: Row(
                                            mainAxisAlignment: MainAxisAlignment.start,
                                            crossAxisAlignment: CrossAxisAlignment.start,
                                            children: [
                                              Container(
                                                margin: EdgeInsets.fromLTRB(0, 0, 3, 0),
                                                child: SizedBox(
                                                  width: 20,
                                                  height: 20,
                                                  child: SvgPicture.asset(
                                                    'assets/vectors/vector_92_x2.svg',
                                                  ),
                                                ),
                                              ),
                                              Container(
                                                margin: EdgeInsets.fromLTRB(0, 5, 0, 3),
                                                child: Text(
                                                  'Atividades',
                                                  style: GoogleFonts.getFont(
                                                    'Fira Sans Condensed',
                                                    fontWeight: FontWeight.w600,
                                                    fontSize: 10,
                                                    color: Color(0xFFFFFFFF),
                                                  ),
                                                ),
                                              ),
                                            ],
                                          ),
                                        ),
                                      ),
                                    ),
                                  ),
                                  Container(
                                    margin: EdgeInsets.fromLTRB(0, 0, 0, 38.5),
                                    child: Container(
                                      decoration: BoxDecoration(
                                        color: Color(0xFFA1A1A1),
                                      ),
                                      child: Container(
                                        width: 1197,
                                        height: 1,
                                      ),
                                    ),
                                  ),
                                  Container(
                                    margin: EdgeInsets.fromLTRB(0, 0, 0, 46),
                                    child: Container(
                                      decoration: BoxDecoration(
                                        color: Color(0xFFA1A1A1),
                                      ),
                                      child: Container(
                                        width: 1197,
                                        height: 1,
                                      ),
                                    ),
                                  ),
                                  Container(
                                    margin: EdgeInsets.fromLTRB(0, 0, 0, 46),
                                    child: Container(
                                      decoration: BoxDecoration(
                                        color: Color(0xFFA1A1A1),
                                      ),
                                      child: Container(
                                        width: 1197,
                                        height: 1,
                                      ),
                                    ),
                                  ),
                                  Container(
                                    margin: EdgeInsets.fromLTRB(0, 0, 0, 46),
                                    child: Container(
                                      decoration: BoxDecoration(
                                        color: Color(0xFFA1A1A1),
                                      ),
                                      child: Container(
                                        width: 1197,
                                        height: 1,
                                      ),
                                    ),
                                  ),
                                  Container(
                                    margin: EdgeInsets.fromLTRB(0, 0, 0, 12),
                                    child: Container(
                                      decoration: BoxDecoration(
                                        color: Color(0xFFA1A1A1),
                                      ),
                                      child: Container(
                                        width: 1197,
                                        height: 1,
                                      ),
                                    ),
                                  ),
                                  SizedBox(
                                    width: 1197,
                                    height: 290,
                                    child: Container(
                                      padding: EdgeInsets.fromLTRB(0, 34, 0, 255),
                                      child: Stack(
                                        clipBehavior: Clip.none,
                                        children: [
                                          Container(
                                            decoration: BoxDecoration(
                                              color: Color(0xFFA1A1A1),
                                            ),
                                            child: Container(
                                              width: 1197,
                                              height: 1,
                                            ),
                                          ),
                                          Positioned(
                                            left: 106,
                                            bottom: 0,
                                            child: Container(
                                              decoration: BoxDecoration(
                                                color: Color(0xFF4F38D4),
                                              ),
                                              child: Container(
                                                width: 67,
                                                height: 148,
                                              ),
                                            ),
                                          ),
                                          Positioned(
                                            left: 208,
                                            bottom: 0,
                                            child: Container(
                                              decoration: BoxDecoration(
                                                color: Color(0xFF212176),
                                              ),
                                              child: Container(
                                                width: 67,
                                                height: 197,
                                              ),
                                            ),
                                          ),
                                          Positioned(
                                            left: 401,
                                            bottom: 0,
                                            child: Container(
                                              decoration: BoxDecoration(
                                                color: Color(0xFF212176),
                                              ),
                                              child: Container(
                                                width: 67,
                                                height: 290,
                                              ),
                                            ),
                                          ),
                                          Positioned(
                                            right: 520,
                                            bottom: 0,
                                            child: Container(
                                              decoration: BoxDecoration(
                                                color: Color(0xFF212176),
                                              ),
                                              child: Container(
                                                width: 67,
                                                height: 15,
                                              ),
                                            ),
                                          ),
                                          Positioned(
                                            right: 313,
                                            bottom: 0,
                                            child: Container(
                                              decoration: BoxDecoration(
                                                color: Color(0xFF212176),
                                              ),
                                              child: Container(
                                                width: 67,
                                                height: 197,
                                              ),
                                            ),
                                          ),
                                          Positioned(
                                            right: 102,
                                            bottom: 0,
                                            child: Container(
                                              decoration: BoxDecoration(
                                                color: Color(0xFF212176),
                                              ),
                                              child: Container(
                                                width: 67,
                                                height: 197,
                                              ),
                                            ),
                                          ),
                                          Positioned(
                                            right: 418,
                                            bottom: 0,
                                            child: Container(
                                              decoration: BoxDecoration(
                                                color: Color(0xFF4F38D4),
                                              ),
                                              child: Container(
                                                width: 67,
                                                height: 197,
                                              ),
                                            ),
                                          ),
                                          Positioned(
                                            left: 310,
                                            bottom: 0,
                                            child: Container(
                                              decoration: BoxDecoration(
                                                color: Color(0xFF4F38D4),
                                              ),
                                              child: Container(
                                                width: 67,
                                                height: 54,
                                              ),
                                            ),
                                          ),
                                          Positioned(
                                            right: 211,
                                            bottom: 0,
                                            child: Container(
                                              decoration: BoxDecoration(
                                                color: Color(0xFF4F38D4),
                                              ),
                                              child: Container(
                                                width: 67,
                                                height: 290,
                                              ),
                                            ),
                                          ),
                                          Positioned(
                                            left: 508,
                                            bottom: 0,
                                            child: Container(
                                              decoration: BoxDecoration(
                                                color: Color(0xFF4F38D4),
                                              ),
                                              child: Container(
                                                width: 67,
                                                height: 198,
                                              ),
                                            ),
                                          ),
                                        ],
                                      ),
                                    ),
                                  ),
                                ],
                              ),
                            ],
                          ),
                        ),
                      ),
                    ),
                  ),
                ],
              ),
              Positioned(
                left: -89,
                bottom: -21,
                child: Container(
                  decoration: BoxDecoration(
                    color: Color(0xFF212176),
                    borderRadius: BorderRadius.only(
                      bottomRight: Radius.circular(100),
                    ),
                  ),
                  child: SizedBox(
                    width: 278,
                    height: 959,
                    child: Container(
                      padding: EdgeInsets.fromLTRB(9.2, 15.8, 9.2, 0),
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.start,
                        crossAxisAlignment: CrossAxisAlignment.center,
                        children: [
                          Container(
                            margin: EdgeInsets.fromLTRB(0, 0, 0, 16.9),
                            child: Align(
                              alignment: Alignment.topLeft,
                              child: Row(
                                mainAxisAlignment: MainAxisAlignment.start,
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Container(
                                    margin: EdgeInsets.fromLTRB(0, 0, 43.5, 0),
                                    child: SizedBox(
                                      width: 47.3,
                                      height: 65.3,
                                      child: SvgPicture.asset(
                                        'assets/vectors/hamburger_22_x2.svg',
                                      ),
                                    ),
                                  ),
                                  Container(
                                    margin: EdgeInsets.fromLTRB(0, 32.2, 0, 13.1),
                                    child: Row(
                                      mainAxisAlignment: MainAxisAlignment.start,
                                      crossAxisAlignment: CrossAxisAlignment.start,
                                      children: [
                                        Container(
                                          margin: EdgeInsets.fromLTRB(0, 3, 8, 1),
                                          child: SizedBox(
                                            width: 17,
                                            height: 16,
                                            child: SvgPicture.asset(
                                              'assets/vectors/vector_26_x2.svg',
                                            ),
                                          ),
                                        ),
                                        Text(
                                          'Audio visual',
                                          style: GoogleFonts.getFont(
                                            'Fira Sans Condensed',
                                            fontWeight: FontWeight.w600,
                                            fontSize: 17,
                                            color: Color(0xFFFFFFFF),
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ),
                          Container(
                            margin: EdgeInsets.fromLTRB(35.8, 0, 0, 34),
                            child: Row(
                              mainAxisAlignment: MainAxisAlignment.start,
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Container(
                                  margin: EdgeInsets.fromLTRB(0, 2.5, 4.5, 2.5),
                                  child: SizedBox(
                                    width: 16.5,
                                    height: 15,
                                    child: SvgPicture.asset(
                                      'assets/vectors/vector_302_x2.svg',
                                    ),
                                  ),
                                ),
                                Text(
                                  'Equipamento',
                                  style: GoogleFonts.getFont(
                                    'Fira Sans Condensed',
                                    fontWeight: FontWeight.w600,
                                    fontSize: 17,
                                    color: Color(0xFFFFFFFF),
                                  ),
                                ),
                              ],
                            ),
                          ),
                          Container(
                            margin: EdgeInsets.fromLTRB(8.6, 0, 0, 31),
                            child: Row(
                              mainAxisAlignment: MainAxisAlignment.start,
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Container(
                                  margin: EdgeInsets.fromLTRB(0, 1, 10, 3),
                                  child: SizedBox(
                                    width: 15,
                                    height: 16,
                                    child: SvgPicture.asset(
                                      'assets/vectors/container_71_x2.svg',
                                    ),
                                  ),
                                ),
                                Text(
                                  'Usuários',
                                  style: GoogleFonts.getFont(
                                    'Fira Sans Condensed',
                                    fontWeight: FontWeight.w600,
                                    fontSize: 17,
                                    color: Color(0xFFFFFFFF),
                                  ),
                                ),
                              ],
                            ),
                          ),
                          Container(
                            margin: EdgeInsets.fromLTRB(27.6, 0, 0, 33),
                            child: Row(
                              mainAxisAlignment: MainAxisAlignment.start,
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Container(
                                  margin: EdgeInsets.fromLTRB(0, 1, 10, 3),
                                  child: SizedBox(
                                    width: 15,
                                    height: 16,
                                    child: SvgPicture.asset(
                                      'assets/vectors/container_6_x2.svg',
                                    ),
                                  ),
                                ),
                                Text(
                                  'Relatorios
                                ',
                                  style: GoogleFonts.getFont(
                                    'Fira Sans Condensed',
                                    fontWeight: FontWeight.w600,
                                    fontSize: 17,
                                    color: Color(0xFFFFFFFF),
                                  ),
                                ),
                              ],
                            ),
                          ),
                          Container(
                            margin: EdgeInsets.fromLTRB(7.2, 0, 0, 0),
                            child: Row(
                              mainAxisAlignment: MainAxisAlignment.start,
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Container(
                                  margin: EdgeInsets.fromLTRB(0, 5, 8, 0),
                                  child: SizedBox(
                                    width: 18,
                                    height: 16,
                                    child: SvgPicture.asset(
                                      'assets/vectors/vector_403_x2.svg',
                                    ),
                                  ),
                                ),
                                Container(
                                  margin: EdgeInsets.fromLTRB(0, 0, 0, 1),
                                  child: Text(
                                    'Reservas',
                                    style: GoogleFonts.getFont(
                                      'Fira Sans Condensed',
                                      fontWeight: FontWeight.w600,
                                      fontSize: 17,
                                      color: Color(0xFFFFFFFF),
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ),
              ),
              Positioned(
                right: -39,
                top: -34,
                child: Container(
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(5),
                    color: Color(0xFF000041),
                    boxShadow: [
                      BoxShadow(
                        color: Color(0x40000000),
                        offset: Offset(0, 4),
                        blurRadius: 2,
                      ),
                    ],
                  ),
                  child: SizedBox(
                    width: 1479,
                    height: 82,
                    child: Container(
                      padding: EdgeInsets.fromLTRB(0, 4, 74, 6),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Container(
                            decoration: BoxDecoration(
                              image: DecorationImage(
                                fit: BoxFit.cover,
                                image: AssetImage(
                                  'assets/images/image_2.png',
                                ),
                              ),
                            ),
                            child: Container(
                              width: 189,
                              height: 72,
                            ),
                          ),
                          Container(
                            margin: EdgeInsets.fromLTRB(0, 6, 0, 9),
                            child: Row(
                              mainAxisAlignment: MainAxisAlignment.start,
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Container(
                                  margin: EdgeInsets.fromLTRB(0, 0, 17, 0),
                                  child: SizedBox(
                                    width: 59,
                                    height: 57,
                                    child: SvgPicture.asset(
                                      'assets/vectors/group_188_x2.svg',
                                    ),
                                  ),
                                ),
                                Container(
                                  margin: EdgeInsets.fromLTRB(0, 19, 0, 19),
                                  child: Text(
                                    'Logado: Waltair',
                                    style: GoogleFonts.getFont(
                                      'Fira Sans Condensed',
                                      fontWeight: FontWeight.w600,
                                      fontSize: 16,
                                      color: Color(0xFFFFFFFF),
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ),
                          Container(
                            margin: EdgeInsets.fromLTRB(0, 14, 0, 16),
                            child: Row(
                              mainAxisAlignment: MainAxisAlignment.start,
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Container(
                                  margin: EdgeInsets.fromLTRB(0, 0, 31, 0),
                                  child: Container(
                                    padding: EdgeInsets.fromLTRB(17, 11, 17, 12),
                                    child: Stack(
                                      clipBehavior: Clip.none,
                                      children: [
                                        Text(
                                          'Encerrar sessão',
                                          style: GoogleFonts.getFont(
                                            'Fira Sans Condensed',
                                            fontWeight: FontWeight.w600,
                                            fontSize: 16,
                                            color: Color(0xFFFFFFFF),
                                          ),
                                        ),
                                        Positioned(
                                          bottom: -12,
                                          child: Container(
                                            width: 138,
                                            height: 42,
                                            decoration: BoxDecoration(
                                              border: Border.all(color: Color(0xFFFFFFFF)),
                                              borderRadius: BorderRadius.circular(19),
                                            ),
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                ),
                                Container(
                                  decoration: BoxDecoration(
                                    color: Color(0xFF202075),
                                  ),
                                  child: SizedBox(
                                    width: 53,
                                    child: Container(
                                      padding: EdgeInsets.fromLTRB(2.7, 12.9, 7.7, 12.6),
                                      child: Stack(
                                        clipBehavior: Clip.none,
                                        children: [
                                          SizedBox(
                                            width: 42.6,
                                            child: Column(
                                              mainAxisAlignment: MainAxisAlignment.start,
                                              crossAxisAlignment: CrossAxisAlignment.center,
                                              children: [
                                                Container(
                                                  margin: EdgeInsets.fromLTRB(7.4, 0, 2.7, 4),
                                                  child: ClipRRect(
                                                    borderRadius: BorderRadius.circular(40),
                                                    child: SizedBox(
                                                      width: 32.5,
                                                      height: 2.8,
                                                      child: SvgPicture.asset(
                                                        'assets/vectors/rectangle_21_x2.svg',
                                                      ),
                                                    ),
                                                  ),
                                                ),
                                                Container(
                                                  margin: EdgeInsets.fromLTRB(7.4, 0, 2.7, 4),
                                                  child: ClipRRect(
                                                    borderRadius: BorderRadius.circular(40),
                                                    child: SizedBox(
                                                      width: 32.5,
                                                      height: 2.8,
                                                      child: SvgPicture.asset(
                                                        'assets/vectors/rectangle_320_x2.svg',
                                                      ),
                                                    ),
                                                  ),
                                                ),
                                                ClipRRect(
                                                  borderRadius: BorderRadius.circular(40),
                                                  child: SizedBox(
                                                    width: 42.6,
                                                    height: 2.8,
                                                    child: SvgPicture.asset(
                                                      'assets/vectors/rectangle_413_x2.svg',
                                                    ),
                                                  ),
                                                ),
                                              ],
                                            ),
                                          ),
                                          Positioned(
                                            left: -2.7,
                                            top: -11.9,
                                            child: Container(
                                              decoration: BoxDecoration(
                                                color: Color(0x03FFFFFF),
                                              ),
                                              child: Container(
                                                width: 48.7,
                                                height: 34.7,
                                              ),
                                            ),
                                          ),
                                        ],
                                      ),
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ),
              ),
              Positioned(
                right: 31,
                bottom: 0,
                child: Container(
                  decoration: BoxDecoration(
                    color: Color(0xFF4228D7),
                    borderRadius: BorderRadius.circular(5),
                  ),
                  child: SizedBox(
                    width: 1198,
                    height: 129,
                    child: Container(
                      padding: EdgeInsets.fromLTRB(108, 27, 0, 90),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Container(
                            margin: EdgeInsets.fromLTRB(0, 0, 6, 0),
                            child: SizedBox(
                              width: 96,
                              child: Text(
                                'DataShow',
                                style: GoogleFonts.getFont(
                                  'Fira Sans Condensed',
                                  fontWeight: FontWeight.w600,
                                  fontSize: 10,
                                  color: Color(0xFFFFFFFF),
                                ),
                              ),
                            ),
                          ),
                          Text(
                            'Microfone',
                            style: GoogleFonts.getFont(
                              'Fira Sans Condensed',
                              fontWeight: FontWeight.w600,
                              fontSize: 10,
                              color: Color(0xFFFFFFFF),
                            ),
                          ),
                          Text(
                            'Auto Falante',
                            style: GoogleFonts.getFont(
                              'Fira Sans Condensed',
                              fontWeight: FontWeight.w600,
                              fontSize: 10,
                              color: Color(0xFFFFFFFF),
                            ),
                          ),
                          Text(
                            'Cabo P10',
                            style: GoogleFonts.getFont(
                              'Fira Sans Condensed',
                              fontWeight: FontWeight.w600,
                              fontSize: 10,
                              color: Color(0xFFFFFFFF),
                            ),
                          ),
                          Text(
                            'Sala Tec',
                            style: GoogleFonts.getFont(
                              'Fira Sans Condensed',
                              fontWeight: FontWeight.w600,
                              fontSize: 10,
                              color: Color(0xFFFFFFFF),
                            ),
                          ),
                          Text(
                            'Computador',
                            style: GoogleFonts.getFont(
                              'Fira Sans Condensed',
                              fontWeight: FontWeight.w600,
                              fontSize: 10,
                              color: Color(0xFFFFFFFF),
                            ),
                          ),
                          Text(
                            'Monitor',
                            style: GoogleFonts.getFont(
                              'Fira Sans Condensed',
                              fontWeight: FontWeight.w600,
                              fontSize: 10,
                              color: Color(0xFFFFFFFF),
                            ),
                          ),
                          Text(
                            'Megafone',
                            style: GoogleFonts.getFont(
                              'Fira Sans Condensed',
                              fontWeight: FontWeight.w600,
                              fontSize: 10,
                              color: Color(0xFFFFFFFF),
                            ),
                          ),
                          Text(
                            'Monitor',
                            style: GoogleFonts.getFont(
                              'Fira Sans Condensed',
                              fontWeight: FontWeight.w600,
                              fontSize: 10,
                              color: Color(0xFFFFFFFF),
                            ),
                          ),
                          Text(
                            'Megafone',
                            style: GoogleFonts.getFont(
                              'Fira Sans Condensed',
                              fontWeight: FontWeight.w600,
                              fontSize: 10,
                              color: Color(0xFFFFFFFF),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}