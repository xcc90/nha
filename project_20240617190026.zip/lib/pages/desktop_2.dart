import 'package:flutter/material.dart';
import 'dart:ui';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:flutter_app/utils.dart';
import 'package:google_fonts/google_fonts.dart';

class Desktop2 extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return 
    Container(
      decoration: BoxDecoration(
        color: Color(0xFFFFFFFF),
      ),
      child: Stack(
        children: [
          Positioned(
            right: -39,
            top: 0,
            child: Container(
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(5),
                color: Color(0xFF000041),
                boxShadow: [
                  BoxShadow(
                    color: Color(0x40000000),
                    offset: Offset(0, 4),
                    blurRadius: 2,
                  ),
                ],
              ),
              child: Container(
                width: 1479,
                height: 82,
              ),
            ),
          ),
    SizedBox(
            width: 1440,
            child: Container(
              padding: EdgeInsets.fromLTRB(0, 4, 41, 0),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Container(
                    decoration: BoxDecoration(
                      image: DecorationImage(
                        fit: BoxFit.cover,
                        image: AssetImage(
                          'assets/images/image_2.png',
                        ),
                      ),
                    ),
                    child: Container(
                      width: 189,
                      height: 72,
                    ),
                  ),
                  Container(
                    margin: EdgeInsets.fromLTRB(0, 6, 0, 9),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.start,
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Container(
                          margin: EdgeInsets.fromLTRB(0, 0, 17, 0),
                          child: SizedBox(
                            width: 59,
                            height: 57,
                            child: SvgPicture.asset(
                              'assets/vectors/group_33_x2.svg',
                            ),
                          ),
                        ),
                        Container(
                          margin: EdgeInsets.fromLTRB(0, 19, 0, 19),
                          child: Text(
                            'Logado: Waltair',
                            style: GoogleFonts.getFont(
                              'Fira Sans Condensed',
                              fontWeight: FontWeight.w600,
                              fontSize: 16,
                              color: Color(0xFFFFFFFF),
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                  Container(
                    margin: EdgeInsets.fromLTRB(0, 14, 0, 16),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.start,
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Container(
                          margin: EdgeInsets.fromLTRB(0, 0, 31, 0),
                          child: Container(
                            padding: EdgeInsets.fromLTRB(17, 11, 17, 12),
                            child: Stack(
                              clipBehavior: Clip.none,
                              children: [
                                Text(
                                  'Encerrar sessão',
                                  style: GoogleFonts.getFont(
                                    'Fira Sans Condensed',
                                    fontWeight: FontWeight.w600,
                                    fontSize: 16,
                                    color: Color(0xFFFFFFFF),
                                  ),
                                ),
                                Positioned(
                                  bottom: -12,
                                  child: Container(
                                    width: 138,
                                    height: 42,
                                    decoration: BoxDecoration(
                                      border: Border.all(color: Color(0xFFFFFFFF)),
                                      borderRadius: BorderRadius.circular(19),
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                        Container(
                          decoration: BoxDecoration(
                            color: Color(0xFF202075),
                          ),
                          child: SizedBox(
                            width: 53,
                            child: Container(
                              padding: EdgeInsets.fromLTRB(2.7, 12.9, 7.7, 12.6),
                              child: Stack(
                                clipBehavior: Clip.none,
                                children: [
                                  SizedBox(
                                    width: 42.6,
                                    child: Column(
                                      mainAxisAlignment: MainAxisAlignment.start,
                                      crossAxisAlignment: CrossAxisAlignment.center,
                                      children: [
                                        Container(
                                          margin: EdgeInsets.fromLTRB(7.4, 0, 2.7, 4),
                                          child: ClipRRect(
                                            borderRadius: BorderRadius.circular(40),
                                            child: SizedBox(
                                              width: 32.5,
                                              height: 2.8,
                                              child: SvgPicture.asset(
                                                'assets/vectors/rectangle_226_x2.svg',
                                              ),
                                            ),
                                          ),
                                        ),
                                        Container(
                                          margin: EdgeInsets.fromLTRB(7.4, 0, 2.7, 4),
                                          child: ClipRRect(
                                            borderRadius: BorderRadius.circular(40),
                                            child: SizedBox(
                                              width: 32.5,
                                              height: 2.8,
                                              child: SvgPicture.asset(
                                                'assets/vectors/rectangle_35_x2.svg',
                                              ),
                                            ),
                                          ),
                                        ),
                                        ClipRRect(
                                          borderRadius: BorderRadius.circular(40),
                                          child: SizedBox(
                                            width: 42.6,
                                            height: 2.8,
                                            child: SvgPicture.asset(
                                              'assets/vectors/rectangle_418_x2.svg',
                                            ),
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                  Positioned(
                                    left: -2.7,
                                    top: -11.9,
                                    child: Container(
                                      decoration: BoxDecoration(
                                        color: Color(0x03FFFFFF),
                                      ),
                                      child: Container(
                                        width: 48.7,
                                        height: 34.7,
                                      ),
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}